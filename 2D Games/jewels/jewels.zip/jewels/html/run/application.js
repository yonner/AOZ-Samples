/*@****************************************************************************
*
*   █████╗  ██████╗ ███████╗    ███████╗████████╗██╗   ██╗██████╗ ██╗ ██████╗ 
*  ██╔══██╗██╔═══██╗╚══███╔╝    ██╔════╝╚══██╔══╝██║   ██║██╔══██╗██║██╔═══██╗
*  ███████║██║   ██║  ███╔╝     ███████╗   ██║   ██║   ██║██║  ██║██║██║   ██║
*  ██╔══██║██║   ██║ ███╔╝      ╚════██║   ██║   ██║   ██║██║  ██║██║██║   ██║
*  ██║  ██║╚██████╔╝███████╗    ███████║   ██║   ╚██████╔╝██████╔╝██║╚██████╔╝
*  ╚═╝  ╚═╝ ╚═════╝ ╚══════╝    ╚══════╝   ╚═╝    ╚═════╝ ╚═════╝ ╚═╝ ╚═════╝ 
*
****************************************************************************@*/
//
// jewels
// Tomas Stenström
// Version 0.1
// Created on Thu Jan 02 2020
// (c) Your Corporation Unlimited
//
// Compiled with AOZ Transpiler Version 0.9.3.1 - 21/01/2020 on the 26/01/2020-09:59:19
//

function Application( canvasId )
{
	this.manifest=JSON.parse('{"version":"7","infos":{"applicationName":"jewels","author":"Tomas Stenström","version":"Version 0.1","date":"Created on Thu Jan 02 2020","copyright":"(c) Your Corporation Unlimited","start":"main.aoz"},"compilation":{"speed":"fast","syntax":"AOZ","emulation":"4000","usePalette":true,"useShortColors":true,"showCopperBlack":false,"unlimitedScreens":true,"unlimitedWindows":true,"maskHardwareCoordinates":false,"endian":"big"},"display":{"tvStandard":"pal","width":1024,"height":768,"background":"color","backgroundColor":"#000000","bodyBackgroundColor":"#000000","bodyBackgroundImage":"./runtime/resources/star_night.jpeg","scaleX":2,"scaleY":2,"screenScale":4,"fps":true,"fpsFont":"12px Verdana","fpsColor":"#FFFF00","fpsX":10,"fpsY":16,"fullPage":0,"fullScreen":0,"keepProportions":true,"fullScreenIcon":true,"fullScreenIconX":-34,"fullScreenIconY":2,"fullScreenIconImage":"./runtime/resources/full_screen.png","smallScreenIconImage":"./runtime/resources/small_screen.png"},"sprites":{"collisionBoxed":false,"collisionPrecision":1,"collisionAlphaThreshold":1},"sounds":{"mode":"amiga","volume":1,"preload":true,"numberOfSoundsToPreload":4,"soundPoolSize":4},"gamepad":{"mapping":{"up":38,"down":40,"left":37,"right":37,"fire":32}},"fonts":{"listFonts":"amiga","amiga":["ammolite","arial","courier","diamond","emerald","garnet","helvetica","onyx","opal","peridot","ruby","sapphire","times","topaz"],"google":[]},"default":{"screen":{"x":120,"y":42,"width":320,"height":256,"numberOfColors":32,"pixelMode":"lowres","palette":["#000000","#AA4400","#FFFFFF","#123456","#FF0000","#00FF00","#0000FF","#666666","#555555","#333333","#773333","#337733","#777733","#333377","#773377","#337777","#000000","#EECC88","#CC6600","#EEAA00","#2277FF","#4499DD","#55AAEE","#AADDFF","#BBDDFF","#CCEEFF","#FFFFFF","#440088","#AA00EE","#EE00EE","#EE0088","#EEEEEE"],"window":{"x":0,"y":0,"fontWidth":8,"fontHeight":8,"border":0,"paper":1,"pen":2,"background":"opaque","font":{"name":"topaz","type":"amiga","height":8},"cursorImage":"./runtime/resources/cursor_amiga.png","cursorColors":[{"r":68,"g":68,"b":0,"a":128},{"r":136,"g":136,"b":0,"a":128},{"r":187,"g":187,"b":0,"a":128},{"r":221,"g":221,"b":0,"a":128},{"r":238,"g":238,"b":0,"a":128},{"r":255,"g":255,"b":34,"a":128},{"r":255,"g":255,"b":136,"a":128},{"r":255,"g":255,"b":204,"a":128},{"r":255,"g":255,"b":255,"a":128},{"r":170,"g":170,"b":255,"a":128},{"r":136,"g":136,"b":204,"a":128},{"r":102,"g":102,"b":170,"a":128},{"r":34,"g":34,"b":102,"a":128},{"r":0,"g":0,"b":68,"a":128},{"r":0,"g":0,"b":17,"a":128},{"r":0,"g":0,"b":0,"a":128}]}}}}');
	this.parent=this;
	this.root=this;
	this.contextName='application';
	this.procParam=0;
	this.procParam$='';
	this.aoz=new AOZ(canvasId,this.manifest);

	// Compiled program begins here
	// ----------------------------
	this.vars=
	{
		OFFSETX:0,
		OFFSETY:0,
		DROPDELAY:0,
		SIZEX:0,
		SIZEY:0,
		GSIZEX:0,
		GSIZEY:0,
		LEVEL:0,
		POANG:0,
		GOFE:0,
		GX:0,
		GY:0,
		GC:0,
		GT:0,
		RALL:0,
		BIGCOUNT:0,
		CHLVL:0,
		NUMPLAYERS:0,
		EMODE$:"",
		CURRENTMODE$:"",
		PLIST$_array:new AArray(this.aoz,"",0),
		PROGRESS_array:new AArray(this.aoz,0,0),
		KANDY_array:new AArray(this.aoz,0,0),
		ED_array:new AArray(this.aoz,0,0),
		SAD_array:new AArray(this.aoz,0,0),
		MOV_array:new AArray(this.aoz,0,0),
		TST_array:new AArray(this.aoz,0,0),
		TST2_array:new AArray(this.aoz,0,0),
		MOVX_array:new AArray(this.aoz,0,0),
		MOVY_array:new AArray(this.aoz,0,0),
		MOVS_array:new AArray(this.aoz,0,0),
		MARKUPX:0,
		MARKUPY:0,
		MOVEPOSS:0,
		AGH:0,
		T:0,
		C:0,
		RFLAG:0,
		TRYMOVE:0,
		XM:0,
		YM:0,
		MARKX:0,
		MARKY:0,
		A$:"",
		MOVED:0,
		MARKV:0,
		SV:0,
		SVX:0,
		SVY:0,
		PN:0,
		CURRENTPLAYER:0,
		TEMP$:"",
		COUNT:0,
		COUNT2:0,
		X:0,
		Y:0,
		D:0,
		F1:0,
		Y2:0,
		X2:0,
		TR0:0,
		C2:0,
		MX1:0,
		MY1:0,
		MX2:0,
		MY2:0,
		B2:0,
		B:0,
		B3:0,
		AN:0,
		DKAND:0,
		MOVN:0,
		KR:0,
		A:0,
		K:0,
		STX:0,
		STY:0,
		MX:0,
		MY:0,
		CMARK:0,
		CMARKUP:0,
		CBOMBX:0,
		CBOMBX2:0,
		CT:0,
		D2:0,
		CBOMBY:0,
		CBOMB:0,
		CBOMBY2:0,
		CBOMB2:0,
		CANCELMOVE:0,
		WEDO:0,
		ANI:0,
		SETX:0,
		SETY:0,
		BEF:0,
		ABOVE:0,
		NEW:0,
		SX:0,
		SY:0,
		PRASK:0,
		SP:0
	}
	this.blocks=[];
	this.blocks[0]=function()
	{
		// OFFSETX=64
		this.aoz.sourcePos="9:0";
		this.vars.OFFSETX=64;
		// OFFSETY=32
		this.aoz.sourcePos="10:0";
		this.vars.OFFSETY=32;
		// DROPDELAY=8
		this.aoz.sourcePos="11:0";
		this.vars.DROPDELAY=8;
		// SIZEX=9
		this.aoz.sourcePos="12:0";
		this.vars.SIZEX=9;
		// SIZEY=9
		this.aoz.sourcePos="13:0";
		this.vars.SIZEY=9;
		// GSIZEX=16
		this.aoz.sourcePos="14:0";
		this.vars.GSIZEX=16;
		// GSIZEY=16
		this.aoz.sourcePos="15:0";
		this.vars.GSIZEY=16;
		// LEVEL=1
		this.aoz.sourcePos="16:0";
		this.vars.LEVEL=1;
		// POANG=0
		this.aoz.sourcePos="17:0";
		this.vars.POANG=0;
		// GOFE=0
		this.aoz.sourcePos="18:0";
		this.vars.GOFE=0;
		// GX=0
		this.aoz.sourcePos="19:0";
		this.vars.GX=0;
		// GY=0
		this.aoz.sourcePos="20:0";
		this.vars.GY=0;
		// GC=0
		this.aoz.sourcePos="21:0";
		this.vars.GC=0;
		// GT=0
		this.aoz.sourcePos="22:0";
		this.vars.GT=0;
		// RALL=0
		this.aoz.sourcePos="23:0";
		this.vars.RALL=0;
		// BIGCOUNT=0
		this.aoz.sourcePos="24:0";
		this.vars.BIGCOUNT=0;
		// CHLVL=0
		this.aoz.sourcePos="25:0";
		this.vars.CHLVL=0;
		// NUMPLAYERS=0
		this.aoz.sourcePos="26:0";
		this.vars.NUMPLAYERS=0;
		// EMODE$="testgame"
		this.aoz.sourcePos="27:0";
		this.vars.EMODE$="testgame";
		// CURRENTMODE$="haha"
		this.aoz.sourcePos="28:0";
		this.vars.CURRENTMODE$="haha";
		// Dim PLIST$(40)
		this.aoz.sourcePos="29:0";
		this.vars.PLIST$_array.dim([40],0);
		// Dim PROGRESS(100)
		this.aoz.sourcePos="30:0";
		this.vars.PROGRESS_array.dim([100],0);
		// Dim KANDY(20,20,5)
		this.aoz.sourcePos="31:0";
		this.vars.KANDY_array.dim([20,20,5],0);
		// Dim ED(20,20,3)
		this.aoz.sourcePos="32:0";
		this.vars.ED_array.dim([20,20,3],0);
		// Dim SAD(20,20,3)
		this.aoz.sourcePos="33:0";
		this.vars.SAD_array.dim([20,20,3],0);
		// Dim MOV(20,20)
		this.aoz.sourcePos="34:0";
		this.vars.MOV_array.dim([20,20],0);
		// Dim TST(20)
		this.aoz.sourcePos="35:0";
		this.vars.TST_array.dim([20],0);
		// Dim TST2(20)
		this.aoz.sourcePos="36:0";
		this.vars.TST2_array.dim([20],0);
		// Dim MOVX(50),MOVY(50),MOVS(50)
		this.aoz.sourcePos="37:0";
		this.vars.MOVX_array.dim([50],0);
		this.vars.MOVY_array.dim([50],0);
		this.vars.MOVS_array.dim([50],0);
		// MARKUPX=-1
		this.aoz.sourcePos="39:0";
		this.vars.MARKUPX=-1;
		// MARKUPY=-1
		this.aoz.sourcePos="40:0";
		this.vars.MARKUPY=-1;
		// MOVEPOSS=False
		this.aoz.sourcePos="41:0";
		this.vars.MOVEPOSS=Math.floor(false);
		// Screen Open 1,320,256,32,Lowres
		this.aoz.sourcePos="43:0";
		this.aoz.screenOpen(1,320,256,32,0);
		// Load Iff "df0:kandyback.iff",1
		this.aoz.sourcePos="47:0";
		return{type:12,waitThis:this.aoz.thisFilesystem,callFunction:"loadImage",waitFunction:"load_wait",args:["df0:kandyback.iff",1,false,undefined]};
	};
	this.blocks[1]=function()
	{
		// get palette 1
		this.aoz.sourcePos="49:0";
		this.aoz.currentScreen.getPalette(1,);
		// screen open 0,320,256,32,lowres
		this.aoz.sourcePos="51:0";
		this.aoz.screenOpen(0,320,256,32,0);
		// Load Iff "df0:jewels2.iff",0
		this.aoz.sourcePos="53:0";
		return{type:12,waitThis:this.aoz.thisFilesystem,callFunction:"loadImage",waitFunction:"load_wait",args:["df0:jewels2.iff",0,false,undefined]};
	};
	this.blocks[2]=function()
	{
		// get palette 0
		this.aoz.sourcePos="55:0";
		this.aoz.currentScreen.getPalette(0,);
		// AGH=1
		this.aoz.sourcePos="57:0";
		this.vars.AGH=1;
		// For T=0 To 2
		this.aoz.sourcePos="58:0";
		this.vars.T=0;
		if(this.vars.T>2)
			return{type:1,label:6};
	};
	this.blocks[3]=function()
	{
		// For C=0 To 5
		this.aoz.sourcePos="59:3";
		this.vars.C=0;
		if(this.vars.C>5)
			return{type:1,label:5};
	};
	this.blocks[4]=function()
	{
		// Get Bob C+1+T*6,T*16+1,C*16+1 To T*16+16,C*16+16
		this.aoz.sourcePos="60:6";
		this.aoz.currentScreen.getBob(this.vars.C+1+this.vars.T*6,{x:this.vars.T*16+1,y:this.vars.C*16+1,width:(this.vars.T*16+16)-(this.vars.T*16+1),height:(this.vars.C*16+16)-(this.vars.C*16+1)},undefined);
		// Inc AGH
		this.aoz.sourcePos="61:6";
		this.vars.AGH++;
		// Next C
		this.aoz.sourcePos="62:3";
		this.vars.C+=1;
		if(this.vars.C<=5)
			return{type:1,label:4}
	};
	this.blocks[5]=function()
	{
		// Next T
		this.aoz.sourcePos="63:0";
		this.vars.T+=1;
		if(this.vars.T<=2)
			return{type:1,label:3}
	};
	this.blocks[6]=function()
	{
		// For T=0 To 4
		this.aoz.sourcePos="65:0";
		this.vars.T=0;
		if(this.vars.T>4)
			return{type:1,label:8};
	};
	this.blocks[7]=function()
	{
		// Next T
		this.aoz.sourcePos="67:0";
		this.vars.T+=1;
		if(this.vars.T<=4)
			return{type:1,label:7}
	};
	this.blocks[8]=function()
	{
		// screen hide 0
		this.aoz.sourcePos="71:0";
		this.aoz.getScreen(0).show(false);
		// screen 1
		this.aoz.sourcePos="73:0";
		this.aoz.setScreen(1);
		// colour 13,$048
		this.aoz.sourcePos="75:0";
		this.aoz.currentScreen.setColour(13,0x048);
		// paper 13 : pen 1
		this.aoz.sourcePos="77:0";
		this.aoz.currentScreen.currentTextWindow.setPaper(13);
		this.aoz.sourcePos="77:11";
		this.aoz.currentScreen.currentTextWindow.setPen(1);
		// Gosub _LOADPLAYERS
		this.aoz.sourcePos="81:0";
		return{type:2,label:150,return:9};
	};
	this.blocks[9]=function()
	{
		// Gosub _LOADLEVEL
		this.aoz.sourcePos="85:0";
		return{type:2,label:490,return:10};
	};
	this.blocks[10]=function()
	{
		// Gosub CREATEGRID
		this.aoz.sourcePos="90:0";
		return{type:2,label:450,return:11};
	};
	this.blocks[11]=function()
	{
		// Gosub NEWGRID
		this.aoz.sourcePos="91:0";
		return{type:2,label:207,return:12};
	};
	this.blocks[12]=function()
	{
		// RFLAG=True : TRYMOVE=True
		this.aoz.sourcePos="93:0";
		this.vars.RFLAG=Math.floor(true);
		this.aoz.sourcePos="93:13";
		this.vars.TRYMOVE=Math.floor(true);
		// Repeat
		this.aoz.sourcePos="95:0";
	};
	this.blocks[13]=function()
	{
		// XM=X Screen(X Mouse)-OFFSETX
		this.aoz.sourcePos="96:3";
		this.vars.XM=Math.floor((this.aoz.getXMouse()-this.aoz.currentScreen.position.x)/this.aoz.currentScreen.renderScale.x -this.vars.OFFSETX);
		// YM=Y Screen(Y Mouse)-OFFSETY
		this.aoz.sourcePos="97:3";
		this.vars.YM=Math.floor((this.aoz.getYMouse()-this.aoz.currentScreen.position.y)/this.aoz.currentScreen.renderScale.y-this.vars.OFFSETY);
		// MARKX=XM/16 : MARKY=YM/16
		this.aoz.sourcePos="99:3";
		this.vars.MARKX=Math.floor(this.vars.XM/16);
		this.aoz.sourcePos="99:17";
		this.vars.MARKY=Math.floor(this.vars.YM/16);
		// if MARKX<0 : MARKX=0 : End If
		this.aoz.sourcePos="100:3";
		if(!(this.vars.MARKX<0))
			return{type:1,label:14};
		this.aoz.sourcePos="100:16";
		this.vars.MARKX=0;
		this.aoz.sourcePos="100:26";
	};
	this.blocks[14]=function()
	{
		// if MARKX>SIZEX : MARKX=SIZEX : End If
		this.aoz.sourcePos="101:3";
		if(!(this.vars.MARKX>this.vars.SIZEX))
			return{type:1,label:15};
		this.aoz.sourcePos="101:20";
		this.vars.MARKX=Math.floor(this.vars.SIZEX);
		this.aoz.sourcePos="101:34";
	};
	this.blocks[15]=function()
	{
		// if MARKY<0 : MARKY=0 : End If
		this.aoz.sourcePos="102:3";
		if(!(this.vars.MARKY<0))
			return{type:1,label:16};
		this.aoz.sourcePos="102:16";
		this.vars.MARKY=0;
		this.aoz.sourcePos="102:26";
	};
	this.blocks[16]=function()
	{
		// if MARKY>SIZEY : MARKY=SIZEY : End If
		this.aoz.sourcePos="103:3";
		if(!(this.vars.MARKY>this.vars.SIZEY))
			return{type:1,label:17};
		this.aoz.sourcePos="103:20";
		this.vars.MARKY=Math.floor(this.vars.SIZEY);
		this.aoz.sourcePos="103:34";
	};
	this.blocks[17]=function()
	{
		// A$=Inkey$
		this.aoz.sourcePos="105:3";
		this.vars.A$=this.aoz.inkey$();
		// If TRYMOVE=False : Gosub TESTMOVE : End If
		this.aoz.sourcePos="106:3";
		if(!(this.vars.TRYMOVE==false))
			return{type:1,label:19};
		this.aoz.sourcePos="106:22";
		return{type:2,label:157,return:18};
	};
	this.blocks[18]=function()
	{
		this.aoz.sourcePos="106:39";
	};
	this.blocks[19]=function()
	{
		// If EMODE$="testgame"
		this.aoz.sourcePos="107:3";
		if(!(this.vars.EMODE$=="testgame"))
			return{type:1,label:21};
		// Gosub _CHECKKANDY
		this.aoz.sourcePos="108:6";
		return{type:2,label:311,return:20};
	};
	this.blocks[20]=function()
	{
		// End If
		this.aoz.sourcePos="109:3";
	};
	this.blocks[21]=function()
	{
		// If CURRENTMODE$<>EMODE$
		this.aoz.sourcePos="110:3";
		if(!(this.vars.CURRENTMODE$!=this.vars.EMODE$))
			return{type:1,label:22};
		// Ink 2,0
		this.aoz.sourcePos="111:6";
		this.aoz.currentScreen.setInk(2,0,);
		// pen 2
		this.aoz.sourcePos="112:6";
		this.aoz.currentScreen.currentTextWindow.setPen(2);
		// locate 240/8,20/8
		this.aoz.sourcePos="113:6";
		this.aoz.currentScreen.currentTextWindow.locate({x:240/8,y:20/8});
		// CURRENTMODE$=EMODE$
		this.aoz.sourcePos="117:6";
		this.vars.CURRENTMODE$=this.vars.EMODE$;
		// End If
		this.aoz.sourcePos="118:3";
	};
	this.blocks[22]=function()
	{
		// If RFLAG=True and EMODE$="testgame"
		this.aoz.sourcePos="119:3";
		if(!(this.vars.RFLAG==true&&this.vars.EMODE$=="testgame"))
			return{type:1,label:27};
		// While RFLAG=True
		this.aoz.sourcePos="121:6";
		if(!(this.vars.RFLAG==true))
			return{type:1,label:26};
	};
	this.blocks[23]=function()
	{
		// Gosub MOVEKANDY
		this.aoz.sourcePos="123:9";
		return{type:2,label:260,return:24};
	};
	this.blocks[24]=function()
	{
		// Gosub GOTAMOVE
		this.aoz.sourcePos="127:9";
		return{type:2,label:415,return:25};
	};
	this.blocks[25]=function()
	{
		// Wend
		this.aoz.sourcePos="129:6";
		if(this.vars.RFLAG==true)
			return{type:1,label:23};
	};
	this.blocks[26]=function()
	{
		// MOVED=True : TRYMOVE=False : MOVEPOSS=False
		this.aoz.sourcePos="130:6";
		this.vars.MOVED=Math.floor(true);
		this.aoz.sourcePos="130:19";
		this.vars.TRYMOVE=Math.floor(false);
		this.aoz.sourcePos="130:35";
		this.vars.MOVEPOSS=Math.floor(false);
		// End If
		this.aoz.sourcePos="131:3";
	};
	this.blocks[27]=function()
	{
		// If Upper$(A$)="1" : EMODE$="editboard" : RALL=True : Gosub RITAGRID : End If
		this.aoz.sourcePos="132:3";
		if(!(this.vars.A$.toUpperCase()=="1"))
			return{type:1,label:29};
		this.aoz.sourcePos="132:23";
		this.vars.EMODE$="editboard";
		this.aoz.sourcePos="132:44";
		this.vars.RALL=Math.floor(true);
		this.aoz.sourcePos="132:56";
		return{type:2,label:421,return:28};
	};
	this.blocks[28]=function()
	{
		this.aoz.sourcePos="132:73";
	};
	this.blocks[29]=function()
	{
		// If Upper$(A$)="2" : EMODE$="placegems" : RALL=True : Gosub RITAGRID : End If
		this.aoz.sourcePos="133:3";
		if(!(this.vars.A$.toUpperCase()=="2"))
			return{type:1,label:31};
		this.aoz.sourcePos="133:23";
		this.vars.EMODE$="placegems";
		this.aoz.sourcePos="133:44";
		this.vars.RALL=Math.floor(true);
		this.aoz.sourcePos="133:56";
		return{type:2,label:421,return:30};
	};
	this.blocks[30]=function()
	{
		this.aoz.sourcePos="133:73";
	};
	this.blocks[31]=function()
	{
		// If Upper$(A$)="P" : EMODE$="testgame" : RALL=True : Gosub RITAGRID : End If
		this.aoz.sourcePos="134:3";
		if(!(this.vars.A$.toUpperCase()=="P"))
			return{type:1,label:33};
		this.aoz.sourcePos="134:23";
		this.vars.EMODE$="testgame";
		this.aoz.sourcePos="134:43";
		this.vars.RALL=Math.floor(true);
		this.aoz.sourcePos="134:55";
		return{type:2,label:421,return:32};
	};
	this.blocks[32]=function()
	{
		this.aoz.sourcePos="134:72";
	};
	this.blocks[33]=function()
	{
		// If Upper$(A$)="R" : Gosub RELOAD : End If
		this.aoz.sourcePos="135:3";
		if(!(this.vars.A$.toUpperCase()=="R"))
			return{type:1,label:35};
		this.aoz.sourcePos="135:23";
		return{type:2,label:479,return:34};
	};
	this.blocks[34]=function()
	{
		this.aoz.sourcePos="135:38";
	};
	this.blocks[35]=function()
	{
		// If Upper$(A$)="M" : Gosub MAKERANDOMGRID : RALL=True : Gosub RITAGRID : End If
		this.aoz.sourcePos="136:3";
		if(!(this.vars.A$.toUpperCase()=="M"))
			return{type:1,label:38};
		this.aoz.sourcePos="136:23";
		return{type:2,label:464,return:36};
	};
	this.blocks[36]=function()
	{
		this.aoz.sourcePos="136:46";
		this.vars.RALL=Math.floor(true);
		this.aoz.sourcePos="136:58";
		return{type:2,label:421,return:37};
	};
	this.blocks[37]=function()
	{
		this.aoz.sourcePos="136:75";
	};
	this.blocks[38]=function()
	{
		// If Upper$(A$)="." or CHLVL=True : CHLVL=False
		this.aoz.sourcePos="137:3";
		if(!(this.vars.A$.toUpperCase()=="."||this.vars.CHLVL==true))
			return{type:1,label:43};
		this.aoz.sourcePos="137:37";
		this.vars.CHLVL=Math.floor(false);
		// LEVEL=LEVEL+1 :
		this.aoz.sourcePos="138:6";
		this.vars.LEVEL=Math.floor(this.vars.LEVEL+1);
		// Gosub _WASHLEVEL
		this.aoz.sourcePos="140:6";
		return{type:2,label:470,return:39};
	};
	this.blocks[39]=function()
	{
		// Gosub _LOADLEVEL : RALL=True
		this.aoz.sourcePos="143:6";
		return{type:2,label:490,return:40};
	};
	this.blocks[40]=function()
	{
		this.aoz.sourcePos="143:25";
		this.vars.RALL=Math.floor(true);
		// Gosub CREATEGRID
		this.aoz.sourcePos="147:6";
		return{type:2,label:450,return:41};
	};
	this.blocks[41]=function()
	{
		// Gosub NEWGRID
		this.aoz.sourcePos="148:6";
		return{type:2,label:207,return:42};
	};
	this.blocks[42]=function()
	{
		// End If
		this.aoz.sourcePos="149:3";
	};
	this.blocks[43]=function()
	{
		// If Upper$(A$)="," : LEVEL=LEVEL-1
		this.aoz.sourcePos="150:3";
		if(!(this.vars.A$.toUpperCase()==","))
			return{type:1,label:47};
		this.aoz.sourcePos="150:23";
		this.vars.LEVEL=Math.floor(this.vars.LEVEL-1);
		// Gosub _LOADLEVEL
		this.aoz.sourcePos="151:6";
		return{type:2,label:490,return:44};
	};
	this.blocks[44]=function()
	{
		// RALL=True
		this.aoz.sourcePos="152:6";
		this.vars.RALL=Math.floor(true);
		// Gosub CREATEGRID
		this.aoz.sourcePos="155:6";
		return{type:2,label:450,return:45};
	};
	this.blocks[45]=function()
	{
		// Gosub NEWGRID
		this.aoz.sourcePos="156:6";
		return{type:2,label:207,return:46};
	};
	this.blocks[46]=function()
	{
		// End If
		this.aoz.sourcePos="157:3";
	};
	this.blocks[47]=function()
	{
		// If Upper$(A$)="T" : MOVEPOSS=False : End If
		this.aoz.sourcePos="158:3";
		if(!(this.vars.A$.toUpperCase()=="T"))
			return{type:1,label:48};
		this.aoz.sourcePos="158:23";
		this.vars.MOVEPOSS=Math.floor(false);
		this.aoz.sourcePos="158:40";
	};
	this.blocks[48]=function()
	{
		// If Upper$(A$)="V"
		this.aoz.sourcePos="159:3";
		if(!(this.vars.A$.toUpperCase()=="V"))
			return{type:1,label:52};
		// If ED(MARKX,MARKY,1)>-1
		this.aoz.sourcePos="160:6";
		if(!(this.vars.ED_array.getValue([this.vars.MARKX,this.vars.MARKY,1])>-1))
			return{type:1,label:49};
		// ED(MARKX,MARKY,1)=-1
		this.aoz.sourcePos="161:9";
		this.vars.ED_array.setValue([this.vars.MARKX,this.vars.MARKY,1],-1);
		// Else
		return{type:1,label:50};
	};
	this.blocks[49]=function()
	{
		// ED(MARKX,MARKY,1)=0
		this.aoz.sourcePos="163:9";
		this.vars.ED_array.setValue([this.vars.MARKX,this.vars.MARKY,1],0);
		// End If
		this.aoz.sourcePos="164:6";
	};
	this.blocks[50]=function()
	{
		// KANDY(MARKX,MARKY,1)=ED(MARKX,MARKY,1)
		this.aoz.sourcePos="165:6";
		this.vars.KANDY_array.setValue([this.vars.MARKX,this.vars.MARKY,1],Math.floor(this.vars.ED_array.getValue([this.vars.MARKX,this.vars.MARKY,1])));
		// KANDY(MARKX,MARKY,0)=0
		this.aoz.sourcePos="166:6";
		this.vars.KANDY_array.setValue([this.vars.MARKX,this.vars.MARKY,0],0);
		// MOV(MARKX,MARKY)=1
		this.aoz.sourcePos="167:6";
		this.vars.MOV_array.setValue([this.vars.MARKX,this.vars.MARKY],1);
		// Gosub RITAGRID
		this.aoz.sourcePos="168:6";
		return{type:2,label:421,return:51};
	};
	this.blocks[51]=function()
	{
		// End If
		this.aoz.sourcePos="169:3";
	};
	this.blocks[52]=function()
	{
		// If Upper$(A$)="L"
		this.aoz.sourcePos="170:3";
		if(!(this.vars.A$.toUpperCase()=="L"))
			return{type:1,label:54};
		// Gosub _LOADLEVEL
		this.aoz.sourcePos="171:6";
		return{type:2,label:490,return:53};
	};
	this.blocks[53]=function()
	{
		// End If
		this.aoz.sourcePos="172:3";
	};
	this.blocks[54]=function()
	{
		// If Upper$(A$)="S" : Gosub _SAVELEVEL : End If
		this.aoz.sourcePos="173:3";
		if(!(this.vars.A$.toUpperCase()=="S"))
			return{type:1,label:56};
		this.aoz.sourcePos="173:23";
		return{type:2,label:508,return:55};
	};
	this.blocks[55]=function()
	{
		this.aoz.sourcePos="173:42";
	};
	this.blocks[56]=function()
	{
		// If Mouse Key=1 and EMODE$="editboard"
		this.aoz.sourcePos="175:3";
		if(!(this.aoz.mouseButtons==1&&this.vars.EMODE$=="editboard"))
			return{type:1,label:60};
		// ED(MARKX,MARKY,1)=ED(MARKX,MARKY,1)+1
		this.aoz.sourcePos="176:6";
		this.vars.ED_array.setValue([this.vars.MARKX,this.vars.MARKY,1],Math.floor(this.vars.ED_array.getValue([this.vars.MARKX,this.vars.MARKY,1])+1));
		// KANDY(MARKX,MARKY,1)=ED(MARKX,MARKY,1)
		this.aoz.sourcePos="177:6";
		this.vars.KANDY_array.setValue([this.vars.MARKX,this.vars.MARKY,1],Math.floor(this.vars.ED_array.getValue([this.vars.MARKX,this.vars.MARKY,1])));
		// MOV(MARKX,MARKY)=1
		this.aoz.sourcePos="178:6";
		this.vars.MOV_array.setValue([this.vars.MARKX,this.vars.MARKY],1);
		// Gosub RITAGRID
		this.aoz.sourcePos="179:6";
		return{type:2,label:421,return:57};
	};
	this.blocks[57]=function()
	{
		// While Mouse Key=1 : Wend
		this.aoz.sourcePos="180:6";
		if(!(this.aoz.mouseButtons==1))
			return{type:1,label:59};
	};
	this.blocks[58]=function()
	{
		this.aoz.sourcePos="180:26";
		if(this.aoz.mouseButtons==1)
			return{type:1,label:58};
	};
	this.blocks[59]=function()
	{
		// End If
		this.aoz.sourcePos="181:3";
	};
	this.blocks[60]=function()
	{
		// If Mouse Key=2 and EMODE$="editboard"
		this.aoz.sourcePos="183:3";
		if(!(this.aoz.mouseButtons==2&&this.vars.EMODE$=="editboard"))
			return{type:1,label:65};
		// If ED(MARKX,MARKY,1)>-1
		this.aoz.sourcePos="184:6";
		if(!(this.vars.ED_array.getValue([this.vars.MARKX,this.vars.MARKY,1])>-1))
			return{type:1,label:62};
		// ED(MARKX,MARKY,1)=ED(MARKX,MARKY,1)-1
		this.aoz.sourcePos="185:9";
		this.vars.ED_array.setValue([this.vars.MARKX,this.vars.MARKY,1],Math.floor(this.vars.ED_array.getValue([this.vars.MARKX,this.vars.MARKY,1])-1));
		// KANDY(MARKX,MARKY,1)=ED(MARKX,MARKY,1)
		this.aoz.sourcePos="186:9";
		this.vars.KANDY_array.setValue([this.vars.MARKX,this.vars.MARKY,1],Math.floor(this.vars.ED_array.getValue([this.vars.MARKX,this.vars.MARKY,1])));
		// MOV(MARKX,MARKY)=1
		this.aoz.sourcePos="187:9";
		this.vars.MOV_array.setValue([this.vars.MARKX,this.vars.MARKY],1);
		// Gosub RITAGRID
		this.aoz.sourcePos="188:9";
		return{type:2,label:421,return:61};
	};
	this.blocks[61]=function()
	{
		// End If
		this.aoz.sourcePos="189:6";
	};
	this.blocks[62]=function()
	{
		// While Mouse Key=2 : Wend
		this.aoz.sourcePos="190:6";
		if(!(this.aoz.mouseButtons==2))
			return{type:1,label:64};
	};
	this.blocks[63]=function()
	{
		this.aoz.sourcePos="190:26";
		if(this.aoz.mouseButtons==2)
			return{type:1,label:63};
	};
	this.blocks[64]=function()
	{
		// End If
		this.aoz.sourcePos="191:3";
	};
	this.blocks[65]=function()
	{
		// If Mouse Key=1 and EMODE$="placegems"
		this.aoz.sourcePos="193:3";
		if(!(this.aoz.mouseButtons==1&&this.vars.EMODE$=="placegems"))
			return{type:1,label:69};
		// ED(MARKX,MARKY,0)=ED(MARKX,MARKY,0)+1
		this.aoz.sourcePos="194:6";
		this.vars.ED_array.setValue([this.vars.MARKX,this.vars.MARKY,0],Math.floor(this.vars.ED_array.getValue([this.vars.MARKX,this.vars.MARKY,0])+1));
		// KANDY(MARKX,MARKY,0)=ED(MARKX,MARKY,0)
		this.aoz.sourcePos="195:6";
		this.vars.KANDY_array.setValue([this.vars.MARKX,this.vars.MARKY,0],Math.floor(this.vars.ED_array.getValue([this.vars.MARKX,this.vars.MARKY,0])));
		// MOV(MARKX,MARKY)=1
		this.aoz.sourcePos="196:6";
		this.vars.MOV_array.setValue([this.vars.MARKX,this.vars.MARKY],1);
		// Gosub RITAGRID
		this.aoz.sourcePos="197:6";
		return{type:2,label:421,return:66};
	};
	this.blocks[66]=function()
	{
		// While Mouse Key=1 : Wend
		this.aoz.sourcePos="198:6";
		if(!(this.aoz.mouseButtons==1))
			return{type:1,label:68};
	};
	this.blocks[67]=function()
	{
		this.aoz.sourcePos="198:26";
		if(this.aoz.mouseButtons==1)
			return{type:1,label:67};
	};
	this.blocks[68]=function()
	{
		// End If
		this.aoz.sourcePos="199:3";
	};
	this.blocks[69]=function()
	{
		// If Mouse Key=2 and EMODE$="placegems"
		this.aoz.sourcePos="201:3";
		if(!(this.aoz.mouseButtons==2&&this.vars.EMODE$=="placegems"))
			return{type:1,label:74};
		// If ED(MARKX,MARKY,1)>-1
		this.aoz.sourcePos="202:6";
		if(!(this.vars.ED_array.getValue([this.vars.MARKX,this.vars.MARKY,1])>-1))
			return{type:1,label:71};
		// ED(MARKX,MARKY,0)=ED(MARKX,MARKY,0)-1
		this.aoz.sourcePos="203:9";
		this.vars.ED_array.setValue([this.vars.MARKX,this.vars.MARKY,0],Math.floor(this.vars.ED_array.getValue([this.vars.MARKX,this.vars.MARKY,0])-1));
		// KANDY(MARKX,MARKY,0)=ED(MARKX,MARKY,0)
		this.aoz.sourcePos="204:9";
		this.vars.KANDY_array.setValue([this.vars.MARKX,this.vars.MARKY,0],Math.floor(this.vars.ED_array.getValue([this.vars.MARKX,this.vars.MARKY,0])));
		// MOV(MARKX,MARKY)=1
		this.aoz.sourcePos="205:9";
		this.vars.MOV_array.setValue([this.vars.MARKX,this.vars.MARKY],1);
		// Gosub RITAGRID
		this.aoz.sourcePos="206:9";
		return{type:2,label:421,return:70};
	};
	this.blocks[70]=function()
	{
		// End If
		this.aoz.sourcePos="207:6";
	};
	this.blocks[71]=function()
	{
		// While Mouse Key=2 : Wend
		this.aoz.sourcePos="208:6";
		if(!(this.aoz.mouseButtons==2))
			return{type:1,label:73};
	};
	this.blocks[72]=function()
	{
		this.aoz.sourcePos="208:26";
		if(this.aoz.mouseButtons==2)
			return{type:1,label:72};
	};
	this.blocks[73]=function()
	{
		// End If
		this.aoz.sourcePos="209:3";
	};
	this.blocks[74]=function()
	{
		// If Mouse Key=1 and EMODE$="testgame"
		this.aoz.sourcePos="211:3";
		if(!(this.aoz.mouseButtons==1&&this.vars.EMODE$=="testgame"))
			return{type:1,label:121};
		// If MARKX>-1 and MARKX<SIZEX and MARKY>-1 and MARKY<SIZEY and KANDY(MARKX,MARKY,1)>-1
		this.aoz.sourcePos="212:6";
		if(!(this.vars.MARKX>-1&&this.vars.MARKX<this.vars.SIZEX&&this.vars.MARKY>-1&&this.vars.MARKY<this.vars.SIZEY&&this.vars.KANDY_array.getValue([this.vars.MARKX,this.vars.MARKY,1])>-1))
			return{type:1,label:120};
		// If MARKUPX=-1
		this.aoz.sourcePos="213:9";
		if(!(this.vars.MARKUPX==-1))
			return{type:1,label:78};
		// MARKUPX=MARKX : MARKUPY=MARKY : MARKV=KANDY(MARKX,MARKY,0)
		this.aoz.sourcePos="214:12";
		this.vars.MARKUPX=Math.floor(this.vars.MARKX);
		this.aoz.sourcePos="214:28";
		this.vars.MARKUPY=Math.floor(this.vars.MARKY);
		this.aoz.sourcePos="214:44";
		this.vars.MARKV=Math.floor(this.vars.KANDY_array.getValue([this.vars.MARKX,this.vars.MARKY,0]));
		// MOV(MARKX,MARKY)=1
		this.aoz.sourcePos="215:12";
		this.vars.MOV_array.setValue([this.vars.MARKX,this.vars.MARKY],1);
		// Gosub RITAGRID
		this.aoz.sourcePos="216:12";
		return{type:2,label:421,return:75};
	};
	this.blocks[75]=function()
	{
		// While Mouse Key=1 : Wend
		this.aoz.sourcePos="217:12";
		if(!(this.aoz.mouseButtons==1))
			return{type:1,label:77};
	};
	this.blocks[76]=function()
	{
		this.aoz.sourcePos="217:32";
		if(this.aoz.mouseButtons==1)
			return{type:1,label:76};
	};
	this.blocks[77]=function()
	{
		// Else
		return{type:1,label:119};
	};
	this.blocks[78]=function()
	{
		// If MARKX<MARKUPX+2 and MARKX>MARKUPX-2 and MARKY<MARKUPY+2 and MARKY>MARKUPY-2
		this.aoz.sourcePos="219:12";
		if(!(this.vars.MARKX<this.vars.MARKUPX+2&&this.vars.MARKX>this.vars.MARKUPX-2&&this.vars.MARKY<this.vars.MARKUPY+2&&this.vars.MARKY>this.vars.MARKUPY-2))
			return{type:1,label:114};
		// SV=KANDY(MARKUPX,MARKUPY,0)
		this.aoz.sourcePos="220:15";
		this.vars.SV=Math.floor(this.vars.KANDY_array.getValue([this.vars.MARKUPX,this.vars.MARKUPY,0]));
		// If MARKX=MARKUPX and MARKY=MARKUPY
		this.aoz.sourcePos="221:15";
		if(!(this.vars.MARKX==this.vars.MARKUPX&&this.vars.MARKY==this.vars.MARKUPY))
			return{type:1,label:82};
		// MARKUPX=-1
		this.aoz.sourcePos="222:18";
		this.vars.MARKUPX=-1;
		// MOV(MARKX,MARKY)=1
		this.aoz.sourcePos="223:18";
		this.vars.MOV_array.setValue([this.vars.MARKX,this.vars.MARKY],1);
		// Gosub RITAGRID
		this.aoz.sourcePos="224:18";
		return{type:2,label:421,return:79};
	};
	this.blocks[79]=function()
	{
		// While Mouse Key=1
		this.aoz.sourcePos="225:18";
		if(!(this.aoz.mouseButtons==1))
			return{type:1,label:81};
	};
	this.blocks[80]=function()
	{
		// Wend
		this.aoz.sourcePos="226:18";
		if(this.aoz.mouseButtons==1)
			return{type:1,label:80};
	};
	this.blocks[81]=function()
	{
		// Goto LP
		this.aoz.sourcePos="227:18";
		return{type:1,label:122};
		// End If
		this.aoz.sourcePos="228:15";
	};
	this.blocks[82]=function()
	{
		// TRYMOVE=True
		this.aoz.sourcePos="229:15";
		this.vars.TRYMOVE=Math.floor(true);
		// MOV(MARKX,MARKY)=1
		this.aoz.sourcePos="230:15";
		this.vars.MOV_array.setValue([this.vars.MARKX,this.vars.MARKY],1);
		// MOV(MARKUPX,MARKUPY)=1
		this.aoz.sourcePos="231:15";
		this.vars.MOV_array.setValue([this.vars.MARKUPX,this.vars.MARKUPY],1);
		// Gosub SGRID
		this.aoz.sourcePos="232:15";
		return{type:2,label:246,return:83};
	};
	this.blocks[83]=function()
	{
		// If MARKX=MARKUPX
		this.aoz.sourcePos="233:15";
		if(!(this.vars.MARKX==this.vars.MARKUPX))
			return{type:1,label:98};
		// If MARKY<MARKUPY
		this.aoz.sourcePos="234:18";
		if(!(this.vars.MARKY<this.vars.MARKUPY))
			return{type:1,label:88};
		// KANDY(MARKUPX,MARKUPY,0)=KANDY(MARKUPX,MARKUPY-1,0)
		this.aoz.sourcePos="235:21";
		this.vars.KANDY_array.setValue([this.vars.MARKUPX,this.vars.MARKUPY,0],Math.floor(this.vars.KANDY_array.getValue([this.vars.MARKUPX,this.vars.MARKUPY-1,0])));
		// KANDY(MARKUPX,MARKUPY-1,0)=SV
		this.aoz.sourcePos="236:21";
		this.vars.KANDY_array.setValue([this.vars.MARKUPX,this.vars.MARKUPY-1,0],Math.floor(this.vars.SV));
		// MOV(MARKUPX,MARKUPY-1)=1
		this.aoz.sourcePos="237:21";
		this.vars.MOV_array.setValue([this.vars.MARKUPX,this.vars.MARKUPY-1],1);
		// SVX=MARKUPX : SVY=MARKUPY-1
		this.aoz.sourcePos="238:21";
		this.vars.SVX=Math.floor(this.vars.MARKUPX);
		this.aoz.sourcePos="238:35";
		this.vars.SVY=Math.floor(this.vars.MARKUPY-1);
		// Gosub ANMOVE
		this.aoz.sourcePos="239:21";
		return{type:2,label:221,return:84};
	};
	this.blocks[84]=function()
	{
		// If KANDY(MARKX,MARKY,0)>20 or KANDY(MARKUPX,MARKUPY,0)>20
		this.aoz.sourcePos="240:21";
		if(!(this.vars.KANDY_array.getValue([this.vars.MARKX,this.vars.MARKY,0])>20||this.vars.KANDY_array.getValue([this.vars.MARKUPX,this.vars.MARKUPY,0])>20))
			return{type:1,label:87};
		// Gosub BONUS1
		this.aoz.sourcePos="241:24";
		return{type:2,label:234,return:85};
	};
	this.blocks[85]=function()
	{
		// RFLAG=True
		this.aoz.sourcePos="242:24";
		this.vars.RFLAG=Math.floor(true);
		// Gosub DELKANDY
		this.aoz.sourcePos="243:24";
		return{type:2,label:239,return:86};
	};
	this.blocks[86]=function()
	{
		// End If
		this.aoz.sourcePos="244:21";
	};
	this.blocks[87]=function()
	{
		// Else
		return{type:1,label:94};
	};
	this.blocks[88]=function()
	{
		// If MARKUPY<SIZEY-1
		this.aoz.sourcePos="246:21";
		if(!(this.vars.MARKUPY<this.vars.SIZEY-1))
			return{type:1,label:93};
		// KANDY(MARKUPX,MARKUPY,0)=KANDY(MARKUPX,MARKUPY+1,0)
		this.aoz.sourcePos="247:24";
		this.vars.KANDY_array.setValue([this.vars.MARKUPX,this.vars.MARKUPY,0],Math.floor(this.vars.KANDY_array.getValue([this.vars.MARKUPX,this.vars.MARKUPY+1,0])));
		// KANDY(MARKUPX,MARKUPY+1,0)=SV
		this.aoz.sourcePos="248:24";
		this.vars.KANDY_array.setValue([this.vars.MARKUPX,this.vars.MARKUPY+1,0],Math.floor(this.vars.SV));
		// SVX=MARKUPX : SVY=MARKUPY+1
		this.aoz.sourcePos="249:24";
		this.vars.SVX=Math.floor(this.vars.MARKUPX);
		this.aoz.sourcePos="249:38";
		this.vars.SVY=Math.floor(this.vars.MARKUPY+1);
		// Gosub ANMOVE
		this.aoz.sourcePos="250:24";
		return{type:2,label:221,return:89};
	};
	this.blocks[89]=function()
	{
		// If KANDY(MARKX,MARKY,0)>20 or KANDY(MARKUPX,MARKUPY,0)>20
		this.aoz.sourcePos="251:24";
		if(!(this.vars.KANDY_array.getValue([this.vars.MARKX,this.vars.MARKY,0])>20||this.vars.KANDY_array.getValue([this.vars.MARKUPX,this.vars.MARKUPY,0])>20))
			return{type:1,label:92};
		// Gosub BONUS1
		this.aoz.sourcePos="252:27";
		return{type:2,label:234,return:90};
	};
	this.blocks[90]=function()
	{
		// RFLAG=True
		this.aoz.sourcePos="253:27";
		this.vars.RFLAG=Math.floor(true);
		// Gosub DELKANDY
		this.aoz.sourcePos="254:27";
		return{type:2,label:239,return:91};
	};
	this.blocks[91]=function()
	{
		// End If
		this.aoz.sourcePos="255:24";
	};
	this.blocks[92]=function()
	{
		// End If
		this.aoz.sourcePos="256:21";
	};
	this.blocks[93]=function()
	{
		// End If
		this.aoz.sourcePos="257:18";
	};
	this.blocks[94]=function()
	{
		// MARKUPX=-1
		this.aoz.sourcePos="258:18";
		this.vars.MARKUPX=-1;
		// Gosub RITAGRID
		this.aoz.sourcePos="259:18";
		return{type:2,label:421,return:95};
	};
	this.blocks[95]=function()
	{
		// While Mouse Key=1 : Wend
		this.aoz.sourcePos="260:18";
		if(!(this.aoz.mouseButtons==1))
			return{type:1,label:97};
	};
	this.blocks[96]=function()
	{
		this.aoz.sourcePos="260:38";
		if(this.aoz.mouseButtons==1)
			return{type:1,label:96};
	};
	this.blocks[97]=function()
	{
		// Goto LP
		this.aoz.sourcePos="261:18";
		return{type:1,label:122};
		// End If
		this.aoz.sourcePos="262:15";
	};
	this.blocks[98]=function()
	{
		// If MARKY=MARKUPY
		this.aoz.sourcePos="263:15";
		if(!(this.vars.MARKY==this.vars.MARKUPY))
			return{type:1,label:113};
		// If MARKX<MARKUPX
		this.aoz.sourcePos="264:18";
		if(!(this.vars.MARKX<this.vars.MARKUPX))
			return{type:1,label:103};
		// KANDY(MARKUPX,MARKUPY,0)=KANDY(MARKUPX-1,MARKUPY,0)
		this.aoz.sourcePos="265:21";
		this.vars.KANDY_array.setValue([this.vars.MARKUPX,this.vars.MARKUPY,0],Math.floor(this.vars.KANDY_array.getValue([this.vars.MARKUPX-1,this.vars.MARKUPY,0])));
		// KANDY(MARKUPX-1,MARKUPY,0)=SV
		this.aoz.sourcePos="266:21";
		this.vars.KANDY_array.setValue([this.vars.MARKUPX-1,this.vars.MARKUPY,0],Math.floor(this.vars.SV));
		// SVX=MARKUPX-1 : SVY=MARKUPY
		this.aoz.sourcePos="267:21";
		this.vars.SVX=Math.floor(this.vars.MARKUPX-1);
		this.aoz.sourcePos="267:37";
		this.vars.SVY=Math.floor(this.vars.MARKUPY);
		// Gosub ANMOVE
		this.aoz.sourcePos="268:21";
		return{type:2,label:221,return:99};
	};
	this.blocks[99]=function()
	{
		// If KANDY(MARKX,MARKY,0)>20 or KANDY(MARKUPX,MARKUPY,0)>20
		this.aoz.sourcePos="269:21";
		if(!(this.vars.KANDY_array.getValue([this.vars.MARKX,this.vars.MARKY,0])>20||this.vars.KANDY_array.getValue([this.vars.MARKUPX,this.vars.MARKUPY,0])>20))
			return{type:1,label:102};
		// Gosub BONUS1
		this.aoz.sourcePos="270:24";
		return{type:2,label:234,return:100};
	};
	this.blocks[100]=function()
	{
		// RFLAG=True
		this.aoz.sourcePos="271:24";
		this.vars.RFLAG=Math.floor(true);
		// Gosub DELKANDY
		this.aoz.sourcePos="272:24";
		return{type:2,label:239,return:101};
	};
	this.blocks[101]=function()
	{
		// End If
		this.aoz.sourcePos="273:21";
	};
	this.blocks[102]=function()
	{
		// Else
		return{type:1,label:109};
	};
	this.blocks[103]=function()
	{
		// If MARKUPX<SIZEX-1
		this.aoz.sourcePos="275:21";
		if(!(this.vars.MARKUPX<this.vars.SIZEX-1))
			return{type:1,label:108};
		// KANDY(MARKUPX,MARKUPY,0)=KANDY(MARKUPX+1,MARKUPY,0)
		this.aoz.sourcePos="276:24";
		this.vars.KANDY_array.setValue([this.vars.MARKUPX,this.vars.MARKUPY,0],Math.floor(this.vars.KANDY_array.getValue([this.vars.MARKUPX+1,this.vars.MARKUPY,0])));
		// KANDY(MARKUPX+1,MARKUPY,0)=SV
		this.aoz.sourcePos="277:24";
		this.vars.KANDY_array.setValue([this.vars.MARKUPX+1,this.vars.MARKUPY,0],Math.floor(this.vars.SV));
		// SVX=MARKUPX+1 : SVY=MARKUPY
		this.aoz.sourcePos="278:24";
		this.vars.SVX=Math.floor(this.vars.MARKUPX+1);
		this.aoz.sourcePos="278:40";
		this.vars.SVY=Math.floor(this.vars.MARKUPY);
		// Gosub ANMOVE
		this.aoz.sourcePos="279:24";
		return{type:2,label:221,return:104};
	};
	this.blocks[104]=function()
	{
		// If KANDY(MARKX,MARKY,0)>20 or KANDY(MARKUPX,MARKUPY,0)>20
		this.aoz.sourcePos="280:24";
		if(!(this.vars.KANDY_array.getValue([this.vars.MARKX,this.vars.MARKY,0])>20||this.vars.KANDY_array.getValue([this.vars.MARKUPX,this.vars.MARKUPY,0])>20))
			return{type:1,label:107};
		// Gosub BONUS1
		this.aoz.sourcePos="281:27";
		return{type:2,label:234,return:105};
	};
	this.blocks[105]=function()
	{
		// RFLAG=True
		this.aoz.sourcePos="282:27";
		this.vars.RFLAG=Math.floor(true);
		// Gosub DELKANDY
		this.aoz.sourcePos="283:27";
		return{type:2,label:239,return:106};
	};
	this.blocks[106]=function()
	{
		// End If
		this.aoz.sourcePos="284:24";
	};
	this.blocks[107]=function()
	{
		// End If
		this.aoz.sourcePos="285:21";
	};
	this.blocks[108]=function()
	{
		// End If
		this.aoz.sourcePos="286:18";
	};
	this.blocks[109]=function()
	{
		// MARKUPX=-1
		this.aoz.sourcePos="287:18";
		this.vars.MARKUPX=-1;
		// Gosub RITAGRID
		this.aoz.sourcePos="288:18";
		return{type:2,label:421,return:110};
	};
	this.blocks[110]=function()
	{
		// While Mouse Key=1 : Wend
		this.aoz.sourcePos="289:18";
		if(!(this.aoz.mouseButtons==1))
			return{type:1,label:112};
	};
	this.blocks[111]=function()
	{
		this.aoz.sourcePos="289:38";
		if(this.aoz.mouseButtons==1)
			return{type:1,label:111};
	};
	this.blocks[112]=function()
	{
		// Goto LP
		this.aoz.sourcePos="290:18";
		return{type:1,label:122};
		// End If
		this.aoz.sourcePos="291:15";
	};
	this.blocks[113]=function()
	{
		// Else
		return{type:1,label:118};
	};
	this.blocks[114]=function()
	{
		// MOV(MARKUPX,MARKUPY)=1
		this.aoz.sourcePos="293:15";
		this.vars.MOV_array.setValue([this.vars.MARKUPX,this.vars.MARKUPY],1);
		// MARKUPX=-1
		this.aoz.sourcePos="294:15";
		this.vars.MARKUPX=-1;
		// Gosub RITAGRID
		this.aoz.sourcePos="295:15";
		return{type:2,label:421,return:115};
	};
	this.blocks[115]=function()
	{
		// While Mouse Key=1
		this.aoz.sourcePos="296:15";
		if(!(this.aoz.mouseButtons==1))
			return{type:1,label:117};
	};
	this.blocks[116]=function()
	{
		// Wend
		this.aoz.sourcePos="297:15";
		if(this.aoz.mouseButtons==1)
			return{type:1,label:116};
	};
	this.blocks[117]=function()
	{
		// Goto LP
		this.aoz.sourcePos="298:15";
		return{type:1,label:122};
		// End If
		this.aoz.sourcePos="299:12";
	};
	this.blocks[118]=function()
	{
		// End If
		this.aoz.sourcePos="300:9";
	};
	this.blocks[119]=function()
	{
		// End If
		this.aoz.sourcePos="301:6";
	};
	this.blocks[120]=function()
	{
		// End If
		this.aoz.sourcePos="302:3";
	};
	this.blocks[121]=function()
	{
	};
	this.blocks[122]=function()
	{
		// LP:
		// Until Upper$(A$)="Q"
		this.aoz.sourcePos="304:0";
		if(!(this.vars.A$.toUpperCase()=="Q"))
			return{type:1,label:13};
	};
	this.blocks[123]=function()
	{
		// Erase All
		this.aoz.sourcePos="305:0";
		// Edit
		this.aoz.sourcePos="306:0";
		return{type:0}
	};
	this.blocks[124]=function()
	{
		// MAINMENU:
		// Return
		this.aoz.sourcePos="312:0";
		return{type:3};
	};
	this.blocks[125]=function()
	{
		// CHOOSEPLAYER:
		// Screen Open 4,320,256,4,Lowres
		this.aoz.sourcePos="315:0";
		this.aoz.screenOpen(4,320,256,4,0);
	};
	this.blocks[126]=function()
	{
		// RETRY2:
		// Cls 0
		this.aoz.sourcePos="317:0";
		this.aoz.currentScreen.cls(0);
		// Print "100 to add a new player"
		this.aoz.sourcePos="318:0";
		this.aoz.currentScreen.currentTextWindow.print("100 to add a new player",true);
		// For T=0 To NUMPLAYERS
		this.aoz.sourcePos="319:0";
		this.vars.T=0;
		if(this.vars.T>this.vars.NUMPLAYERS)
			return{type:1,label:128};
	};
	this.blocks[127]=function()
	{
		// Text 20,40+T*10,Str$(T)+"-"+PLIST$(T)
		this.aoz.sourcePos="320:3";
		this.aoz.currentScreen.text({x:20,y:40+this.vars.T*10},this.aoz.str$(this.vars.T)+"-"+this.vars.PLIST$_array.getValue([this.vars.T]),undefined);
		// Next T
		this.aoz.sourcePos="321:0";
		this.vars.T+=1;
		if(this.vars.T<=this.vars.NUMPLAYERS)
			return{type:1,label:127}
	};
	this.blocks[128]=function()
	{
		// Locate 2,2
		this.aoz.sourcePos="322:0";
		this.aoz.currentScreen.currentTextWindow.locate({x:2,y:2});
		// Input "player nr: ";PN
		this.aoz.sourcePos="323:0";
		return{type:8,instruction:"input",args:{text:"player nr: ",variables:[{name:"PN",type:0}],newLine:true}};
	};
	this.blocks[129]=function()
	{
		// CURRENTPLAYER=PN
		this.aoz.sourcePos="324:0";
		this.vars.CURRENTPLAYER=Math.floor(this.vars.PN);
		// If PN=100
		this.aoz.sourcePos="325:0";
		if(!(this.vars.PN==100))
			return{type:1,label:137};
		// Input "new player: ";TEMP$
		this.aoz.sourcePos="326:3";
		return{type:8,instruction:"input",args:{text:"new player: ",variables:[{name:"TEMP$",type:2}],newLine:true}};
	};
	this.blocks[130]=function()
	{
		// For T=0 To NUMPLAYERS
		this.aoz.sourcePos="327:3";
		this.vars.T=0;
		if(this.vars.T>this.vars.NUMPLAYERS)
			return{type:1,label:136};
	};
	this.blocks[131]=function()
	{
		// If Upper$(TEMP$)=Upper$(PLIST$(T))
		this.aoz.sourcePos="328:6";
		if(!(this.vars.TEMP$.toUpperCase()==this.vars.PLIST$_array.getValue([this.vars.T]).toUpperCase()))
			return{type:1,label:133};
		// Print "player already exists - press any key"
		this.aoz.sourcePos="329:9";
		this.aoz.currentScreen.currentTextWindow.print("player already exists - press any key",true);
		// Wait Key
		this.aoz.sourcePos="330:9";
		return{type:8,instruction:"waitKey",args:[]};
	};
	this.blocks[132]=function()
	{
		// Goto RETRY2
		this.aoz.sourcePos="331:9";
		return{type:1,label:126};
		// Else
		return{type:1,label:135};
	};
	this.blocks[133]=function()
	{
		// NUMPLAYERS=NUMPLAYERS+1
		this.aoz.sourcePos="333:9";
		this.vars.NUMPLAYERS=Math.floor(this.vars.NUMPLAYERS+1);
		// PLIST$(NUMPLAYERS)=TEMP$
		this.aoz.sourcePos="334:9";
		this.vars.PLIST$_array.setValue([this.vars.NUMPLAYERS],this.vars.TEMP$);
		// CURRENTPLAYER=NUMPLAYERS
		this.aoz.sourcePos="335:9";
		this.vars.CURRENTPLAYER=Math.floor(this.vars.NUMPLAYERS);
		// Gosub _SAVEPLAYERS
		this.aoz.sourcePos="336:9";
		return{type:2,label:145,return:134};
	};
	this.blocks[134]=function()
	{
		// End If
		this.aoz.sourcePos="337:6";
	};
	this.blocks[135]=function()
	{
		// Next T
		this.aoz.sourcePos="338:3";
		this.vars.T+=1;
		if(this.vars.T<=this.vars.NUMPLAYERS)
			return{type:1,label:131}
	};
	this.blocks[136]=function()
	{
		// End If
		this.aoz.sourcePos="339:0";
	};
	this.blocks[137]=function()
	{
		// If PN=101
		this.aoz.sourcePos="340:0";
		if(!(this.vars.PN==101))
			return{type:1,label:141};
		// Input "player nr:";PN
		this.aoz.sourcePos="341:3";
		return{type:8,instruction:"input",args:{text:"player nr:",variables:[{name:"PN",type:0}],newLine:true}};
	};
	this.blocks[138]=function()
	{
		// Input "new name: ";PLIST$(PN)
		this.aoz.sourcePos="342:3";
		return{type:8,instruction:"input",args:{text:"new name: ",variables:[{name:"PLIST$_array",dimensions:[this.vars.PN],type:2}],newLine:true}};
	};
	this.blocks[139]=function()
	{
		// Gosub _SAVEPLAYERS
		this.aoz.sourcePos="343:3";
		return{type:2,label:145,return:140};
	};
	this.blocks[140]=function()
	{
		// Goto RETRY2
		this.aoz.sourcePos="344:3";
		return{type:1,label:126};
		// End If
		this.aoz.sourcePos="345:0";
	};
	this.blocks[141]=function()
	{
		// Screen Close 4
		this.aoz.sourcePos="346:0";
		this.aoz.screenClose(4);
		// Gosub _LOADPROGRESS
		this.aoz.sourcePos="347:0";
		return{type:2,label:144,return:142};
	};
	this.blocks[142]=function()
	{
		// Return
		this.aoz.sourcePos="348:0";
		return{type:3};
	};
	this.blocks[143]=function()
	{
		// _SAVEPROGRESS:
		// Return
		this.aoz.sourcePos="352:0";
		return{type:3};
	};
	this.blocks[144]=function()
	{
		// _LOADPROGRESS:
		// Return
		this.aoz.sourcePos="356:0";
		return{type:3};
	};
	this.blocks[145]=function()
	{
		// _SAVEPLAYERS:
		// Open Out 1,"df0:players.dat"
		this.aoz.sourcePos="360:0";
		return{type:12,waitThis:this.aoz.thisFilesystem,callFunction:"openOut",waitFunction:"load_wait",args:[1,"df0:players.dat"]};
	};
	this.blocks[146]=function()
	{
		// For T=0 To NUMPLAYERS
		this.aoz.sourcePos="361:0";
		this.vars.T=0;
		if(this.vars.T>this.vars.NUMPLAYERS)
			return{type:1,label:148};
	};
	this.blocks[147]=function()
	{
		// Print #1,PLIST$(T)
		this.aoz.sourcePos="362:3";
		this.aoz.filesystem.print(1,this.vars.PLIST$_array.getValue([this.vars.T]),true);
		// Next T
		this.aoz.sourcePos="363:0";
		this.vars.T+=1;
		if(this.vars.T<=this.vars.NUMPLAYERS)
			return{type:1,label:147}
	};
	this.blocks[148]=function()
	{
		// Close 1
		this.aoz.sourcePos="364:0";
		return{type:12,waitThis:this.aoz.thisFilesystem,callFunction:"close",waitFunction:"load_wait",args:[1]};
	};
	this.blocks[149]=function()
	{
		// Return
		this.aoz.sourcePos="365:0";
		return{type:3};
	};
	this.blocks[150]=function()
	{
		// _LOADPLAYERS:
		// If Exist("df0:players.dat")
		this.aoz.sourcePos="368:0";
		if(!(this.aoz.filesystem.exist("df0:players.dat")))
			return{type:1,label:156};
		// Open In 1,"df0:players.dat"
		this.aoz.sourcePos="369:3";
		return{type:12,waitThis:this.aoz.thisFilesystem,callFunction:"openIn",waitFunction:"load_wait",args:[1,"df0:players.dat"]};
	};
	this.blocks[151]=function()
	{
		// T=0
		this.aoz.sourcePos="370:3";
		this.vars.T=0;
		// While Not Eof(1)
		this.aoz.sourcePos="371:3";
		if(!(!(this.aoz.filesystem.eof(1))))
			return{type:1,label:154};
	};
	this.blocks[152]=function()
	{
		// Input #1,PLIST$(T)
		this.aoz.sourcePos="372:6";
		this.aoz.filesystem.input(1,[{name:"PLIST$_array",dimensions:[this.vars.T],type:2}],false);
	};
	this.blocks[153]=function()
	{
		// T=T+1
		this.aoz.sourcePos="373:6";
		this.vars.T=Math.floor(this.vars.T+1);
		// Wend
		this.aoz.sourcePos="374:3";
		if(!(this.aoz.filesystem.eof(1)))
			return{type:1,label:152};
	};
	this.blocks[154]=function()
	{
		// NUMPLAYERS=T-1
		this.aoz.sourcePos="375:3";
		this.vars.NUMPLAYERS=Math.floor(this.vars.T-1);
		// Close 1
		this.aoz.sourcePos="376:3";
		return{type:12,waitThis:this.aoz.thisFilesystem,callFunction:"close",waitFunction:"load_wait",args:[1]};
	};
	this.blocks[155]=function()
	{
		// End If
		this.aoz.sourcePos="377:0";
	};
	this.blocks[156]=function()
	{
		// Return
		this.aoz.sourcePos="378:0";
		return{type:3};
	};
	this.blocks[157]=function()
	{
		// TESTMOVE:
		// If MOVEPOSS=False
		this.aoz.sourcePos="381:0";
		if(!(this.vars.MOVEPOSS==false))
			return{type:1,label:206};
		// COUNT=0 : COUNT2=0
		this.aoz.sourcePos="382:3";
		this.vars.COUNT=0;
		this.aoz.sourcePos="382:13";
		this.vars.COUNT2=0;
		// For X=0 To SIZEX-1
		this.aoz.sourcePos="383:3";
		this.vars.X=0;
		if(this.vars.X>this.vars.SIZEX-1)
			return{type:1,label:162};
	};
	this.blocks[158]=function()
	{
		// For Y=0 To SIZEY-1
		this.aoz.sourcePos="384:6";
		this.vars.Y=0;
		if(this.vars.Y>this.vars.SIZEY-1)
			return{type:1,label:161};
	};
	this.blocks[159]=function()
	{
		// If KANDY(X,Y,0)=21
		this.aoz.sourcePos="385:9";
		if(!(this.vars.KANDY_array.getValue([this.vars.X,this.vars.Y,0])==21))
			return{type:1,label:160};
		// MOVEPOSS=True
		this.aoz.sourcePos="386:12";
		this.vars.MOVEPOSS=Math.floor(true);
		// Return
		this.aoz.sourcePos="387:12";
		return{type:3};
		// End If
		this.aoz.sourcePos="388:9";
	};
	this.blocks[160]=function()
	{
		// Next Y
		this.aoz.sourcePos="389:6";
		this.vars.Y+=1;
		if(this.vars.Y<=this.vars.SIZEY-1)
			return{type:1,label:159}
	};
	this.blocks[161]=function()
	{
		// Next X
		this.aoz.sourcePos="390:3";
		this.vars.X+=1;
		if(this.vars.X<=this.vars.SIZEX-1)
			return{type:1,label:158}
	};
	this.blocks[162]=function()
	{
		// For X=0 To SIZEX-1
		this.aoz.sourcePos="391:3";
		this.vars.X=0;
		if(this.vars.X>this.vars.SIZEX-1)
			return{type:1,label:201};
	};
	this.blocks[163]=function()
	{
		// For Y=0 To SIZEY-1
		this.aoz.sourcePos="392:6";
		this.vars.Y=0;
		if(this.vars.Y>this.vars.SIZEY-1)
			return{type:1,label:200};
	};
	this.blocks[164]=function()
	{
		// If KANDY(X,Y,1)>-1
		this.aoz.sourcePos="393:9";
		if(!(this.vars.KANDY_array.getValue([this.vars.X,this.vars.Y,1])>-1))
			return{type:1,label:199};
		// D=KANDY(X,Y,0) : C=0 : F1=False
		this.aoz.sourcePos="394:12";
		this.vars.D=Math.floor(this.vars.KANDY_array.getValue([this.vars.X,this.vars.Y,0]));
		this.aoz.sourcePos="394:29";
		this.vars.C=0;
		this.aoz.sourcePos="394:35";
		this.vars.F1=Math.floor(false);
		// If D>0
		this.aoz.sourcePos="395:12";
		if(!(this.vars.D>0))
			return{type:1,label:198};
		// If D>10 : D=D-10 : End If
		this.aoz.sourcePos="396:15";
		if(!(this.vars.D>10))
			return{type:1,label:165};
		this.aoz.sourcePos="396:25";
		this.vars.D=Math.floor(this.vars.D-10);
		this.aoz.sourcePos="396:34";
	};
	this.blocks[165]=function()
	{
		// For Y2=Y-1 To Y+1 Step 1
		this.aoz.sourcePos="397:15";
		this.vars.Y2=Math.floor(this.vars.Y-1);
		if(this.vars.Y2>this.vars.Y+1)
			return{type:1,label:171};
	};
	this.blocks[166]=function()
	{
		// For X2=X-1 To X+1 Step 1
		this.aoz.sourcePos="398:18";
		this.vars.X2=Math.floor(this.vars.X-1);
		if(this.vars.X2>this.vars.X+1)
			return{type:1,label:170};
	};
	this.blocks[167]=function()
	{
		// If X2>-1 and Y2>-1 and X2<SIZEX and Y2<SIZEY
		this.aoz.sourcePos="399:21";
		if(!(this.vars.X2>-1&&this.vars.Y2>-1&&this.vars.X2<this.vars.SIZEX&&this.vars.Y2<this.vars.SIZEY))
			return{type:1,label:168};
		// TST(C)=KANDY(X2,Y2,0)
		this.aoz.sourcePos="400:24";
		this.vars.TST_array.setValue([this.vars.C],Math.floor(this.vars.KANDY_array.getValue([this.vars.X2,this.vars.Y2,0])));
		// TST2(C)=KANDY(X2,Y2,1)
		this.aoz.sourcePos="401:24";
		this.vars.TST2_array.setValue([this.vars.C],Math.floor(this.vars.KANDY_array.getValue([this.vars.X2,this.vars.Y2,1])));
		// Else
		return{type:1,label:169};
	};
	this.blocks[168]=function()
	{
		// TST(C)=-2
		this.aoz.sourcePos="403:24";
		this.vars.TST_array.setValue([this.vars.C],-2);
		// TST2(C)=-2
		this.aoz.sourcePos="404:24";
		this.vars.TST2_array.setValue([this.vars.C],-2);
		// End If
		this.aoz.sourcePos="405:21";
	};
	this.blocks[169]=function()
	{
		// C=C+1
		this.aoz.sourcePos="406:21";
		this.vars.C=Math.floor(this.vars.C+1);
		// Next X2
		this.aoz.sourcePos="407:18";
		this.vars.X2+=1;
		if(this.vars.X2<=this.vars.X+1)
			return{type:1,label:167}
	};
	this.blocks[170]=function()
	{
		// Next Y2
		this.aoz.sourcePos="408:15";
		this.vars.Y2+=1;
		if(this.vars.Y2<=this.vars.Y+1)
			return{type:1,label:166}
	};
	this.blocks[171]=function()
	{
		// If Y+2<SIZEY
		this.aoz.sourcePos="409:15";
		if(!(this.vars.Y+2<this.vars.SIZEY))
			return{type:1,label:172};
		// TST(9)=KANDY(X,Y+2,0)
		this.aoz.sourcePos="410:18";
		this.vars.TST_array.setValue([9],Math.floor(this.vars.KANDY_array.getValue([this.vars.X,this.vars.Y+2,0])));
		// Else
		return{type:1,label:173};
	};
	this.blocks[172]=function()
	{
		// TST(9)=-2
		this.aoz.sourcePos="412:18";
		this.vars.TST_array.setValue([9],-2);
		// End If
		this.aoz.sourcePos="413:15";
	};
	this.blocks[173]=function()
	{
		// If X+2<SIZEX
		this.aoz.sourcePos="414:15";
		if(!(this.vars.X+2<this.vars.SIZEX))
			return{type:1,label:174};
		// TST(10)=KANDY(X+2,Y,0)
		this.aoz.sourcePos="415:18";
		this.vars.TST_array.setValue([10],Math.floor(this.vars.KANDY_array.getValue([this.vars.X+2,this.vars.Y,0])));
		// Else
		return{type:1,label:175};
	};
	this.blocks[174]=function()
	{
		// TST(10)=-2
		this.aoz.sourcePos="417:18";
		this.vars.TST_array.setValue([10],-2);
		// End If
		this.aoz.sourcePos="418:15";
	};
	this.blocks[175]=function()
	{
		// If Y-2>-1
		this.aoz.sourcePos="419:15";
		if(!(this.vars.Y-2>-1))
			return{type:1,label:176};
		// TST(11)=KANDY(X,Y-2,0)
		this.aoz.sourcePos="420:18";
		this.vars.TST_array.setValue([11],Math.floor(this.vars.KANDY_array.getValue([this.vars.X,this.vars.Y-2,0])));
		// Else
		return{type:1,label:177};
	};
	this.blocks[176]=function()
	{
		// TST(11)=-2
		this.aoz.sourcePos="422:18";
		this.vars.TST_array.setValue([11],-2);
		// End If
		this.aoz.sourcePos="423:15";
	};
	this.blocks[177]=function()
	{
		// If X-2>-1
		this.aoz.sourcePos="424:15";
		if(!(this.vars.X-2>-1))
			return{type:1,label:178};
		// TST(12)=KANDY(X-2,Y,0)
		this.aoz.sourcePos="425:18";
		this.vars.TST_array.setValue([12],Math.floor(this.vars.KANDY_array.getValue([this.vars.X-2,this.vars.Y,0])));
		// Else
		return{type:1,label:179};
	};
	this.blocks[178]=function()
	{
		// TST(12)=-2
		this.aoz.sourcePos="427:18";
		this.vars.TST_array.setValue([12],-2);
		// End If
		this.aoz.sourcePos="428:15";
	};
	this.blocks[179]=function()
	{
		// If TST(1)=D and TST2(7)>-1 : If(TST(8)=D or TST(6)=D) : F1=True : TR0=1 : Goto DAN3 : End If : End If
		this.aoz.sourcePos="430:15";
		if(!(this.vars.TST_array.getValue([1])==this.vars.D&&this.vars.TST2_array.getValue([7])>-1))
			return{type:1,label:181};
		this.aoz.sourcePos="430:44";
		if(!((this.vars.TST_array.getValue([8])==this.vars.D||this.vars.TST_array.getValue([6])==this.vars.D)))
			return{type:1,label:180};
		this.aoz.sourcePos="430:71";
		this.vars.F1=Math.floor(true);
		this.aoz.sourcePos="430:81";
		this.vars.TR0=1;
		this.aoz.sourcePos="430:89";
		return{type:1,label:196};
		this.aoz.sourcePos="430:101";
	};
	this.blocks[180]=function()
	{
		this.aoz.sourcePos="430:110";
	};
	this.blocks[181]=function()
	{
		// If TST(5)=D and TST2(3)>-1 : If(TST(6)=D or TST(0)=D) : F1=True : TR0=2 : Goto DAN3 : End If : End If
		this.aoz.sourcePos="431:15";
		if(!(this.vars.TST_array.getValue([5])==this.vars.D&&this.vars.TST2_array.getValue([3])>-1))
			return{type:1,label:183};
		this.aoz.sourcePos="431:44";
		if(!((this.vars.TST_array.getValue([6])==this.vars.D||this.vars.TST_array.getValue([0])==this.vars.D)))
			return{type:1,label:182};
		this.aoz.sourcePos="431:71";
		this.vars.F1=Math.floor(true);
		this.aoz.sourcePos="431:81";
		this.vars.TR0=2;
		this.aoz.sourcePos="431:89";
		return{type:1,label:196};
		this.aoz.sourcePos="431:101";
	};
	this.blocks[182]=function()
	{
		this.aoz.sourcePos="431:110";
	};
	this.blocks[183]=function()
	{
		// If TST(7)=D and TST2(1)>-1 : If(TST(0)=D or TST(2)=D) : F1=True : TR0=3 : Goto DAN3 : End If : End If
		this.aoz.sourcePos="432:15";
		if(!(this.vars.TST_array.getValue([7])==this.vars.D&&this.vars.TST2_array.getValue([1])>-1))
			return{type:1,label:185};
		this.aoz.sourcePos="432:44";
		if(!((this.vars.TST_array.getValue([0])==this.vars.D||this.vars.TST_array.getValue([2])==this.vars.D)))
			return{type:1,label:184};
		this.aoz.sourcePos="432:71";
		this.vars.F1=Math.floor(true);
		this.aoz.sourcePos="432:81";
		this.vars.TR0=3;
		this.aoz.sourcePos="432:89";
		return{type:1,label:196};
		this.aoz.sourcePos="432:101";
	};
	this.blocks[184]=function()
	{
		this.aoz.sourcePos="432:110";
	};
	this.blocks[185]=function()
	{
		// If TST(3)=D and TST2(5)>-1 : If(TST(2)=D or TST(8)=D) : F1=True : TR0=4 : Goto DAN3 : End If : End If
		this.aoz.sourcePos="433:15";
		if(!(this.vars.TST_array.getValue([3])==this.vars.D&&this.vars.TST2_array.getValue([5])>-1))
			return{type:1,label:187};
		this.aoz.sourcePos="433:44";
		if(!((this.vars.TST_array.getValue([2])==this.vars.D||this.vars.TST_array.getValue([8])==this.vars.D)))
			return{type:1,label:186};
		this.aoz.sourcePos="433:71";
		this.vars.F1=Math.floor(true);
		this.aoz.sourcePos="433:81";
		this.vars.TR0=4;
		this.aoz.sourcePos="433:89";
		return{type:1,label:196};
		this.aoz.sourcePos="433:101";
	};
	this.blocks[186]=function()
	{
		this.aoz.sourcePos="433:110";
	};
	this.blocks[187]=function()
	{
		// If TST(2)=D and TST(8)=D and TST2(5)>-1 : F1=True : TR0=5 : Goto DAN3 : End If
		this.aoz.sourcePos="434:15";
		if(!(this.vars.TST_array.getValue([2])==this.vars.D&&this.vars.TST_array.getValue([8])==this.vars.D&&this.vars.TST2_array.getValue([5])>-1))
			return{type:1,label:188};
		this.aoz.sourcePos="434:57";
		this.vars.F1=Math.floor(true);
		this.aoz.sourcePos="434:67";
		this.vars.TR0=5;
		this.aoz.sourcePos="434:75";
		return{type:1,label:196};
		this.aoz.sourcePos="434:87";
	};
	this.blocks[188]=function()
	{
		// If TST(8)=D and TST(6)=D and TST2(7)>-1 : F1=True : TR0=6 : Goto DAN3 : End If
		this.aoz.sourcePos="435:15";
		if(!(this.vars.TST_array.getValue([8])==this.vars.D&&this.vars.TST_array.getValue([6])==this.vars.D&&this.vars.TST2_array.getValue([7])>-1))
			return{type:1,label:189};
		this.aoz.sourcePos="435:57";
		this.vars.F1=Math.floor(true);
		this.aoz.sourcePos="435:67";
		this.vars.TR0=6;
		this.aoz.sourcePos="435:75";
		return{type:1,label:196};
		this.aoz.sourcePos="435:87";
	};
	this.blocks[189]=function()
	{
		// If TST(6)=D and TST(0)=D and TST2(3)>-1 : F1=True : TR0=7 : Goto DAN3 : End If
		this.aoz.sourcePos="436:15";
		if(!(this.vars.TST_array.getValue([6])==this.vars.D&&this.vars.TST_array.getValue([0])==this.vars.D&&this.vars.TST2_array.getValue([3])>-1))
			return{type:1,label:190};
		this.aoz.sourcePos="436:57";
		this.vars.F1=Math.floor(true);
		this.aoz.sourcePos="436:67";
		this.vars.TR0=7;
		this.aoz.sourcePos="436:75";
		return{type:1,label:196};
		this.aoz.sourcePos="436:87";
	};
	this.blocks[190]=function()
	{
		// If TST(0)=D and TST(2)=D and TST2(1)>-1 : F1=True : TR0=8 : Goto DAN3 : End If
		this.aoz.sourcePos="437:15";
		if(!(this.vars.TST_array.getValue([0])==this.vars.D&&this.vars.TST_array.getValue([2])==this.vars.D&&this.vars.TST2_array.getValue([1])>-1))
			return{type:1,label:191};
		this.aoz.sourcePos="437:57";
		this.vars.F1=Math.floor(true);
		this.aoz.sourcePos="437:67";
		this.vars.TR0=8;
		this.aoz.sourcePos="437:75";
		return{type:1,label:196};
		this.aoz.sourcePos="437:87";
	};
	this.blocks[191]=function()
	{
		// If TST(1)=D and TST(9)=D and TST2(7)>-1 : F1=True : TR0=9 : Goto DAN3 : End If
		this.aoz.sourcePos="439:15";
		if(!(this.vars.TST_array.getValue([1])==this.vars.D&&this.vars.TST_array.getValue([9])==this.vars.D&&this.vars.TST2_array.getValue([7])>-1))
			return{type:1,label:192};
		this.aoz.sourcePos="439:57";
		this.vars.F1=Math.floor(true);
		this.aoz.sourcePos="439:67";
		this.vars.TR0=9;
		this.aoz.sourcePos="439:75";
		return{type:1,label:196};
		this.aoz.sourcePos="439:87";
	};
	this.blocks[192]=function()
	{
		// If TST(3)=D and TST(10)=D and TST2(5)>-1 : F1=True : TR0=10 : Goto DAN3 : End If
		this.aoz.sourcePos="440:15";
		if(!(this.vars.TST_array.getValue([3])==this.vars.D&&this.vars.TST_array.getValue([10])==this.vars.D&&this.vars.TST2_array.getValue([5])>-1))
			return{type:1,label:193};
		this.aoz.sourcePos="440:58";
		this.vars.F1=Math.floor(true);
		this.aoz.sourcePos="440:68";
		this.vars.TR0=10;
		this.aoz.sourcePos="440:77";
		return{type:1,label:196};
		this.aoz.sourcePos="440:89";
	};
	this.blocks[193]=function()
	{
		// If TST(5)=D and TST(12)=D and TST2(3)>-1 : F1=True : TR0=11 : Goto DAN3 : End If
		this.aoz.sourcePos="441:15";
		if(!(this.vars.TST_array.getValue([5])==this.vars.D&&this.vars.TST_array.getValue([12])==this.vars.D&&this.vars.TST2_array.getValue([3])>-1))
			return{type:1,label:194};
		this.aoz.sourcePos="441:58";
		this.vars.F1=Math.floor(true);
		this.aoz.sourcePos="441:68";
		this.vars.TR0=11;
		this.aoz.sourcePos="441:77";
		return{type:1,label:196};
		this.aoz.sourcePos="441:89";
	};
	this.blocks[194]=function()
	{
		// If TST(7)=D and TST(11)=D and TST2(1)>-1 : F1=True : TR0=12 : Goto DAN3 : End If
		this.aoz.sourcePos="442:15";
		if(!(this.vars.TST_array.getValue([7])==this.vars.D&&this.vars.TST_array.getValue([11])==this.vars.D&&this.vars.TST2_array.getValue([1])>-1))
			return{type:1,label:195};
		this.aoz.sourcePos="442:58";
		this.vars.F1=Math.floor(true);
		this.aoz.sourcePos="442:68";
		this.vars.TR0=12;
		this.aoz.sourcePos="442:77";
		return{type:1,label:196};
		this.aoz.sourcePos="442:89";
	};
	this.blocks[195]=function()
	{
	};
	this.blocks[196]=function()
	{
		// DAN3:
		// If F1=True
		this.aoz.sourcePos="445:15";
		if(!(this.vars.F1==true))
			return{type:1,label:197};
		// MOVEPOSS=True
		this.aoz.sourcePos="446:18";
		this.vars.MOVEPOSS=Math.floor(true);
		// locate 0,17
		this.aoz.sourcePos="447:18";
		this.aoz.currentScreen.currentTextWindow.locate({x:0,y:17});
		// print Str$(X)+","+Str$(Y)+"  "
		this.aoz.sourcePos="448:18";
		this.aoz.currentScreen.currentTextWindow.print(this.aoz.str$(this.vars.X)+","+this.aoz.str$(this.vars.Y)+"  ",true);
		// Exit 2
		this.aoz.sourcePos="450:18";
		return{type:1,label:201};
		// End If
		this.aoz.sourcePos="451:15";
	};
	this.blocks[197]=function()
	{
		// End If
		this.aoz.sourcePos="452:12";
	};
	this.blocks[198]=function()
	{
		// End If
		this.aoz.sourcePos="453:9";
	};
	this.blocks[199]=function()
	{
		// Next Y
		this.aoz.sourcePos="454:6";
		this.vars.Y+=1;
		if(this.vars.Y<=this.vars.SIZEY-1)
			return{type:1,label:164}
	};
	this.blocks[200]=function()
	{
		// Next X
		this.aoz.sourcePos="455:3";
		this.vars.X+=1;
		if(this.vars.X<=this.vars.SIZEX-1)
			return{type:1,label:163}
	};
	this.blocks[201]=function()
	{
		// If MOVEPOSS=False
		this.aoz.sourcePos="456:3";
		if(!(this.vars.MOVEPOSS==false))
			return{type:1,label:205};
		// Ink 2,0
		this.aoz.sourcePos="457:6";
		this.aoz.currentScreen.setInk(2,0,);
		// pen 2
		this.aoz.sourcePos="458:6";
		this.aoz.currentScreen.currentTextWindow.setPen(2);
		// locate 10,8
		this.aoz.sourcePos="459:6";
		this.aoz.currentScreen.currentTextWindow.locate({x:10,y:8});
		// print " NO MORE MOVE "
		this.aoz.sourcePos="460:6";
		this.aoz.currentScreen.currentTextWindow.print(" NO MORE MOVE ",true);
		// Wait 100
		this.aoz.sourcePos="462:6";
		return{type:8,instruction:"wait",args:[100]};
	};
	this.blocks[202]=function()
	{
		// Gosub CREATEGRID
		this.aoz.sourcePos="464:6";
		return{type:2,label:450,return:203};
	};
	this.blocks[203]=function()
	{
		// Gosub NEWGRID
		this.aoz.sourcePos="465:6";
		return{type:2,label:207,return:204};
	};
	this.blocks[204]=function()
	{
		// End If
		this.aoz.sourcePos="468:3";
	};
	this.blocks[205]=function()
	{
		// End If
		this.aoz.sourcePos="469:0";
	};
	this.blocks[206]=function()
	{
		// Return
		this.aoz.sourcePos="470:0";
		return{type:3};
	};
	this.blocks[207]=function()
	{
		// NEWGRID:
		// Ink 10,0
		this.aoz.sourcePos="473:0";
		this.aoz.currentScreen.setInk(10,0,);
		// pen 0
		this.aoz.sourcePos="474:0";
		this.aoz.currentScreen.currentTextWindow.setPen(0);
		// locate 1,1 :  print Str$(BIGCOUNT)+"   "
		this.aoz.sourcePos="475:0";
		this.aoz.currentScreen.currentTextWindow.locate({x:1,y:1});
		this.aoz.sourcePos="475:14";
		this.aoz.currentScreen.currentTextWindow.print(this.aoz.str$(this.vars.BIGCOUNT)+"   ",true);
		// locate 1,2 : print Str$(MARKV)+"   "
		this.aoz.sourcePos="476:0";
		this.aoz.currentScreen.currentTextWindow.locate({x:1,y:2});
		this.aoz.sourcePos="476:13";
		this.aoz.currentScreen.currentTextWindow.print(this.aoz.str$(this.vars.MARKV)+"   ",true);
		// locate 120/8,1 : print "level: "+Str$(LEVEL)+"  "
		this.aoz.sourcePos="477:0";
		this.aoz.currentScreen.currentTextWindow.locate({x:120/8,y:1});
		this.aoz.sourcePos="477:17";
		this.aoz.currentScreen.currentTextWindow.print("level: "+this.aoz.str$(this.vars.LEVEL)+"  ",true);
		// locate 120/8,2 : print "score: "+Str$(POANG)+"  "
		this.aoz.sourcePos="478:0";
		this.aoz.currentScreen.currentTextWindow.locate({x:120/8,y:2});
		this.aoz.sourcePos="478:17";
		this.aoz.currentScreen.currentTextWindow.print("score: "+this.aoz.str$(this.vars.POANG)+"  ",true);
		// EMODE$="editboard"
		this.aoz.sourcePos="482:0";
		this.vars.EMODE$="editboard";
		// For Y=0 To SIZEY-1
		this.aoz.sourcePos="483:0";
		this.vars.Y=0;
		if(this.vars.Y>this.vars.SIZEY-1)
			return{type:1,label:213};
	};
	this.blocks[208]=function()
	{
		// For X=0 To SIZEX-1
		this.aoz.sourcePos="484:3";
		this.vars.X=0;
		if(this.vars.X>this.vars.SIZEX-1)
			return{type:1,label:212};
	};
	this.blocks[209]=function()
	{
		// X2=X : Y2=Y
		this.aoz.sourcePos="487:9";
		this.vars.X2=Math.floor(this.vars.X);
		this.aoz.sourcePos="487:16";
		this.vars.Y2=Math.floor(this.vars.Y);
		// GX=X+(OFFSETX/16) : GY=Y+(OFFSETY/16) : GC=KANDY(X,Y,0) : GOFE=0 : Gosub PKANDY
		this.aoz.sourcePos="488:9";
		this.vars.GX=Math.floor(this.vars.X+(this.vars.OFFSETX/16));
		this.aoz.sourcePos="488:29";
		this.vars.GY=Math.floor(this.vars.Y+(this.vars.OFFSETY/16));
		this.aoz.sourcePos="488:49";
		this.vars.GC=Math.floor(this.vars.KANDY_array.getValue([this.vars.X,this.vars.Y,0]));
		this.aoz.sourcePos="488:67";
		this.vars.GOFE=0;
		this.aoz.sourcePos="488:76";
		return{type:2,label:509,return:210};
	};
	this.blocks[210]=function()
	{
		// Wait 1
		this.aoz.sourcePos="490:6";
		return{type:8,instruction:"wait",args:[1]};
	};
	this.blocks[211]=function()
	{
		// Next X
		this.aoz.sourcePos="491:3";
		this.vars.X+=1;
		if(this.vars.X<=this.vars.SIZEX-1)
			return{type:1,label:209}
	};
	this.blocks[212]=function()
	{
		// Next Y
		this.aoz.sourcePos="492:0";
		this.vars.Y+=1;
		if(this.vars.Y<=this.vars.SIZEY-1)
			return{type:1,label:208}
	};
	this.blocks[213]=function()
	{
		// EMODE$="testgame"
		this.aoz.sourcePos="494:0";
		this.vars.EMODE$="testgame";
		// For Y=SIZEY-1 To 0 Step -1
		this.aoz.sourcePos="495:0";
		this.vars.Y=Math.floor(this.vars.SIZEY-1);
		if(this.vars.Y<0)
			return{type:1,label:220};
	};
	this.blocks[214]=function()
	{
		// For X=SIZEX-1 To 0 Step -1
		this.aoz.sourcePos="496:3";
		this.vars.X=Math.floor(this.vars.SIZEX-1);
		if(this.vars.X<0)
			return{type:1,label:219};
	};
	this.blocks[215]=function()
	{
		// If KANDY(X,Y,1)>-1
		this.aoz.sourcePos="497:6";
		if(!(this.vars.KANDY_array.getValue([this.vars.X,this.vars.Y,1])>-1))
			return{type:1,label:217};
		// X2=X : Y2=Y
		this.aoz.sourcePos="499:9";
		this.vars.X2=Math.floor(this.vars.X);
		this.aoz.sourcePos="499:16";
		this.vars.Y2=Math.floor(this.vars.Y);
		// GX=X+(OFFSETX/16) : GY=Y+(OFFSETY/16) : GC=KANDY(X,Y,0) : GOFE=0 : Gosub PKANDY
		this.aoz.sourcePos="500:9";
		this.vars.GX=Math.floor(this.vars.X+(this.vars.OFFSETX/16));
		this.aoz.sourcePos="500:29";
		this.vars.GY=Math.floor(this.vars.Y+(this.vars.OFFSETY/16));
		this.aoz.sourcePos="500:49";
		this.vars.GC=Math.floor(this.vars.KANDY_array.getValue([this.vars.X,this.vars.Y,0]));
		this.aoz.sourcePos="500:67";
		this.vars.GOFE=0;
		this.aoz.sourcePos="500:76";
		return{type:2,label:509,return:216};
	};
	this.blocks[216]=function()
	{
		// End If
		this.aoz.sourcePos="501:6";
	};
	this.blocks[217]=function()
	{
		// Wait 1
		this.aoz.sourcePos="502:6";
		return{type:8,instruction:"wait",args:[1]};
	};
	this.blocks[218]=function()
	{
		// Next X
		this.aoz.sourcePos="503:3";
		this.vars.X+=-1;
		if(this.vars.X>=0)
			return{type:1,label:215}
	};
	this.blocks[219]=function()
	{
		// Next Y
		this.aoz.sourcePos="504:0";
		this.vars.Y+=-1;
		if(this.vars.Y>=0)
			return{type:1,label:214}
	};
	this.blocks[220]=function()
	{
		// Return
		this.aoz.sourcePos="506:0";
		return{type:3};
	};
	this.blocks[221]=function()
	{
		// ANMOVE:
		// C=KANDY(MARKUPX,MARKUPY,0)
		this.aoz.sourcePos="510:0";
		this.vars.C=Math.floor(this.vars.KANDY_array.getValue([this.vars.MARKUPX,this.vars.MARKUPY,0]));
		// C2=KANDY(MARKX,MARKY,0)
		this.aoz.sourcePos="511:0";
		this.vars.C2=Math.floor(this.vars.KANDY_array.getValue([this.vars.MARKX,this.vars.MARKY,0]));
		// If C>10 : C=C+1 : End If
		this.aoz.sourcePos="513:0";
		if(!(this.vars.C>10))
			return{type:1,label:222};
		this.aoz.sourcePos="513:10";
		this.vars.C=Math.floor(this.vars.C+1);
		this.aoz.sourcePos="513:18";
	};
	this.blocks[222]=function()
	{
		// If C2>10 : C2=C2+1 : End If
		this.aoz.sourcePos="514:0";
		if(!(this.vars.C2>10))
			return{type:1,label:223};
		this.aoz.sourcePos="514:11";
		this.vars.C2=Math.floor(this.vars.C2+1);
		this.aoz.sourcePos="514:21";
	};
	this.blocks[223]=function()
	{
		// MX1=0 : MY1=0 : MX2=0 : MY2=0
		this.aoz.sourcePos="518:0";
		this.vars.MX1=0;
		this.aoz.sourcePos="518:8";
		this.vars.MY1=0;
		this.aoz.sourcePos="518:16";
		this.vars.MX2=0;
		this.aoz.sourcePos="518:24";
		this.vars.MY2=0;
		// If MARKUPX<MARKX : MX1=-2 : MX2=2
		this.aoz.sourcePos="519:0";
		if(!(this.vars.MARKUPX<this.vars.MARKX))
			return{type:1,label:224};
		this.aoz.sourcePos="519:19";
		this.vars.MX1=-2;
		this.aoz.sourcePos="519:28";
		this.vars.MX2=2;
		// Else
		return{type:1,label:226};
	};
	this.blocks[224]=function()
	{
		// If MARKX<MARKUPX
		this.aoz.sourcePos="521:3";
		if(!(this.vars.MARKX<this.vars.MARKUPX))
			return{type:1,label:225};
		// MX1=2 : MX2=-2
		this.aoz.sourcePos="522:6";
		this.vars.MX1=2;
		this.aoz.sourcePos="522:14";
		this.vars.MX2=-2;
		// End If
		this.aoz.sourcePos="523:3";
	};
	this.blocks[225]=function()
	{
		// End If
		this.aoz.sourcePos="524:0";
	};
	this.blocks[226]=function()
	{
		// If MARKUPY<MARKY : MY1=-2 : MY2=2
		this.aoz.sourcePos="525:0";
		if(!(this.vars.MARKUPY<this.vars.MARKY))
			return{type:1,label:227};
		this.aoz.sourcePos="525:19";
		this.vars.MY1=-2;
		this.aoz.sourcePos="525:28";
		this.vars.MY2=2;
		// Else
		return{type:1,label:229};
	};
	this.blocks[227]=function()
	{
		// If MARKY<MARKUPY
		this.aoz.sourcePos="527:3";
		if(!(this.vars.MARKY<this.vars.MARKUPY))
			return{type:1,label:228};
		// MY1=2 : MY2=-2
		this.aoz.sourcePos="528:6";
		this.vars.MY1=2;
		this.aoz.sourcePos="528:14";
		this.vars.MY2=-2;
		// End If
		this.aoz.sourcePos="529:3";
	};
	this.blocks[228]=function()
	{
		// End If
		this.aoz.sourcePos="530:0";
	};
	this.blocks[229]=function()
	{
		// B2=9
		this.aoz.sourcePos="532:0";
		this.vars.B2=9;
		// B=KANDY(MARKUPX,MARKUPY,1)
		this.aoz.sourcePos="533:0";
		this.vars.B=Math.floor(this.vars.KANDY_array.getValue([this.vars.MARKUPX,this.vars.MARKUPY,1]));
		// Screen 0
		this.aoz.sourcePos="535:0";
		this.aoz.setScreen(0);
		// Get Bob 28,B*16,B2*16 To B*16+16,B2*16+16
		this.aoz.sourcePos="537:0";
		this.aoz.currentScreen.getBob(28,{x:this.vars.B*16,y:this.vars.B2*16,width:(this.vars.B*16+16)-(this.vars.B*16),height:(this.vars.B2*16+16)-(this.vars.B2*16)},undefined);
		// B3=KANDY(MARKX,MARKY,1)
		this.aoz.sourcePos="539:0";
		this.vars.B3=Math.floor(this.vars.KANDY_array.getValue([this.vars.MARKX,this.vars.MARKY,1]));
		// Get Bob 29,B3*16,B2*16 To B3*16+16,B2*16+16
		this.aoz.sourcePos="541:0";
		this.aoz.currentScreen.getBob(29,{x:this.vars.B3*16,y:this.vars.B2*16,width:(this.vars.B3*16+16)-(this.vars.B3*16),height:(this.vars.B2*16+16)-(this.vars.B2*16)},undefined);
		// Screen 1
		this.aoz.sourcePos="543:0";
		this.aoz.setScreen(1);
		// For AN=0 To 7
		this.aoz.sourcePos="545:0";
		this.vars.AN=0;
		if(this.vars.AN>7)
			return{type:1,label:233};
	};
	this.blocks[230]=function()
	{
		// Paste Bob MARKUPX*16+OFFSETX,MARKUPY*16+OFFSETY,28
		this.aoz.sourcePos="549:3";
		this.aoz.currentScreen.pasteBob(28,this.vars.MARKUPX*16+this.vars.OFFSETX,this.vars.MARKUPY*16+this.vars.OFFSETY,undefined,undefined,undefined*this.aoz.degreeRadian,);
		// Paste Bob MARKX*16+OFFSETX,MARKY*16+OFFSETY,29
		this.aoz.sourcePos="553:3";
		this.aoz.currentScreen.pasteBob(29,this.vars.MARKX*16+this.vars.OFFSETX,this.vars.MARKY*16+this.vars.OFFSETY,undefined,undefined,undefined*this.aoz.degreeRadian,);
		// Javascript
		this.aoz.currentScreen.context.globalAlpha=0.7; 
		// End Javascript
		// Paste Bob MARKX*16+OFFSETX-(MX2*AN)+1,MARKY*16+OFFSETY-(MY2*AN)+1,C
		this.aoz.sourcePos="556:3";
		this.aoz.currentScreen.pasteBob(this.vars.C,this.vars.MARKX*16+this.vars.OFFSETX-(this.vars.MX2*this.vars.AN)+1,this.vars.MARKY*16+this.vars.OFFSETY-(this.vars.MY2*this.vars.AN)+1,undefined,undefined,undefined*this.aoz.degreeRadian,);
		// Paste Bob MARKUPX*16+OFFSETX-(MX1*AN)+1,MARKUPY*16+OFFSETY-(MY1*AN)+1,C2
		this.aoz.sourcePos="558:3";
		this.aoz.currentScreen.pasteBob(this.vars.C2,this.vars.MARKUPX*16+this.vars.OFFSETX-(this.vars.MX1*this.vars.AN)+1,this.vars.MARKUPY*16+this.vars.OFFSETY-(this.vars.MY1*this.vars.AN)+1,undefined,undefined,undefined*this.aoz.degreeRadian,);
		// Javascript
		this.aoz.currentScreen.context.globalAlpha=1; 
		// End Javascript
		// Wait Vbl
		this.aoz.sourcePos="561:3";
		return{type:8,instruction:"waitVbl",args:[]};
	};
	this.blocks[231]=function()
	{
		// Wait 1
		this.aoz.sourcePos="562:3";
		return{type:8,instruction:"wait",args:[1]};
	};
	this.blocks[232]=function()
	{
		// Next AN
		this.aoz.sourcePos="564:0";
		this.vars.AN+=1;
		if(this.vars.AN<=7)
			return{type:1,label:230}
	};
	this.blocks[233]=function()
	{
		// Return
		this.aoz.sourcePos="566:0";
		return{type:3};
	};
	this.blocks[234]=function()
	{
		// BONUS1:
		// If KANDY(MARKUPX,MARKUPY,0)>20
		this.aoz.sourcePos="569:0";
		if(!(this.vars.KANDY_array.getValue([this.vars.MARKUPX,this.vars.MARKUPY,0])>20))
			return{type:1,label:236};
		// DKAND=KANDY(MARKX,MARKY,0)
		this.aoz.sourcePos="570:3";
		this.vars.DKAND=Math.floor(this.vars.KANDY_array.getValue([this.vars.MARKX,this.vars.MARKY,0]));
		// KANDY(MARKUPX,MARKUPY,0)=-1
		this.aoz.sourcePos="571:3";
		this.vars.KANDY_array.setValue([this.vars.MARKUPX,this.vars.MARKUPY,0],-1);
		// KANDY(MARKUPX,MARKUPY,3)=4
		this.aoz.sourcePos="572:3";
		this.vars.KANDY_array.setValue([this.vars.MARKUPX,this.vars.MARKUPY,3],4);
		// MOV(MARKUPX,MARKUPY)=1
		this.aoz.sourcePos="573:3";
		this.vars.MOV_array.setValue([this.vars.MARKUPX,this.vars.MARKUPY],1);
		// MOV(MARKX,MARKY)=1
		this.aoz.sourcePos="574:3";
		this.vars.MOV_array.setValue([this.vars.MARKX,this.vars.MARKY],1);
		// If KANDY(MARKUPX,MARKUPY,1)>0 : KANDY(MARKUPX,MARKUPY,1)=KANDY(MARKUPX,MARKUPY,1)-1 : End If
		this.aoz.sourcePos="575:3";
		if(!(this.vars.KANDY_array.getValue([this.vars.MARKUPX,this.vars.MARKUPY,1])>0))
			return{type:1,label:235};
		this.aoz.sourcePos="575:35";
		this.vars.KANDY_array.setValue([this.vars.MARKUPX,this.vars.MARKUPY,1],Math.floor(this.vars.KANDY_array.getValue([this.vars.MARKUPX,this.vars.MARKUPY,1])-1));
		this.aoz.sourcePos="575:89";
	};
	this.blocks[235]=function()
	{
		// Else
		return{type:1,label:238};
	};
	this.blocks[236]=function()
	{
		// DKAND=KANDY(MARKUPX,MARKUPY,0)
		this.aoz.sourcePos="577:3";
		this.vars.DKAND=Math.floor(this.vars.KANDY_array.getValue([this.vars.MARKUPX,this.vars.MARKUPY,0]));
		// KANDY(MARKX,MARKY,0)=-1
		this.aoz.sourcePos="578:3";
		this.vars.KANDY_array.setValue([this.vars.MARKX,this.vars.MARKY,0],-1);
		// KANDY(MARKX,MARKY,3)=4
		this.aoz.sourcePos="579:3";
		this.vars.KANDY_array.setValue([this.vars.MARKX,this.vars.MARKY,3],4);
		// MOV(MARKUPX,MARKUPY)=1
		this.aoz.sourcePos="580:3";
		this.vars.MOV_array.setValue([this.vars.MARKUPX,this.vars.MARKUPY],1);
		// MOV(MARKX,MARKY)=1
		this.aoz.sourcePos="581:3";
		this.vars.MOV_array.setValue([this.vars.MARKX,this.vars.MARKY],1);
		// If KANDY(MARKX,MARKY,1)>0 : KANDY(MARKX,MARKY,1)=KANDY(MARKX,MARKY,1)-1 : End If
		this.aoz.sourcePos="582:3";
		if(!(this.vars.KANDY_array.getValue([this.vars.MARKX,this.vars.MARKY,1])>0))
			return{type:1,label:237};
		this.aoz.sourcePos="582:31";
		this.vars.KANDY_array.setValue([this.vars.MARKX,this.vars.MARKY,1],Math.floor(this.vars.KANDY_array.getValue([this.vars.MARKX,this.vars.MARKY,1])-1));
		this.aoz.sourcePos="582:77";
	};
	this.blocks[237]=function()
	{
		// End If
		this.aoz.sourcePos="583:0";
	};
	this.blocks[238]=function()
	{
		// Return
		this.aoz.sourcePos="585:0";
		return{type:3};
	};
	this.blocks[239]=function()
	{
		// DELKANDY:
		// For X=0 To SIZEX-1
		this.aoz.sourcePos="588:0";
		this.vars.X=0;
		if(this.vars.X>this.vars.SIZEX-1)
			return{type:1,label:245};
	};
	this.blocks[240]=function()
	{
		// For Y=0 To SIZEY-1
		this.aoz.sourcePos="589:3";
		this.vars.Y=0;
		if(this.vars.Y>this.vars.SIZEY-1)
			return{type:1,label:244};
	};
	this.blocks[241]=function()
	{
		// If KANDY(X,Y,0)=DKAND
		this.aoz.sourcePos="590:6";
		if(!(this.vars.KANDY_array.getValue([this.vars.X,this.vars.Y,0])==this.vars.DKAND))
			return{type:1,label:243};
		// KANDY(X,Y,0)=-1
		this.aoz.sourcePos="593:9";
		this.vars.KANDY_array.setValue([this.vars.X,this.vars.Y,0],-1);
		// KANDY(X,Y,3)=4
		this.aoz.sourcePos="594:9";
		this.vars.KANDY_array.setValue([this.vars.X,this.vars.Y,3],4);
		// MOV(X,Y)=1
		this.aoz.sourcePos="595:9";
		this.vars.MOV_array.setValue([this.vars.X,this.vars.Y],1);
		// If KANDY(X,Y,1)>0 : KANDY(X,Y,1)=KANDY(X,Y,1)-1 : End If
		this.aoz.sourcePos="596:9";
		if(!(this.vars.KANDY_array.getValue([this.vars.X,this.vars.Y,1])>0))
			return{type:1,label:242};
		this.aoz.sourcePos="596:29";
		this.vars.KANDY_array.setValue([this.vars.X,this.vars.Y,1],Math.floor(this.vars.KANDY_array.getValue([this.vars.X,this.vars.Y,1])-1));
		this.aoz.sourcePos="596:59";
	};
	this.blocks[242]=function()
	{
		// End If
		this.aoz.sourcePos="597:6";
	};
	this.blocks[243]=function()
	{
		// Next Y
		this.aoz.sourcePos="598:3";
		this.vars.Y+=1;
		if(this.vars.Y<=this.vars.SIZEY-1)
			return{type:1,label:241}
	};
	this.blocks[244]=function()
	{
		// Next X
		this.aoz.sourcePos="599:0";
		this.vars.X+=1;
		if(this.vars.X<=this.vars.SIZEX-1)
			return{type:1,label:240}
	};
	this.blocks[245]=function()
	{
		// Return
		this.aoz.sourcePos="600:0";
		return{type:3};
	};
	this.blocks[246]=function()
	{
		// SGRID:
		// For X=0 To SIZEX-1
		this.aoz.sourcePos="603:0";
		this.vars.X=0;
		if(this.vars.X>this.vars.SIZEX-1)
			return{type:1,label:252};
	};
	this.blocks[247]=function()
	{
		// For Y=0 To SIZEY-1
		this.aoz.sourcePos="604:3";
		this.vars.Y=0;
		if(this.vars.Y>this.vars.SIZEY-1)
			return{type:1,label:251};
	};
	this.blocks[248]=function()
	{
		// For T=0 To 2
		this.aoz.sourcePos="605:6";
		this.vars.T=0;
		if(this.vars.T>2)
			return{type:1,label:250};
	};
	this.blocks[249]=function()
	{
		// SAD(X,Y,T)=KANDY(X,Y,T)
		this.aoz.sourcePos="606:9";
		this.vars.SAD_array.setValue([this.vars.X,this.vars.Y,this.vars.T],Math.floor(this.vars.KANDY_array.getValue([this.vars.X,this.vars.Y,this.vars.T])));
		// Next
		this.aoz.sourcePos="607:6";
		this.vars.T+=1;
		if(this.vars.T<=2)
			return{type:1,label:249}
	};
	this.blocks[250]=function()
	{
		// Next Y
		this.aoz.sourcePos="608:3";
		this.vars.Y+=1;
		if(this.vars.Y<=this.vars.SIZEY-1)
			return{type:1,label:248}
	};
	this.blocks[251]=function()
	{
		// Next X
		this.aoz.sourcePos="609:0";
		this.vars.X+=1;
		if(this.vars.X<=this.vars.SIZEX-1)
			return{type:1,label:247}
	};
	this.blocks[252]=function()
	{
		// Return
		this.aoz.sourcePos="610:0";
		return{type:3};
	};
	this.blocks[253]=function()
	{
		// CANCELGRID:
		// For X=0 To SIZEX-1
		this.aoz.sourcePos="613:0";
		this.vars.X=0;
		if(this.vars.X>this.vars.SIZEX-1)
			return{type:1,label:259};
	};
	this.blocks[254]=function()
	{
		// For Y=0 To SIZEY-1
		this.aoz.sourcePos="614:3";
		this.vars.Y=0;
		if(this.vars.Y>this.vars.SIZEY-1)
			return{type:1,label:258};
	};
	this.blocks[255]=function()
	{
		// For T=0 To 2
		this.aoz.sourcePos="615:6";
		this.vars.T=0;
		if(this.vars.T>2)
			return{type:1,label:257};
	};
	this.blocks[256]=function()
	{
		// KANDY(X,Y,T)=SAD(X,Y,T)
		this.aoz.sourcePos="616:9";
		this.vars.KANDY_array.setValue([this.vars.X,this.vars.Y,this.vars.T],Math.floor(this.vars.SAD_array.getValue([this.vars.X,this.vars.Y,this.vars.T])));
		// Next T
		this.aoz.sourcePos="617:6";
		this.vars.T+=1;
		if(this.vars.T<=2)
			return{type:1,label:256}
	};
	this.blocks[257]=function()
	{
		// Next Y
		this.aoz.sourcePos="618:3";
		this.vars.Y+=1;
		if(this.vars.Y<=this.vars.SIZEY-1)
			return{type:1,label:255}
	};
	this.blocks[258]=function()
	{
		// Next X
		this.aoz.sourcePos="619:0";
		this.vars.X+=1;
		if(this.vars.X<=this.vars.SIZEX-1)
			return{type:1,label:254}
	};
	this.blocks[259]=function()
	{
		// Return
		this.aoz.sourcePos="620:0";
		return{type:3};
	};
	this.blocks[260]=function()
	{
		// MOVEKANDY:
		// MOVN=0
		this.aoz.sourcePos="625:0";
		this.vars.MOVN=0;
		// For X=SIZEX-1 To 0 Step -1
		this.aoz.sourcePos="626:0";
		this.vars.X=Math.floor(this.vars.SIZEX-1);
		if(this.vars.X<0)
			return{type:1,label:267};
	};
	this.blocks[261]=function()
	{
		// For Y=SIZEY-1 To 0 Step -1
		this.aoz.sourcePos="627:3";
		this.vars.Y=Math.floor(this.vars.SIZEY-1);
		if(this.vars.Y<0)
			return{type:1,label:266};
	};
	this.blocks[262]=function()
	{
		// If KANDY(X,Y,0)=-1
		this.aoz.sourcePos="628:6";
		if(!(this.vars.KANDY_array.getValue([this.vars.X,this.vars.Y,0])==-1))
			return{type:1,label:265};
		// KR=0
		this.aoz.sourcePos="629:9";
		this.vars.KR=0;
		// MOVX(MOVN)=X : MOVY(MOVN)=Y-1
		this.aoz.sourcePos="630:9";
		this.vars.MOVX_array.setValue([this.vars.MOVN],Math.floor(this.vars.X));
		this.aoz.sourcePos="630:24";
		this.vars.MOVY_array.setValue([this.vars.MOVN],Math.floor(this.vars.Y-1));
		// For T=Y-1 To 0 Step -1
		this.aoz.sourcePos="631:9";
		this.vars.T=Math.floor(this.vars.Y-1);
		if(this.vars.T<0)
			return{type:1,label:264};
	};
	this.blocks[263]=function()
	{
		// KR=KR+1
		this.aoz.sourcePos="632:12";
		this.vars.KR=Math.floor(this.vars.KR+1);
		// Next T
		this.aoz.sourcePos="633:9";
		this.vars.T+=-1;
		if(this.vars.T>=0)
			return{type:1,label:263}
	};
	this.blocks[264]=function()
	{
		// MOVS(MOVN)=KR
		this.aoz.sourcePos="634:9";
		this.vars.MOVS_array.setValue([this.vars.MOVN],Math.floor(this.vars.KR));
		// MOVN=MOVN+1
		this.aoz.sourcePos="635:9";
		this.vars.MOVN=Math.floor(this.vars.MOVN+1);
		// Exit
		this.aoz.sourcePos="636:9";
		return{type:1,label:266};
		// End If
		this.aoz.sourcePos="637:6";
	};
	this.blocks[265]=function()
	{
		// Next Y
		this.aoz.sourcePos="638:3";
		this.vars.Y+=-1;
		if(this.vars.Y>=0)
			return{type:1,label:262}
	};
	this.blocks[266]=function()
	{
		// Next X
		this.aoz.sourcePos="639:0";
		this.vars.X+=-1;
		if(this.vars.X>=0)
			return{type:1,label:261}
	};
	this.blocks[267]=function()
	{
		// If MOVN>0
		this.aoz.sourcePos="641:0";
		if(!(this.vars.MOVN>0))
			return{type:1,label:281};
		// For A=2 To 16 Step 4
		this.aoz.sourcePos="642:3";
		this.vars.A=2;
		if(this.vars.A>16)
			return{type:1,label:280};
	};
	this.blocks[268]=function()
	{
		// K=A
		this.aoz.sourcePos="643:6";
		this.vars.K=Math.floor(this.vars.A);
		// For C=0 To MOVN-1
		this.aoz.sourcePos="644:6";
		this.vars.C=0;
		if(this.vars.C>this.vars.MOVN-1)
			return{type:1,label:278};
	};
	this.blocks[269]=function()
	{
		// X=MOVX(C)
		this.aoz.sourcePos="645:9";
		this.vars.X=Math.floor(this.vars.MOVX_array.getValue([this.vars.C]));
		// If MOVY(C)>-1
		this.aoz.sourcePos="646:9";
		if(!(this.vars.MOVY_array.getValue([this.vars.C])>-1))
			return{type:1,label:277};
		// STX=-1
		this.aoz.sourcePos="647:12";
		this.vars.STX=-1;
		// For T=MOVY(C) To 0 Step -1
		this.aoz.sourcePos="648:12";
		this.vars.T=Math.floor(this.vars.MOVY_array.getValue([this.vars.C]));
		if(this.vars.T<0)
			return{type:1,label:274};
	};
	this.blocks[270]=function()
	{
		// If KANDY(X,T,1)>-1
		this.aoz.sourcePos="649:15";
		if(!(this.vars.KANDY_array.getValue([this.vars.X,this.vars.T,1])>-1))
			return{type:1,label:272};
		// X2=X : Y2=T
		this.aoz.sourcePos="651:18";
		this.vars.X2=Math.floor(this.vars.X);
		this.aoz.sourcePos="651:25";
		this.vars.Y2=Math.floor(this.vars.T);
		// GX=X+(OFFSETX/16) : GY=T+(OFFSETY/16) : GC=KANDY(X,T,0) : GOFE=K : Gosub PKANDY
		this.aoz.sourcePos="652:18";
		this.vars.GX=Math.floor(this.vars.X+(this.vars.OFFSETX/16));
		this.aoz.sourcePos="652:38";
		this.vars.GY=Math.floor(this.vars.T+(this.vars.OFFSETY/16));
		this.aoz.sourcePos="652:58";
		this.vars.GC=Math.floor(this.vars.KANDY_array.getValue([this.vars.X,this.vars.T,0]));
		this.aoz.sourcePos="652:76";
		this.vars.GOFE=Math.floor(this.vars.K);
		this.aoz.sourcePos="652:85";
		return{type:2,label:509,return:271};
	};
	this.blocks[271]=function()
	{
		// Else
		return{type:1,label:273};
	};
	this.blocks[272]=function()
	{
		// STX=X : STY=T
		this.aoz.sourcePos="654:18";
		this.vars.STX=Math.floor(this.vars.X);
		this.aoz.sourcePos="654:26";
		this.vars.STY=Math.floor(this.vars.T);
		// End If
		this.aoz.sourcePos="655:15";
	};
	this.blocks[273]=function()
	{
		// Next T
		this.aoz.sourcePos="656:12";
		this.vars.T+=-1;
		if(this.vars.T>=0)
			return{type:1,label:270}
	};
	this.blocks[274]=function()
	{
		// If STX>-1
		this.aoz.sourcePos="657:12";
		if(!(this.vars.STX>-1))
			return{type:1,label:276};
		// X2=STX : Y2=STY
		this.aoz.sourcePos="659:15";
		this.vars.X2=Math.floor(this.vars.STX);
		this.aoz.sourcePos="659:24";
		this.vars.Y2=Math.floor(this.vars.STY);
		// GX=STX+(OFFSETX/16) : GY=STY+(OFFSETY/16) : GC=KANDY(STX,STY,0) : GOFE=0 : Gosub PKANDY
		this.aoz.sourcePos="660:15";
		this.vars.GX=Math.floor(this.vars.STX+(this.vars.OFFSETX/16));
		this.aoz.sourcePos="660:37";
		this.vars.GY=Math.floor(this.vars.STY+(this.vars.OFFSETY/16));
		this.aoz.sourcePos="660:59";
		this.vars.GC=Math.floor(this.vars.KANDY_array.getValue([this.vars.STX,this.vars.STY,0]));
		this.aoz.sourcePos="660:81";
		this.vars.GOFE=0;
		this.aoz.sourcePos="660:90";
		return{type:2,label:509,return:275};
	};
	this.blocks[275]=function()
	{
		// End If
		this.aoz.sourcePos="661:12";
	};
	this.blocks[276]=function()
	{
		// End If
		this.aoz.sourcePos="662:9";
	};
	this.blocks[277]=function()
	{
		// Next C
		this.aoz.sourcePos="663:6";
		this.vars.C+=1;
		if(this.vars.C<=this.vars.MOVN-1)
			return{type:1,label:269}
	};
	this.blocks[278]=function()
	{
		// Wait 1
		this.aoz.sourcePos="665:6";
		return{type:8,instruction:"wait",args:[1]};
	};
	this.blocks[279]=function()
	{
		// Next A
		this.aoz.sourcePos="666:3";
		this.vars.A+=4;
		if(this.vars.A<=16)
			return{type:1,label:268}
	};
	this.blocks[280]=function()
	{
		// End If
		this.aoz.sourcePos="667:0";
	};
	this.blocks[281]=function()
	{
	};
	this.blocks[282]=function()
	{
		// URKA:
		// For X=SIZEX-1 To 0 Step -1
		this.aoz.sourcePos="672:0";
		this.vars.X=Math.floor(this.vars.SIZEX-1);
		if(this.vars.X<0)
			return{type:1,label:308};
	};
	this.blocks[283]=function()
	{
		// For Y=SIZEY-1 To 0 Step -1
		this.aoz.sourcePos="673:3";
		this.vars.Y=Math.floor(this.vars.SIZEY-1);
		if(this.vars.Y<0)
			return{type:1,label:307};
	};
	this.blocks[284]=function()
	{
		// D=KANDY(X,Y,0) : MX=X : MY=Y
		this.aoz.sourcePos="674:6";
		this.vars.D=Math.floor(this.vars.KANDY_array.getValue([this.vars.X,this.vars.Y,0]));
		this.aoz.sourcePos="674:23";
		this.vars.MX=Math.floor(this.vars.X);
		this.aoz.sourcePos="674:30";
		this.vars.MY=Math.floor(this.vars.Y);
		// If D=-1
		this.aoz.sourcePos="675:6";
		if(!(this.vars.D==-1))
			return{type:1,label:294};
		// T=Y-1
		this.aoz.sourcePos="676:9";
		this.vars.T=Math.floor(this.vars.Y-1);
		// repeat
		this.aoz.sourcePos="677:9";
	};
	this.blocks[285]=function()
	{
		// MY=T
		this.aoz.sourcePos="679:12";
		this.vars.MY=Math.floor(this.vars.T);
	};
	this.blocks[286]=function()
	{
		// LP2:
		// If T>0
		this.aoz.sourcePos="681:12";
		if(!(this.vars.T>0))
			return{type:1,label:288};
		// If KANDY(X,T,1)=-1 : T=T-1 : Goto LP2 : End If
		this.aoz.sourcePos="682:15";
		if(!(this.vars.KANDY_array.getValue([this.vars.X,this.vars.T,1])==-1))
			return{type:1,label:287};
		this.aoz.sourcePos="682:36";
		this.vars.T=Math.floor(this.vars.T-1);
		this.aoz.sourcePos="682:44";
		return{type:1,label:286};
		this.aoz.sourcePos="682:55";
	};
	this.blocks[287]=function()
	{
		// End If
		this.aoz.sourcePos="683:12";
	};
	this.blocks[288]=function()
	{
		// If T>0
		this.aoz.sourcePos="684:12";
		if(!(this.vars.T>0))
			return{type:1,label:289};
		// KANDY(X,MY+1,0)=KANDY(X,T,0)
		this.aoz.sourcePos="685:15";
		this.vars.KANDY_array.setValue([this.vars.X,this.vars.MY+1,0],Math.floor(this.vars.KANDY_array.getValue([this.vars.X,this.vars.T,0])));
		// MOV(X,MY+1)=1
		this.aoz.sourcePos="686:15";
		this.vars.MOV_array.setValue([this.vars.X,this.vars.MY+1],1);
		// Else
		return{type:1,label:292};
	};
	this.blocks[289]=function()
	{
		// If T<0
		this.aoz.sourcePos="688:15";
		if(!(this.vars.T<0))
			return{type:1,label:290};
		// KANDY(X,MY+1,0)=Rnd(5)+1
		this.aoz.sourcePos="689:18";
		this.vars.KANDY_array.setValue([this.vars.X,this.vars.MY+1,0],Math.floor(this.aoz.rnd(5)+1));
		// Else
		return{type:1,label:291};
	};
	this.blocks[290]=function()
	{
		// KANDY(X,MY+1,0)=KANDY(X,T,0)
		this.aoz.sourcePos="691:18";
		this.vars.KANDY_array.setValue([this.vars.X,this.vars.MY+1,0],Math.floor(this.vars.KANDY_array.getValue([this.vars.X,this.vars.T,0])));
		// KANDY(X,MY,0)=Rnd(5)+1
		this.aoz.sourcePos="692:18";
		this.vars.KANDY_array.setValue([this.vars.X,this.vars.MY,0],Math.floor(this.aoz.rnd(5)+1));
		// MOV(X,MY)=1
		this.aoz.sourcePos="693:18";
		this.vars.MOV_array.setValue([this.vars.X,this.vars.MY],1);
		// End If
		this.aoz.sourcePos="694:15";
	};
	this.blocks[291]=function()
	{
		// MOV(X,MY+1)=1
		this.aoz.sourcePos="695:15";
		this.vars.MOV_array.setValue([this.vars.X,this.vars.MY+1],1);
		// End If
		this.aoz.sourcePos="696:12";
	};
	this.blocks[292]=function()
	{
		// T=T-1
		this.aoz.sourcePos="697:12";
		this.vars.T=Math.floor(this.vars.T-1);
		// until T<0
		this.aoz.sourcePos="698:9";
		if(!(this.vars.T<0))
			return{type:1,label:285};
	};
	this.blocks[293]=function()
	{
		// Exit
		this.aoz.sourcePos="703:9";
		return{type:1,label:307};
		// Else
		return{type:1,label:295};
	};
	this.blocks[294]=function()
	{
		// End If
		this.aoz.sourcePos="705:6";
	};
	this.blocks[295]=function()
	{
		// If D=-2
		this.aoz.sourcePos="707:6";
		if(!(this.vars.D==-2))
			return{type:1,label:306};
		// For X2=X-1 To X+1
		this.aoz.sourcePos="708:9";
		this.vars.X2=Math.floor(this.vars.X-1);
		if(this.vars.X2>this.vars.X+1)
			return{type:1,label:305};
	};
	this.blocks[296]=function()
	{
		// For Y2=Y-1 To Y+1
		this.aoz.sourcePos="709:12";
		this.vars.Y2=Math.floor(this.vars.Y-1);
		if(this.vars.Y2>this.vars.Y+1)
			return{type:1,label:304};
	};
	this.blocks[297]=function()
	{
		// If X2>-1 and Y2>-1 and X2<SIZEX and Y2<SIZEY
		this.aoz.sourcePos="710:15";
		if(!(this.vars.X2>-1&&this.vars.Y2>-1&&this.vars.X2<this.vars.SIZEX&&this.vars.Y2<this.vars.SIZEY))
			return{type:1,label:303};
		// If KANDY(X2,Y2,0)>10 and KANDY(X2,Y2,1)>-1
		this.aoz.sourcePos="711:18";
		if(!(this.vars.KANDY_array.getValue([this.vars.X2,this.vars.Y2,0])>10&&this.vars.KANDY_array.getValue([this.vars.X2,this.vars.Y2,1])>-1))
			return{type:1,label:299};
		// KANDY(X2,Y2,0)=-2
		this.aoz.sourcePos="712:21";
		this.vars.KANDY_array.setValue([this.vars.X2,this.vars.Y2,0],-2);
		// KANDY(X2,Y2,3)=4 : POANG=POANG+10
		this.aoz.sourcePos="713:21";
		this.vars.KANDY_array.setValue([this.vars.X2,this.vars.Y2,3],4);
		this.aoz.sourcePos="713:40";
		this.vars.POANG=Math.floor(this.vars.POANG+10);
		// MOV(X2,Y2)=1
		this.aoz.sourcePos="714:21";
		this.vars.MOV_array.setValue([this.vars.X2,this.vars.Y2],1);
		// If KANDY(X2,Y2,1)>0 : KANDY(X2,Y2,1)=KANDY(X2,Y2,1)-1 : End If
		this.aoz.sourcePos="715:21";
		if(!(this.vars.KANDY_array.getValue([this.vars.X2,this.vars.Y2,1])>0))
			return{type:1,label:298};
		this.aoz.sourcePos="715:43";
		this.vars.KANDY_array.setValue([this.vars.X2,this.vars.Y2,1],Math.floor(this.vars.KANDY_array.getValue([this.vars.X2,this.vars.Y2,1])-1));
		this.aoz.sourcePos="715:77";
	};
	this.blocks[298]=function()
	{
		// Else
		return{type:1,label:302};
	};
	this.blocks[299]=function()
	{
		// If KANDY(X2,Y2,1)>-1
		this.aoz.sourcePos="717:21";
		if(!(this.vars.KANDY_array.getValue([this.vars.X2,this.vars.Y2,1])>-1))
			return{type:1,label:301};
		// KANDY(X2,Y2,0)=-1
		this.aoz.sourcePos="718:24";
		this.vars.KANDY_array.setValue([this.vars.X2,this.vars.Y2,0],-1);
		// KANDY(X2,Y2,3)=4 : POANG=POANG+10
		this.aoz.sourcePos="719:24";
		this.vars.KANDY_array.setValue([this.vars.X2,this.vars.Y2,3],4);
		this.aoz.sourcePos="719:43";
		this.vars.POANG=Math.floor(this.vars.POANG+10);
		// MOV(X2,Y2)=1
		this.aoz.sourcePos="720:24";
		this.vars.MOV_array.setValue([this.vars.X2,this.vars.Y2],1);
		// If KANDY(X2,Y2,1)>0 : KANDY(X2,Y2,1)=KANDY(X2,Y2,1)-1 : End If
		this.aoz.sourcePos="721:24";
		if(!(this.vars.KANDY_array.getValue([this.vars.X2,this.vars.Y2,1])>0))
			return{type:1,label:300};
		this.aoz.sourcePos="721:46";
		this.vars.KANDY_array.setValue([this.vars.X2,this.vars.Y2,1],Math.floor(this.vars.KANDY_array.getValue([this.vars.X2,this.vars.Y2,1])-1));
		this.aoz.sourcePos="721:80";
	};
	this.blocks[300]=function()
	{
		// End If
		this.aoz.sourcePos="722:21";
	};
	this.blocks[301]=function()
	{
		// End If
		this.aoz.sourcePos="723:18";
	};
	this.blocks[302]=function()
	{
		// End If
		this.aoz.sourcePos="724:15";
	};
	this.blocks[303]=function()
	{
		// Next Y2
		this.aoz.sourcePos="725:12";
		this.vars.Y2+=1;
		if(this.vars.Y2<=this.vars.Y+1)
			return{type:1,label:297}
	};
	this.blocks[304]=function()
	{
		// Next X2
		this.aoz.sourcePos="726:9";
		this.vars.X2+=1;
		if(this.vars.X2<=this.vars.X+1)
			return{type:1,label:296}
	};
	this.blocks[305]=function()
	{
		// MOVED=True
		this.aoz.sourcePos="727:9";
		this.vars.MOVED=Math.floor(true);
		// Exit 2
		this.aoz.sourcePos="728:9";
		return{type:1,label:308};
		// End If
		this.aoz.sourcePos="729:6";
	};
	this.blocks[306]=function()
	{
		// Next Y
		this.aoz.sourcePos="730:3";
		this.vars.Y+=-1;
		if(this.vars.Y>=0)
			return{type:1,label:284}
	};
	this.blocks[307]=function()
	{
		// Next X
		this.aoz.sourcePos="731:0";
		this.vars.X+=-1;
		if(this.vars.X>=0)
			return{type:1,label:283}
	};
	this.blocks[308]=function()
	{
		// Gosub CHECKREMOVE
		this.aoz.sourcePos="732:0";
		return{type:2,label:400,return:309};
	};
	this.blocks[309]=function()
	{
		// Gosub RITAGRID
		this.aoz.sourcePos="733:0";
		return{type:2,label:421,return:310};
	};
	this.blocks[310]=function()
	{
		// Return
		this.aoz.sourcePos="735:0";
		return{type:3};
	};
	this.blocks[311]=function()
	{
		// _CHECKKANDY:
		// If TRYMOVE=True or MOVED=True
		this.aoz.sourcePos="738:0";
		if(!(this.vars.TRYMOVE==true||this.vars.MOVED==true))
			return{type:1,label:391};
		// CMARK=False : CMARKUP=False : CBOMBX=-1 : CBOMBX2=-1
		this.aoz.sourcePos="739:3";
		this.vars.CMARK=Math.floor(false);
		this.aoz.sourcePos="739:17";
		this.vars.CMARKUP=Math.floor(false);
		this.aoz.sourcePos="739:33";
		this.vars.CBOMBX=-1;
		this.aoz.sourcePos="739:45";
		this.vars.CBOMBX2=-1;
		// For Y=SIZEY-1 To 0 Step -1
		this.aoz.sourcePos="740:3";
		this.vars.Y=Math.floor(this.vars.SIZEY-1);
		if(this.vars.Y<0)
			return{type:1,label:375};
	};
	this.blocks[312]=function()
	{
		// For X=SIZEX-1 To 0 Step -1
		this.aoz.sourcePos="741:6";
		this.vars.X=Math.floor(this.vars.SIZEX-1);
		if(this.vars.X<0)
			return{type:1,label:374};
	};
	this.blocks[313]=function()
	{
		// D=KANDY(X,Y,0) : COUNT=0 : CT=D
		this.aoz.sourcePos="742:9";
		this.vars.D=Math.floor(this.vars.KANDY_array.getValue([this.vars.X,this.vars.Y,0]));
		this.aoz.sourcePos="742:26";
		this.vars.COUNT=0;
		this.aoz.sourcePos="742:36";
		this.vars.CT=Math.floor(this.vars.D);
		// If D>0
		this.aoz.sourcePos="743:9";
		if(!(this.vars.D>0))
			return{type:1,label:373};
		// For T=X To 0 Step -1
		this.aoz.sourcePos="744:12";
		this.vars.T=Math.floor(this.vars.X);
		if(this.vars.T<0)
			return{type:1,label:316};
	};
	this.blocks[314]=function()
	{
		// D2=KANDY(T,Y,0)
		this.aoz.sourcePos="745:15";
		this.vars.D2=Math.floor(this.vars.KANDY_array.getValue([this.vars.T,this.vars.Y,0]));
		// If D<>D2 and D+10<>D2 and D<>D2+10
		this.aoz.sourcePos="746:15";
		if(!(this.vars.D!=this.vars.D2&&this.vars.D+10!=this.vars.D2&&this.vars.D!=this.vars.D2+10))
			return{type:1,label:315};
		// Exit
		this.aoz.sourcePos="747:18";
		return{type:1,label:316};
		// End If
		this.aoz.sourcePos="748:15";
	};
	this.blocks[315]=function()
	{
		// COUNT=COUNT+1
		this.aoz.sourcePos="749:15";
		this.vars.COUNT=Math.floor(this.vars.COUNT+1);
		// Next T
		this.aoz.sourcePos="750:12";
		this.vars.T+=-1;
		if(this.vars.T>=0)
			return{type:1,label:314}
	};
	this.blocks[316]=function()
	{
		// If COUNT>2
		this.aoz.sourcePos="751:12";
		if(!(this.vars.COUNT>2))
			return{type:1,label:342};
		// For T=X To X-COUNT+1 Step -1
		this.aoz.sourcePos="752:15";
		this.vars.T=Math.floor(this.vars.X);
		if(this.vars.T<this.vars.X-this.vars.COUNT+1)
			return{type:1,label:341};
	};
	this.blocks[317]=function()
	{
		// If T=SVX and COUNT>3
		this.aoz.sourcePos="753:18";
		if(!(this.vars.T==this.vars.SVX&&this.vars.COUNT>3))
			return{type:1,label:321};
		// If KANDY(T,Y,0)<10 and KANDY(T,Y,0)>-1
		this.aoz.sourcePos="754:21";
		if(!(this.vars.KANDY_array.getValue([this.vars.T,this.vars.Y,0])<10&&this.vars.KANDY_array.getValue([this.vars.T,this.vars.Y,0])>-1))
			return{type:1,label:320};
		// CBOMBX=T : CBOMBY=Y
		this.aoz.sourcePos="756:24";
		this.vars.CBOMBX=Math.floor(this.vars.T);
		this.aoz.sourcePos="756:35";
		this.vars.CBOMBY=Math.floor(this.vars.Y);
		// If COUNT<5 : CBOMB=KANDY(T,Y,0)+10 : End If
		this.aoz.sourcePos="757:24";
		if(!(this.vars.COUNT<5))
			return{type:1,label:318};
		this.aoz.sourcePos="757:37";
		this.vars.CBOMB=Math.floor(this.vars.KANDY_array.getValue([this.vars.T,this.vars.Y,0])+10);
		this.aoz.sourcePos="757:61";
	};
	this.blocks[318]=function()
	{
		// If COUNT>4 : CBOMB=21 : End If
		this.aoz.sourcePos="758:24";
		if(!(this.vars.COUNT>4))
			return{type:1,label:319};
		this.aoz.sourcePos="758:37";
		this.vars.CBOMB=21;
		this.aoz.sourcePos="758:48";
	};
	this.blocks[319]=function()
	{
		// KANDY(T,Y,0)=-1 : MOV(T,Y)=1
		this.aoz.sourcePos="759:24";
		this.vars.KANDY_array.setValue([this.vars.T,this.vars.Y,0],-1);
		this.aoz.sourcePos="759:42";
		this.vars.MOV_array.setValue([this.vars.T,this.vars.Y],1);
		// End If
		this.aoz.sourcePos="760:21";
	};
	this.blocks[320]=function()
	{
		// Else
		return{type:1,label:340};
	};
	this.blocks[321]=function()
	{
		// If KANDY(T,Y,0)>10
		this.aoz.sourcePos="762:21";
		if(!(this.vars.KANDY_array.getValue([this.vars.T,this.vars.Y,0])>10))
			return{type:1,label:333};
		// MOV(T,Y)=1
		this.aoz.sourcePos="763:24";
		this.vars.MOV_array.setValue([this.vars.T,this.vars.Y],1);
		// KANDY(T,Y,0)=-1
		this.aoz.sourcePos="764:24";
		this.vars.KANDY_array.setValue([this.vars.T,this.vars.Y,0],-1);
		// KANDY(T,Y,3)=4 : POANG=POANG+10
		this.aoz.sourcePos="765:24";
		this.vars.KANDY_array.setValue([this.vars.T,this.vars.Y,3],4);
		this.aoz.sourcePos="765:41";
		this.vars.POANG=Math.floor(this.vars.POANG+10);
		// If KANDY(T,Y,1)>0 : KANDY(T,Y,1)=KANDY(T,Y,1)-1 : End If
		this.aoz.sourcePos="766:24";
		if(!(this.vars.KANDY_array.getValue([this.vars.T,this.vars.Y,1])>0))
			return{type:1,label:322};
		this.aoz.sourcePos="766:44";
		this.vars.KANDY_array.setValue([this.vars.T,this.vars.Y,1],Math.floor(this.vars.KANDY_array.getValue([this.vars.T,this.vars.Y,1])-1));
		this.aoz.sourcePos="766:74";
	};
	this.blocks[322]=function()
	{
		// For X2=T-1 To T+1
		this.aoz.sourcePos="768:24";
		this.vars.X2=Math.floor(this.vars.T-1);
		if(this.vars.X2>this.vars.T+1)
			return{type:1,label:332};
	};
	this.blocks[323]=function()
	{
		// For Y2=Y-1 To Y+1
		this.aoz.sourcePos="769:27";
		this.vars.Y2=Math.floor(this.vars.Y-1);
		if(this.vars.Y2>this.vars.Y+1)
			return{type:1,label:331};
	};
	this.blocks[324]=function()
	{
		// If X2>-1 and Y2>-1 and X2<SIZEX and Y2<SIZEY
		this.aoz.sourcePos="770:30";
		if(!(this.vars.X2>-1&&this.vars.Y2>-1&&this.vars.X2<this.vars.SIZEX&&this.vars.Y2<this.vars.SIZEY))
			return{type:1,label:330};
		// If KANDY(X2,Y2,0)>10 and KANDY(X2,Y2,1)>-1
		this.aoz.sourcePos="771:33";
		if(!(this.vars.KANDY_array.getValue([this.vars.X2,this.vars.Y2,0])>10&&this.vars.KANDY_array.getValue([this.vars.X2,this.vars.Y2,1])>-1))
			return{type:1,label:326};
		// KANDY(X2,Y2,0)=-2
		this.aoz.sourcePos="772:36";
		this.vars.KANDY_array.setValue([this.vars.X2,this.vars.Y2,0],-2);
		// KANDY(X2,Y2,3)=4 : POANG=POANG+10
		this.aoz.sourcePos="773:36";
		this.vars.KANDY_array.setValue([this.vars.X2,this.vars.Y2,3],4);
		this.aoz.sourcePos="773:55";
		this.vars.POANG=Math.floor(this.vars.POANG+10);
		// MOV(X2,Y2)=1
		this.aoz.sourcePos="774:36";
		this.vars.MOV_array.setValue([this.vars.X2,this.vars.Y2],1);
		// If KANDY(X2,Y2,1)>0 : KANDY(X2,Y2,1)=KANDY(X2,Y2,1)-1 : End If
		this.aoz.sourcePos="775:36";
		if(!(this.vars.KANDY_array.getValue([this.vars.X2,this.vars.Y2,1])>0))
			return{type:1,label:325};
		this.aoz.sourcePos="775:58";
		this.vars.KANDY_array.setValue([this.vars.X2,this.vars.Y2,1],Math.floor(this.vars.KANDY_array.getValue([this.vars.X2,this.vars.Y2,1])-1));
		this.aoz.sourcePos="775:92";
	};
	this.blocks[325]=function()
	{
		// Else
		return{type:1,label:329};
	};
	this.blocks[326]=function()
	{
		// If KANDY(X2,Y2,0)>-1 and KANDY(X2,Y2,1)>-1
		this.aoz.sourcePos="777:36";
		if(!(this.vars.KANDY_array.getValue([this.vars.X2,this.vars.Y2,0])>-1&&this.vars.KANDY_array.getValue([this.vars.X2,this.vars.Y2,1])>-1))
			return{type:1,label:328};
		// KANDY(X2,Y2,0)=-1
		this.aoz.sourcePos="778:39";
		this.vars.KANDY_array.setValue([this.vars.X2,this.vars.Y2,0],-1);
		// KANDY(X2,Y2,3)=4 : POANG=POANG+10
		this.aoz.sourcePos="779:39";
		this.vars.KANDY_array.setValue([this.vars.X2,this.vars.Y2,3],4);
		this.aoz.sourcePos="779:58";
		this.vars.POANG=Math.floor(this.vars.POANG+10);
		// MOV(X2,Y2)=1
		this.aoz.sourcePos="780:39";
		this.vars.MOV_array.setValue([this.vars.X2,this.vars.Y2],1);
		// If KANDY(X2,Y2,1)>0 : KANDY(X2,Y2,1)=KANDY(X2,Y2,1)-1 : End If
		this.aoz.sourcePos="781:39";
		if(!(this.vars.KANDY_array.getValue([this.vars.X2,this.vars.Y2,1])>0))
			return{type:1,label:327};
		this.aoz.sourcePos="781:61";
		this.vars.KANDY_array.setValue([this.vars.X2,this.vars.Y2,1],Math.floor(this.vars.KANDY_array.getValue([this.vars.X2,this.vars.Y2,1])-1));
		this.aoz.sourcePos="781:95";
	};
	this.blocks[327]=function()
	{
		// End If
		this.aoz.sourcePos="782:36";
	};
	this.blocks[328]=function()
	{
		// End If
		this.aoz.sourcePos="783:33";
	};
	this.blocks[329]=function()
	{
		// End If
		this.aoz.sourcePos="784:30";
	};
	this.blocks[330]=function()
	{
		// Next Y2
		this.aoz.sourcePos="785:27";
		this.vars.Y2+=1;
		if(this.vars.Y2<=this.vars.Y+1)
			return{type:1,label:324}
	};
	this.blocks[331]=function()
	{
		// Next X2
		this.aoz.sourcePos="786:24";
		this.vars.X2+=1;
		if(this.vars.X2<=this.vars.T+1)
			return{type:1,label:323}
	};
	this.blocks[332]=function()
	{
		// Else
		return{type:1,label:339};
	};
	this.blocks[333]=function()
	{
		// If(T<>MARKUPX or Y<>MARKY) and(T<>MARKUPX or Y<>MARKUPY)
		this.aoz.sourcePos="789:24";
		if(!((this.vars.T!=this.vars.MARKUPX||this.vars.Y!=this.vars.MARKY)&&(this.vars.T!=this.vars.MARKUPX||this.vars.Y!=this.vars.MARKUPY)))
			return{type:1,label:335};
		// KANDY(T,Y,0)=-1
		this.aoz.sourcePos="790:27";
		this.vars.KANDY_array.setValue([this.vars.T,this.vars.Y,0],-1);
		// KANDY(T,Y,3)=4 : POANG=POANG+10
		this.aoz.sourcePos="791:27";
		this.vars.KANDY_array.setValue([this.vars.T,this.vars.Y,3],4);
		this.aoz.sourcePos="791:44";
		this.vars.POANG=Math.floor(this.vars.POANG+10);
		// MOV(T,Y)=1
		this.aoz.sourcePos="792:27";
		this.vars.MOV_array.setValue([this.vars.T,this.vars.Y],1);
		// If KANDY(T,Y,1)>0 : KANDY(T,Y,1)=KANDY(T,Y,1)-1 : End If
		this.aoz.sourcePos="793:27";
		if(!(this.vars.KANDY_array.getValue([this.vars.T,this.vars.Y,1])>0))
			return{type:1,label:334};
		this.aoz.sourcePos="793:47";
		this.vars.KANDY_array.setValue([this.vars.T,this.vars.Y,1],Math.floor(this.vars.KANDY_array.getValue([this.vars.T,this.vars.Y,1])-1));
		this.aoz.sourcePos="793:77";
	};
	this.blocks[334]=function()
	{
		// Else
		return{type:1,label:338};
	};
	this.blocks[335]=function()
	{
		// If T=MARKX and Y=MARKY
		this.aoz.sourcePos="795:27";
		if(!(this.vars.T==this.vars.MARKX&&this.vars.Y==this.vars.MARKY))
			return{type:1,label:336};
		// CMARK=True
		this.aoz.sourcePos="796:30";
		this.vars.CMARK=Math.floor(true);
		// End If
		this.aoz.sourcePos="797:27";
	};
	this.blocks[336]=function()
	{
		// If T=MARKUPX and Y=MARKUPY
		this.aoz.sourcePos="798:27";
		if(!(this.vars.T==this.vars.MARKUPX&&this.vars.Y==this.vars.MARKUPY))
			return{type:1,label:337};
		// CMARKUP=True
		this.aoz.sourcePos="799:30";
		this.vars.CMARKUP=Math.floor(true);
		// End If
		this.aoz.sourcePos="800:27";
	};
	this.blocks[337]=function()
	{
		// End If
		this.aoz.sourcePos="801:24";
	};
	this.blocks[338]=function()
	{
		// End If
		this.aoz.sourcePos="802:21";
	};
	this.blocks[339]=function()
	{
		// End If
		this.aoz.sourcePos="803:18";
	};
	this.blocks[340]=function()
	{
		// RFLAG=True
		this.aoz.sourcePos="804:18";
		this.vars.RFLAG=Math.floor(true);
		// Next T
		this.aoz.sourcePos="805:15";
		this.vars.T+=-1;
		if(this.vars.T>=this.vars.X-this.vars.COUNT+1)
			return{type:1,label:317}
	};
	this.blocks[341]=function()
	{
		// End If
		this.aoz.sourcePos="806:12";
	};
	this.blocks[342]=function()
	{
		// COUNT2=0
		this.aoz.sourcePos="807:12";
		this.vars.COUNT2=0;
		// For T=Y To 0 Step -1
		this.aoz.sourcePos="808:12";
		this.vars.T=Math.floor(this.vars.Y);
		if(this.vars.T<0)
			return{type:1,label:345};
	};
	this.blocks[343]=function()
	{
		// D2=KANDY(X,T,0)
		this.aoz.sourcePos="809:15";
		this.vars.D2=Math.floor(this.vars.KANDY_array.getValue([this.vars.X,this.vars.T,0]));
		// If CT<>D2 and CT+10<>D2 and CT<>D2+10
		this.aoz.sourcePos="810:15";
		if(!(this.vars.CT!=this.vars.D2&&this.vars.CT+10!=this.vars.D2&&this.vars.CT!=this.vars.D2+10))
			return{type:1,label:344};
		// Exit
		this.aoz.sourcePos="811:18";
		return{type:1,label:345};
		// End If
		this.aoz.sourcePos="812:15";
	};
	this.blocks[344]=function()
	{
		// COUNT2=COUNT2+1
		this.aoz.sourcePos="813:15";
		this.vars.COUNT2=Math.floor(this.vars.COUNT2+1);
		// Next T
		this.aoz.sourcePos="814:12";
		this.vars.T+=-1;
		if(this.vars.T>=0)
			return{type:1,label:343}
	};
	this.blocks[345]=function()
	{
		// If COUNT2>2
		this.aoz.sourcePos="815:12";
		if(!(this.vars.COUNT2>2))
			return{type:1,label:371};
		// For T=Y To Y-COUNT2+1 Step -1
		this.aoz.sourcePos="816:15";
		this.vars.T=Math.floor(this.vars.Y);
		if(this.vars.T<this.vars.Y-this.vars.COUNT2+1)
			return{type:1,label:370};
	};
	this.blocks[346]=function()
	{
		// If T=SVY and COUNT2>3
		this.aoz.sourcePos="817:18";
		if(!(this.vars.T==this.vars.SVY&&this.vars.COUNT2>3))
			return{type:1,label:350};
		// If KANDY(X,T,0)<10 and KANDY(X,T,0)>-1
		this.aoz.sourcePos="818:21";
		if(!(this.vars.KANDY_array.getValue([this.vars.X,this.vars.T,0])<10&&this.vars.KANDY_array.getValue([this.vars.X,this.vars.T,0])>-1))
			return{type:1,label:349};
		// CBOMBX2=X : CBOMBY2=T
		this.aoz.sourcePos="820:24";
		this.vars.CBOMBX2=Math.floor(this.vars.X);
		this.aoz.sourcePos="820:36";
		this.vars.CBOMBY2=Math.floor(this.vars.T);
		// If COUNT2<5 : CBOMB2=KANDY(X,T,0)+10 : End If
		this.aoz.sourcePos="821:24";
		if(!(this.vars.COUNT2<5))
			return{type:1,label:347};
		this.aoz.sourcePos="821:38";
		this.vars.CBOMB2=Math.floor(this.vars.KANDY_array.getValue([this.vars.X,this.vars.T,0])+10);
		this.aoz.sourcePos="821:63";
	};
	this.blocks[347]=function()
	{
		// If COUNT2>4 : CBOMB2=21 : End If
		this.aoz.sourcePos="822:24";
		if(!(this.vars.COUNT2>4))
			return{type:1,label:348};
		this.aoz.sourcePos="822:38";
		this.vars.CBOMB2=21;
		this.aoz.sourcePos="822:50";
	};
	this.blocks[348]=function()
	{
		// KANDY(X,T,0)=-1
		this.aoz.sourcePos="823:24";
		this.vars.KANDY_array.setValue([this.vars.X,this.vars.T,0],-1);
		// MOV(X,T)=1
		this.aoz.sourcePos="824:24";
		this.vars.MOV_array.setValue([this.vars.X,this.vars.T],1);
		// End If
		this.aoz.sourcePos="825:21";
	};
	this.blocks[349]=function()
	{
		// Else
		return{type:1,label:369};
	};
	this.blocks[350]=function()
	{
		// If KANDY(X,T,0)>10
		this.aoz.sourcePos="827:21";
		if(!(this.vars.KANDY_array.getValue([this.vars.X,this.vars.T,0])>10))
			return{type:1,label:362};
		// KANDY(X,T,0)=-1
		this.aoz.sourcePos="828:24";
		this.vars.KANDY_array.setValue([this.vars.X,this.vars.T,0],-1);
		// KANDY(X,T,3)=4 : POANG=POANG+10
		this.aoz.sourcePos="829:24";
		this.vars.KANDY_array.setValue([this.vars.X,this.vars.T,3],4);
		this.aoz.sourcePos="829:41";
		this.vars.POANG=Math.floor(this.vars.POANG+10);
		// If KANDY(X,T,1)>0 : KANDY(X,T,1)=KANDY(X,T,1)-1 : End If
		this.aoz.sourcePos="830:24";
		if(!(this.vars.KANDY_array.getValue([this.vars.X,this.vars.T,1])>0))
			return{type:1,label:351};
		this.aoz.sourcePos="830:44";
		this.vars.KANDY_array.setValue([this.vars.X,this.vars.T,1],Math.floor(this.vars.KANDY_array.getValue([this.vars.X,this.vars.T,1])-1));
		this.aoz.sourcePos="830:74";
	};
	this.blocks[351]=function()
	{
		// For X2=X-1 To X+1
		this.aoz.sourcePos="832:24";
		this.vars.X2=Math.floor(this.vars.X-1);
		if(this.vars.X2>this.vars.X+1)
			return{type:1,label:361};
	};
	this.blocks[352]=function()
	{
		// For Y2=T-1 To T+1
		this.aoz.sourcePos="833:27";
		this.vars.Y2=Math.floor(this.vars.T-1);
		if(this.vars.Y2>this.vars.T+1)
			return{type:1,label:360};
	};
	this.blocks[353]=function()
	{
		// If X2>-1 and Y2>-1 and X2<SIZEX and Y2<SIZEY
		this.aoz.sourcePos="834:30";
		if(!(this.vars.X2>-1&&this.vars.Y2>-1&&this.vars.X2<this.vars.SIZEX&&this.vars.Y2<this.vars.SIZEY))
			return{type:1,label:359};
		// If KANDY(X2,Y2,0)>10 and KANDY(X2,Y2,1)>-1
		this.aoz.sourcePos="835:33";
		if(!(this.vars.KANDY_array.getValue([this.vars.X2,this.vars.Y2,0])>10&&this.vars.KANDY_array.getValue([this.vars.X2,this.vars.Y2,1])>-1))
			return{type:1,label:355};
		// KANDY(X2,Y2,0)=-2
		this.aoz.sourcePos="836:36";
		this.vars.KANDY_array.setValue([this.vars.X2,this.vars.Y2,0],-2);
		// KANDY(X2,Y2,3)=4 : POANG=POANG+10
		this.aoz.sourcePos="837:36";
		this.vars.KANDY_array.setValue([this.vars.X2,this.vars.Y2,3],4);
		this.aoz.sourcePos="837:55";
		this.vars.POANG=Math.floor(this.vars.POANG+10);
		// MOV(X2,Y2)=1
		this.aoz.sourcePos="838:36";
		this.vars.MOV_array.setValue([this.vars.X2,this.vars.Y2],1);
		// If KANDY(X2,Y2,1)>0 : KANDY(X2,Y2,1)=KANDY(X2,Y2,1)-1 : End If
		this.aoz.sourcePos="839:36";
		if(!(this.vars.KANDY_array.getValue([this.vars.X2,this.vars.Y2,1])>0))
			return{type:1,label:354};
		this.aoz.sourcePos="839:58";
		this.vars.KANDY_array.setValue([this.vars.X2,this.vars.Y2,1],Math.floor(this.vars.KANDY_array.getValue([this.vars.X2,this.vars.Y2,1])-1));
		this.aoz.sourcePos="839:92";
	};
	this.blocks[354]=function()
	{
		// Else
		return{type:1,label:358};
	};
	this.blocks[355]=function()
	{
		// If KANDY(X2,Y2,0)>-1 and KANDY(X2,Y2,1)>-1
		this.aoz.sourcePos="841:36";
		if(!(this.vars.KANDY_array.getValue([this.vars.X2,this.vars.Y2,0])>-1&&this.vars.KANDY_array.getValue([this.vars.X2,this.vars.Y2,1])>-1))
			return{type:1,label:357};
		// KANDY(X2,Y2,0)=-1
		this.aoz.sourcePos="842:39";
		this.vars.KANDY_array.setValue([this.vars.X2,this.vars.Y2,0],-1);
		// KANDY(X2,Y2,3)=4 : POANG=POANG+10
		this.aoz.sourcePos="843:39";
		this.vars.KANDY_array.setValue([this.vars.X2,this.vars.Y2,3],4);
		this.aoz.sourcePos="843:58";
		this.vars.POANG=Math.floor(this.vars.POANG+10);
		// MOV(X2,Y2)=1
		this.aoz.sourcePos="844:39";
		this.vars.MOV_array.setValue([this.vars.X2,this.vars.Y2],1);
		// If KANDY(X2,Y2,1)>0 : KANDY(X2,Y2,1)=KANDY(X2,Y2,1)-1 : End If
		this.aoz.sourcePos="845:39";
		if(!(this.vars.KANDY_array.getValue([this.vars.X2,this.vars.Y2,1])>0))
			return{type:1,label:356};
		this.aoz.sourcePos="845:61";
		this.vars.KANDY_array.setValue([this.vars.X2,this.vars.Y2,1],Math.floor(this.vars.KANDY_array.getValue([this.vars.X2,this.vars.Y2,1])-1));
		this.aoz.sourcePos="845:95";
	};
	this.blocks[356]=function()
	{
		// End If
		this.aoz.sourcePos="846:36";
	};
	this.blocks[357]=function()
	{
		// End If
		this.aoz.sourcePos="847:33";
	};
	this.blocks[358]=function()
	{
		// End If
		this.aoz.sourcePos="848:30";
	};
	this.blocks[359]=function()
	{
		// Next Y2
		this.aoz.sourcePos="849:27";
		this.vars.Y2+=1;
		if(this.vars.Y2<=this.vars.T+1)
			return{type:1,label:353}
	};
	this.blocks[360]=function()
	{
		// Next X2
		this.aoz.sourcePos="850:24";
		this.vars.X2+=1;
		if(this.vars.X2<=this.vars.X+1)
			return{type:1,label:352}
	};
	this.blocks[361]=function()
	{
		// Else
		return{type:1,label:368};
	};
	this.blocks[362]=function()
	{
		// If(X<>MARKX or T<>MARKY) and(X<>MARKUPX or T<>MARKUPY)
		this.aoz.sourcePos="852:24";
		if(!((this.vars.X!=this.vars.MARKX||this.vars.T!=this.vars.MARKY)&&(this.vars.X!=this.vars.MARKUPX||this.vars.T!=this.vars.MARKUPY)))
			return{type:1,label:364};
		// KANDY(X,T,0)=-1
		this.aoz.sourcePos="853:27";
		this.vars.KANDY_array.setValue([this.vars.X,this.vars.T,0],-1);
		// KANDY(X,T,3)=4 : POANG=POANG+10
		this.aoz.sourcePos="854:27";
		this.vars.KANDY_array.setValue([this.vars.X,this.vars.T,3],4);
		this.aoz.sourcePos="854:44";
		this.vars.POANG=Math.floor(this.vars.POANG+10);
		// MOV(X,T)=1
		this.aoz.sourcePos="855:27";
		this.vars.MOV_array.setValue([this.vars.X,this.vars.T],1);
		// If KANDY(X,T,1)>0 : KANDY(X,T,1)=KANDY(X,T,1)-1 : End If
		this.aoz.sourcePos="856:27";
		if(!(this.vars.KANDY_array.getValue([this.vars.X,this.vars.T,1])>0))
			return{type:1,label:363};
		this.aoz.sourcePos="856:47";
		this.vars.KANDY_array.setValue([this.vars.X,this.vars.T,1],Math.floor(this.vars.KANDY_array.getValue([this.vars.X,this.vars.T,1])-1));
		this.aoz.sourcePos="856:77";
	};
	this.blocks[363]=function()
	{
		// Else
		return{type:1,label:367};
	};
	this.blocks[364]=function()
	{
		// If X=MARKX and T=MARKY
		this.aoz.sourcePos="858:27";
		if(!(this.vars.X==this.vars.MARKX&&this.vars.T==this.vars.MARKY))
			return{type:1,label:365};
		// CMARK=True
		this.aoz.sourcePos="859:30";
		this.vars.CMARK=Math.floor(true);
		// End If
		this.aoz.sourcePos="860:27";
	};
	this.blocks[365]=function()
	{
		// If X=MARKUPX and T=MARKUPY
		this.aoz.sourcePos="861:27";
		if(!(this.vars.X==this.vars.MARKUPX&&this.vars.T==this.vars.MARKUPY))
			return{type:1,label:366};
		// CMARKUP=True
		this.aoz.sourcePos="862:30";
		this.vars.CMARKUP=Math.floor(true);
		// End If
		this.aoz.sourcePos="863:27";
	};
	this.blocks[366]=function()
	{
		// End If
		this.aoz.sourcePos="864:24";
	};
	this.blocks[367]=function()
	{
		// End If
		this.aoz.sourcePos="865:21";
	};
	this.blocks[368]=function()
	{
		// End If
		this.aoz.sourcePos="866:18";
	};
	this.blocks[369]=function()
	{
		// RFLAG=True
		this.aoz.sourcePos="867:18";
		this.vars.RFLAG=Math.floor(true);
		// Next T
		this.aoz.sourcePos="868:15";
		this.vars.T+=-1;
		if(this.vars.T>=this.vars.Y-this.vars.COUNT2+1)
			return{type:1,label:346}
	};
	this.blocks[370]=function()
	{
		// End If
		this.aoz.sourcePos="869:12";
	};
	this.blocks[371]=function()
	{
		// If COUNT+COUNT2>BIGCOUNT
		this.aoz.sourcePos="870:12";
		if(!(this.vars.COUNT+this.vars.COUNT2>this.vars.BIGCOUNT))
			return{type:1,label:372};
		// BIGCOUNT=COUNT+COUNT2
		this.aoz.sourcePos="871:15";
		this.vars.BIGCOUNT=Math.floor(this.vars.COUNT+this.vars.COUNT2);
		// End If
		this.aoz.sourcePos="872:12";
	};
	this.blocks[372]=function()
	{
		// End If
		this.aoz.sourcePos="873:9";
	};
	this.blocks[373]=function()
	{
		// Next X
		this.aoz.sourcePos="874:6";
		this.vars.X+=-1;
		if(this.vars.X>=0)
			return{type:1,label:313}
	};
	this.blocks[374]=function()
	{
		// Next Y
		this.aoz.sourcePos="875:3";
		this.vars.Y+=-1;
		if(this.vars.Y>=0)
			return{type:1,label:312}
	};
	this.blocks[375]=function()
	{
		// If CMARKUP=True
		this.aoz.sourcePos="876:3";
		if(!(this.vars.CMARKUP==true))
			return{type:1,label:377};
		// MOV(MARKUPX,MARKUPY)=1
		this.aoz.sourcePos="877:6";
		this.vars.MOV_array.setValue([this.vars.MARKUPX,this.vars.MARKUPY],1);
		// KANDY(MARKUPX,MARKUPY,0)=-1
		this.aoz.sourcePos="878:6";
		this.vars.KANDY_array.setValue([this.vars.MARKUPX,this.vars.MARKUPY,0],-1);
		// KANDY(MARKUPX,MARKUPY,3)=4
		this.aoz.sourcePos="879:6";
		this.vars.KANDY_array.setValue([this.vars.MARKUPX,this.vars.MARKUPY,3],4);
		// If KANDY(MARKUPX,MARKUPY,1)>0 : KANDY(MARKUPX,MARKUPY,1)=KANDY(MARKUPX,MARKUPY,1)-1 : End If
		this.aoz.sourcePos="880:6";
		if(!(this.vars.KANDY_array.getValue([this.vars.MARKUPX,this.vars.MARKUPY,1])>0))
			return{type:1,label:376};
		this.aoz.sourcePos="880:38";
		this.vars.KANDY_array.setValue([this.vars.MARKUPX,this.vars.MARKUPY,1],Math.floor(this.vars.KANDY_array.getValue([this.vars.MARKUPX,this.vars.MARKUPY,1])-1));
		this.aoz.sourcePos="880:92";
	};
	this.blocks[376]=function()
	{
		// End If
		this.aoz.sourcePos="881:3";
	};
	this.blocks[377]=function()
	{
		// If CMARK=True
		this.aoz.sourcePos="882:3";
		if(!(this.vars.CMARK==true))
			return{type:1,label:379};
		// MOV(MARKX,MARKY)=1
		this.aoz.sourcePos="883:6";
		this.vars.MOV_array.setValue([this.vars.MARKX,this.vars.MARKY],1);
		// KANDY(MARKX,MARKY,0)=-1
		this.aoz.sourcePos="884:6";
		this.vars.KANDY_array.setValue([this.vars.MARKX,this.vars.MARKY,0],-1);
		// KANDY(MARKX,MARKY,3)=4
		this.aoz.sourcePos="885:6";
		this.vars.KANDY_array.setValue([this.vars.MARKX,this.vars.MARKY,3],4);
		// If KANDY(MARKX,MARKY,1)>0 : KANDY(MARKX,MARKY,1)=KANDY(MARKX,MARKY,1)-1 : End If
		this.aoz.sourcePos="886:6";
		if(!(this.vars.KANDY_array.getValue([this.vars.MARKX,this.vars.MARKY,1])>0))
			return{type:1,label:378};
		this.aoz.sourcePos="886:34";
		this.vars.KANDY_array.setValue([this.vars.MARKX,this.vars.MARKY,1],Math.floor(this.vars.KANDY_array.getValue([this.vars.MARKX,this.vars.MARKY,1])-1));
		this.aoz.sourcePos="886:80";
	};
	this.blocks[378]=function()
	{
		// End If
		this.aoz.sourcePos="887:3";
	};
	this.blocks[379]=function()
	{
		// If RFLAG=False and MOVED=False
		this.aoz.sourcePos="888:3";
		if(!(this.vars.RFLAG==false&&this.vars.MOVED==false))
			return{type:1,label:380};
		// CANCELMOVE=True
		this.aoz.sourcePos="889:6";
		this.vars.CANCELMOVE=Math.floor(true);
		// End If
		this.aoz.sourcePos="890:3";
	};
	this.blocks[380]=function()
	{
		// TRYMOVE=False
		this.aoz.sourcePos="891:3";
		this.vars.TRYMOVE=Math.floor(false);
		// If CBOMBX>-1
		this.aoz.sourcePos="892:3";
		if(!(this.vars.CBOMBX>-1))
			return{type:1,label:381};
		// KANDY(CBOMBX,CBOMBY,0)=CBOMB
		this.aoz.sourcePos="893:6";
		this.vars.KANDY_array.setValue([this.vars.CBOMBX,this.vars.CBOMBY,0],Math.floor(this.vars.CBOMB));
		// MOV(CBOMBX,CBOMBY)=1
		this.aoz.sourcePos="894:6";
		this.vars.MOV_array.setValue([this.vars.CBOMBX,this.vars.CBOMBY],1);
		// End If
		this.aoz.sourcePos="895:3";
	};
	this.blocks[381]=function()
	{
		// If CBOMBX2>-1
		this.aoz.sourcePos="896:3";
		if(!(this.vars.CBOMBX2>-1))
			return{type:1,label:382};
		// KANDY(CBOMBX2,CBOMBY2,0)=CBOMB2
		this.aoz.sourcePos="897:6";
		this.vars.KANDY_array.setValue([this.vars.CBOMBX2,this.vars.CBOMBY2,0],Math.floor(this.vars.CBOMB2));
		// MOV(CBOMBX2,CBOMBY2)=1
		this.aoz.sourcePos="898:6";
		this.vars.MOV_array.setValue([this.vars.CBOMBX2,this.vars.CBOMBY2],1);
		// End If
		this.aoz.sourcePos="899:3";
	};
	this.blocks[382]=function()
	{
		// If RFLAG=True
		this.aoz.sourcePos="900:3";
		if(!(this.vars.RFLAG==true))
			return{type:1,label:386};
		// Gosub CHECKREMOVE
		this.aoz.sourcePos="901:6";
		return{type:2,label:400,return:383};
	};
	this.blocks[383]=function()
	{
		// Gosub RITAGRID
		this.aoz.sourcePos="902:6";
		return{type:2,label:421,return:384};
	};
	this.blocks[384]=function()
	{
		// Gosub WEDONE
		this.aoz.sourcePos="904:6";
		return{type:2,label:392,return:385};
	};
	this.blocks[385]=function()
	{
		// End If
		this.aoz.sourcePos="905:3";
	};
	this.blocks[386]=function()
	{
		// If CANCELMOVE=True
		this.aoz.sourcePos="906:3";
		if(!(this.vars.CANCELMOVE==true))
			return{type:1,label:390};
		// Gosub CANCELGRID
		this.aoz.sourcePos="907:6";
		return{type:2,label:253,return:387};
	};
	this.blocks[387]=function()
	{
		// RALL=True
		this.aoz.sourcePos="908:6";
		this.vars.RALL=Math.floor(true);
		// Gosub RITAGRID
		this.aoz.sourcePos="909:6";
		return{type:2,label:421,return:388};
	};
	this.blocks[388]=function()
	{
		// RALL=False
		this.aoz.sourcePos="910:6";
		this.vars.RALL=Math.floor(false);
		// Wait DROPDELAY
		this.aoz.sourcePos="911:6";
		return{type:8,instruction:"wait",args:[this.vars.DROPDELAY]};
	};
	this.blocks[389]=function()
	{
		// CANCELMOVE=False
		this.aoz.sourcePos="912:6";
		this.vars.CANCELMOVE=Math.floor(false);
		// End If
		this.aoz.sourcePos="913:3";
	};
	this.blocks[390]=function()
	{
		// MOVED=False
		this.aoz.sourcePos="914:3";
		this.vars.MOVED=Math.floor(false);
		// End If
		this.aoz.sourcePos="915:0";
	};
	this.blocks[391]=function()
	{
		// Return
		this.aoz.sourcePos="917:0";
		return{type:3};
	};
	this.blocks[392]=function()
	{
		// WEDONE:
		// WEDO=True
		this.aoz.sourcePos="920:0";
		this.vars.WEDO=Math.floor(true);
		// For Y=0 To SIZEY-1
		this.aoz.sourcePos="921:0";
		this.vars.Y=0;
		if(this.vars.Y>this.vars.SIZEY-1)
			return{type:1,label:397};
	};
	this.blocks[393]=function()
	{
		// For X=0 To SIZEX-1
		this.aoz.sourcePos="922:3";
		this.vars.X=0;
		if(this.vars.X>this.vars.SIZEX-1)
			return{type:1,label:396};
	};
	this.blocks[394]=function()
	{
		// If KANDY(X,Y,1)>0
		this.aoz.sourcePos="923:6";
		if(!(this.vars.KANDY_array.getValue([this.vars.X,this.vars.Y,1])>0))
			return{type:1,label:395};
		// WEDO=False
		this.aoz.sourcePos="924:9";
		this.vars.WEDO=Math.floor(false);
		// Exit 2
		this.aoz.sourcePos="925:9";
		return{type:1,label:397};
		// End If
		this.aoz.sourcePos="926:6";
	};
	this.blocks[395]=function()
	{
		// Next X
		this.aoz.sourcePos="927:3";
		this.vars.X+=1;
		if(this.vars.X<=this.vars.SIZEX-1)
			return{type:1,label:394}
	};
	this.blocks[396]=function()
	{
		// Next Y
		this.aoz.sourcePos="928:0";
		this.vars.Y+=1;
		if(this.vars.Y<=this.vars.SIZEY-1)
			return{type:1,label:393}
	};
	this.blocks[397]=function()
	{
		// If WEDO=True
		this.aoz.sourcePos="930:0";
		if(!(this.vars.WEDO==true))
			return{type:1,label:399};
		// Gosub _SAVEPROGRESS
		this.aoz.sourcePos="932:3";
		return{type:2,label:143,return:398};
	};
	this.blocks[398]=function()
	{
		// CHLVL=True
		this.aoz.sourcePos="933:3";
		this.vars.CHLVL=Math.floor(true);
		// End If
		this.aoz.sourcePos="934:0";
	};
	this.blocks[399]=function()
	{
		// Return
		this.aoz.sourcePos="936:0";
		return{type:3};
	};
	this.blocks[400]=function()
	{
		// CHECKREMOVE:
	};
	this.blocks[401]=function()
	{
		// AGAIN:
		// AN=False
		this.aoz.sourcePos="940:0";
		this.vars.AN=Math.floor(false);
		// For Y=0 To SIZEY-1
		this.aoz.sourcePos="941:0";
		this.vars.Y=0;
		if(this.vars.Y>this.vars.SIZEY-1)
			return{type:1,label:406};
	};
	this.blocks[402]=function()
	{
		// For X=0 To SIZEX-1
		this.aoz.sourcePos="942:3";
		this.vars.X=0;
		if(this.vars.X>this.vars.SIZEX-1)
			return{type:1,label:405};
	};
	this.blocks[403]=function()
	{
		// If KANDY(X,Y,3)>0 : AN=True
		this.aoz.sourcePos="943:6";
		if(!(this.vars.KANDY_array.getValue([this.vars.X,this.vars.Y,3])>0))
			return{type:1,label:404};
		this.aoz.sourcePos="943:26";
		this.vars.AN=Math.floor(true);
		// Exit 2
		this.aoz.sourcePos="944:9";
		return{type:1,label:406};
		// End If
		this.aoz.sourcePos="945:6";
	};
	this.blocks[404]=function()
	{
		// Next X
		this.aoz.sourcePos="946:3";
		this.vars.X+=1;
		if(this.vars.X<=this.vars.SIZEX-1)
			return{type:1,label:403}
	};
	this.blocks[405]=function()
	{
		// Next Y
		this.aoz.sourcePos="947:0";
		this.vars.Y+=1;
		if(this.vars.Y<=this.vars.SIZEY-1)
			return{type:1,label:402}
	};
	this.blocks[406]=function()
	{
		// If AN=True
		this.aoz.sourcePos="948:0";
		if(!(this.vars.AN==true))
			return{type:1,label:413};
		// B2=9
		this.aoz.sourcePos="949:3";
		this.vars.B2=9;
		// For Y=0 To SIZEY-1
		this.aoz.sourcePos="950:3";
		this.vars.Y=0;
		if(this.vars.Y>this.vars.SIZEY-1)
			return{type:1,label:411};
	};
	this.blocks[407]=function()
	{
		// For X=0 To SIZEX-1
		this.aoz.sourcePos="951:6";
		this.vars.X=0;
		if(this.vars.X>this.vars.SIZEX-1)
			return{type:1,label:410};
	};
	this.blocks[408]=function()
	{
		// If KANDY(X,Y,3)>0
		this.aoz.sourcePos="952:9";
		if(!(this.vars.KANDY_array.getValue([this.vars.X,this.vars.Y,3])>0))
			return{type:1,label:409};
		// MOV(X,Y)=1
		this.aoz.sourcePos="953:12";
		this.vars.MOV_array.setValue([this.vars.X,this.vars.Y],1);
		// ANI=5-KANDY(X,Y,3)
		this.aoz.sourcePos="954:12";
		this.vars.ANI=Math.floor(5-this.vars.KANDY_array.getValue([this.vars.X,this.vars.Y,3]));
		// KANDY(X,Y,3)=KANDY(X,Y,3)-1
		this.aoz.sourcePos="955:12";
		this.vars.KANDY_array.setValue([this.vars.X,this.vars.Y,3],Math.floor(this.vars.KANDY_array.getValue([this.vars.X,this.vars.Y,3])-1));
		// B=KANDY(X,Y,1) : X2=X*16+OFFSETX : Y2=Y*16+OFFSETY
		this.aoz.sourcePos="956:12";
		this.vars.B=Math.floor(this.vars.KANDY_array.getValue([this.vars.X,this.vars.Y,1]));
		this.aoz.sourcePos="956:29";
		this.vars.X2=Math.floor(this.vars.X*16+this.vars.OFFSETX);
		this.aoz.sourcePos="956:47";
		this.vars.Y2=Math.floor(this.vars.Y*16+this.vars.OFFSETY);
		// Screen Copy 0,B*16,B2*16,B*16+16,B2*16+16 To 1,X2,Y2
		this.aoz.sourcePos="957:12";
		this.aoz.getScreen(0).screenCopy(this.aoz.getScreen(1),undefined,{x:this.vars.B*16,y:this.vars.B2*16,width:(this.vars.B*16+16)-(this.vars.B*16),height:(this.vars.B2*16+16)-(this.vars.B2*16)},{x:this.vars.X2,y:this.vars.Y2});
		// Paste Bob X*16+OFFSETX,Y*16+OFFSETY,ANI+19
		this.aoz.sourcePos="958:12";
		this.aoz.currentScreen.pasteBob(this.vars.ANI+19,this.vars.X*16+this.vars.OFFSETX,this.vars.Y*16+this.vars.OFFSETY,undefined,undefined,undefined*this.aoz.degreeRadian,);
		// End If
		this.aoz.sourcePos="961:9";
	};
	this.blocks[409]=function()
	{
		// Next X
		this.aoz.sourcePos="962:6";
		this.vars.X+=1;
		if(this.vars.X<=this.vars.SIZEX-1)
			return{type:1,label:408}
	};
	this.blocks[410]=function()
	{
		// Next Y
		this.aoz.sourcePos="963:3";
		this.vars.Y+=1;
		if(this.vars.Y<=this.vars.SIZEY-1)
			return{type:1,label:407}
	};
	this.blocks[411]=function()
	{
		// Wait 5
		this.aoz.sourcePos="964:3";
		return{type:8,instruction:"wait",args:[5]};
	};
	this.blocks[412]=function()
	{
		// Goto AGAIN
		this.aoz.sourcePos="965:3";
		return{type:1,label:401};
		// End If
		this.aoz.sourcePos="966:0";
	};
	this.blocks[413]=function()
	{
		// Return
		this.aoz.sourcePos="967:0";
		return{type:3};
	};
	this.blocks[414]=function()
	{
		// CANWEMOVE:
		// Return
		this.aoz.sourcePos="971:0";
		return{type:3};
	};
	this.blocks[415]=function()
	{
		// GOTAMOVE:
		// RFLAG=False
		this.aoz.sourcePos="974:0";
		this.vars.RFLAG=Math.floor(false);
		// For Y=0 To SIZEY-1
		this.aoz.sourcePos="975:0";
		this.vars.Y=0;
		if(this.vars.Y>this.vars.SIZEY-1)
			return{type:1,label:420};
	};
	this.blocks[416]=function()
	{
		// For X=0 To SIZEX-1
		this.aoz.sourcePos="976:3";
		this.vars.X=0;
		if(this.vars.X>this.vars.SIZEX-1)
			return{type:1,label:419};
	};
	this.blocks[417]=function()
	{
		// If KANDY(X,Y,0)=-1
		this.aoz.sourcePos="977:6";
		if(!(this.vars.KANDY_array.getValue([this.vars.X,this.vars.Y,0])==-1))
			return{type:1,label:418};
		// RFLAG=True
		this.aoz.sourcePos="978:9";
		this.vars.RFLAG=Math.floor(true);
		// End If
		this.aoz.sourcePos="979:6";
	};
	this.blocks[418]=function()
	{
		// Next X
		this.aoz.sourcePos="980:3";
		this.vars.X+=1;
		if(this.vars.X<=this.vars.SIZEX-1)
			return{type:1,label:417}
	};
	this.blocks[419]=function()
	{
		// Next Y
		this.aoz.sourcePos="981:0";
		this.vars.Y+=1;
		if(this.vars.Y<=this.vars.SIZEY-1)
			return{type:1,label:416}
	};
	this.blocks[420]=function()
	{
		// Return
		this.aoz.sourcePos="982:0";
		return{type:3};
	};
	this.blocks[421]=function()
	{
		// RITAGRID:
		// SETX=OFFSETX/16
		this.aoz.sourcePos="985:0";
		this.vars.SETX=Math.floor(this.vars.OFFSETX/16);
		// SETY=OFFSETY/16
		this.aoz.sourcePos="986:0";
		this.vars.SETY=Math.floor(this.vars.OFFSETY/16);
		// For Y=0 To SIZEY-1
		this.aoz.sourcePos="987:0";
		this.vars.Y=0;
		if(this.vars.Y>this.vars.SIZEY-1)
			return{type:1,label:429};
	};
	this.blocks[422]=function()
	{
		// For X=0 To SIZEX-1
		this.aoz.sourcePos="988:3";
		this.vars.X=0;
		if(this.vars.X>this.vars.SIZEX-1)
			return{type:1,label:428};
	};
	this.blocks[423]=function()
	{
		// If MOV(X,Y)>0 or RALL=True
		this.aoz.sourcePos="989:6";
		if(!(this.vars.MOV_array.getValue([this.vars.X,this.vars.Y])>0||this.vars.RALL==true))
			return{type:1,label:427};
		// If MOV(X,Y)>0 : MOV(X,Y)=MOV(X,Y)-1 : End If
		this.aoz.sourcePos="990:9";
		if(!(this.vars.MOV_array.getValue([this.vars.X,this.vars.Y])>0))
			return{type:1,label:424};
		this.aoz.sourcePos="990:25";
		this.vars.MOV_array.setValue([this.vars.X,this.vars.Y],Math.floor(this.vars.MOV_array.getValue([this.vars.X,this.vars.Y])-1));
		this.aoz.sourcePos="990:47";
	};
	this.blocks[424]=function()
	{
		// X2=X : Y2=Y
		this.aoz.sourcePos="993:9";
		this.vars.X2=Math.floor(this.vars.X);
		this.aoz.sourcePos="993:16";
		this.vars.Y2=Math.floor(this.vars.Y);
		// GX=X+SETX : GY=Y+SETY : GC=KANDY(X,Y,0) : GOFE=0 : Gosub PKANDY
		this.aoz.sourcePos="994:9";
		this.vars.GX=Math.floor(this.vars.X+this.vars.SETX);
		this.aoz.sourcePos="994:21";
		this.vars.GY=Math.floor(this.vars.Y+this.vars.SETY);
		this.aoz.sourcePos="994:33";
		this.vars.GC=Math.floor(this.vars.KANDY_array.getValue([this.vars.X,this.vars.Y,0]));
		this.aoz.sourcePos="994:51";
		this.vars.GOFE=0;
		this.aoz.sourcePos="994:60";
		return{type:2,label:509,return:425};
	};
	this.blocks[425]=function()
	{
		// If X=MARKUPX and Y=MARKUPY
		this.aoz.sourcePos="996:9";
		if(!(this.vars.X==this.vars.MARKUPX&&this.vars.Y==this.vars.MARKUPY))
			return{type:1,label:426};
		// Ink 2
		this.aoz.sourcePos="997:12";
		this.aoz.currentScreen.setInk(2,);
		// Javascript
		this.aoz.currentScreen.context.globalAlpha=0.5; 
		// End Javascript
		// Paste Bob X*16+OFFSETX,Y*16+OFFSETY,25
		this.aoz.sourcePos="1000:12";
		this.aoz.currentScreen.pasteBob(25,this.vars.X*16+this.vars.OFFSETX,this.vars.Y*16+this.vars.OFFSETY,undefined,undefined,undefined*this.aoz.degreeRadian,);
		// Javascript
		this.aoz.currentScreen.context.globalAlpha=1; 
		// End Javascript
		// End If
		this.aoz.sourcePos="1002:9";
	};
	this.blocks[426]=function()
	{
		// End If
		this.aoz.sourcePos="1003:6";
	};
	this.blocks[427]=function()
	{
		// Next X
		this.aoz.sourcePos="1004:3";
		this.vars.X+=1;
		if(this.vars.X<=this.vars.SIZEX-1)
			return{type:1,label:423}
	};
	this.blocks[428]=function()
	{
		// Next Y
		this.aoz.sourcePos="1005:0";
		this.vars.Y+=1;
		if(this.vars.Y<=this.vars.SIZEY-1)
			return{type:1,label:422}
	};
	this.blocks[429]=function()
	{
		// RALL=False
		this.aoz.sourcePos="1006:0";
		this.vars.RALL=Math.floor(false);
		// Return
		this.aoz.sourcePos="1014:0";
		return{type:3};
	};
	this.blocks[430]=function()
	{
		// FIRSTGRID:
		// BEF=0
		this.aoz.sourcePos="1017:0";
		this.vars.BEF=0;
		// ABOVE=0
		this.aoz.sourcePos="1018:0";
		this.vars.ABOVE=0;
		// For T=0 To 2
		this.aoz.sourcePos="1019:0";
		this.vars.T=0;
		if(this.vars.T>2)
			return{type:1,label:432};
	};
	this.blocks[431]=function()
	{
		// Next T
		this.aoz.sourcePos="1021:0";
		this.vars.T+=1;
		if(this.vars.T<=2)
			return{type:1,label:431}
	};
	this.blocks[432]=function()
	{
		// For Y=0 To SIZEY-1
		this.aoz.sourcePos="1022:0";
		this.vars.Y=0;
		if(this.vars.Y>this.vars.SIZEY-1)
			return{type:1,label:441};
	};
	this.blocks[433]=function()
	{
		// For X=0 To SIZEX-1
		this.aoz.sourcePos="1023:3";
		this.vars.X=0;
		if(this.vars.X>this.vars.SIZEX-1)
			return{type:1,label:440};
	};
	this.blocks[434]=function()
	{
		// If KANDY(X,Y,1)>-1
		this.aoz.sourcePos="1024:6";
		if(!(this.vars.KANDY_array.getValue([this.vars.X,this.vars.Y,1])>-1))
			return{type:1,label:438};
		// If Y>0 : ABOVE=KANDY(X,Y-1,0) : End If
		this.aoz.sourcePos="1025:9";
		if(!(this.vars.Y>0))
			return{type:1,label:435};
		this.aoz.sourcePos="1025:18";
		this.vars.ABOVE=Math.floor(this.vars.KANDY_array.getValue([this.vars.X,this.vars.Y-1,0]));
		this.aoz.sourcePos="1025:41";
	};
	this.blocks[435]=function()
	{
		// Repeat
		this.aoz.sourcePos="1026:9";
	};
	this.blocks[436]=function()
	{
		// NEW=Rnd(5)+1
		this.aoz.sourcePos="1027:12";
		this.vars.NEW=Math.floor(this.aoz.rnd(5)+1);
		// Until NEW<>BEF and NEW<>ABOVE
		this.aoz.sourcePos="1028:9";
		if(!(this.vars.NEW!=this.vars.BEF&&this.vars.NEW!=this.vars.ABOVE))
			return{type:1,label:436};
	};
	this.blocks[437]=function()
	{
		// KANDY(X,Y,0)=NEW
		this.aoz.sourcePos="1029:9";
		this.vars.KANDY_array.setValue([this.vars.X,this.vars.Y,0],Math.floor(this.vars.NEW));
		// ED(X,Y,0)=NEW
		this.aoz.sourcePos="1030:9";
		this.vars.ED_array.setValue([this.vars.X,this.vars.Y,0],Math.floor(this.vars.NEW));
		// BEF=KANDY(X,Y,0)
		this.aoz.sourcePos="1032:9";
		this.vars.BEF=Math.floor(this.vars.KANDY_array.getValue([this.vars.X,this.vars.Y,0]));
		// Else
		return{type:1,label:439};
	};
	this.blocks[438]=function()
	{
		// ED(X,Y,0)=0
		this.aoz.sourcePos="1035:9";
		this.vars.ED_array.setValue([this.vars.X,this.vars.Y,0],0);
		// KANDY(X,Y,0)=0
		this.aoz.sourcePos="1036:9";
		this.vars.KANDY_array.setValue([this.vars.X,this.vars.Y,0],0);
		// End If
		this.aoz.sourcePos="1037:6";
	};
	this.blocks[439]=function()
	{
		// Next X
		this.aoz.sourcePos="1039:3";
		this.vars.X+=1;
		if(this.vars.X<=this.vars.SIZEX-1)
			return{type:1,label:434}
	};
	this.blocks[440]=function()
	{
		// Next Y
		this.aoz.sourcePos="1040:0";
		this.vars.Y+=1;
		if(this.vars.Y<=this.vars.SIZEY-1)
			return{type:1,label:433}
	};
	this.blocks[441]=function()
	{
		// SETX=OFFSETX/16
		this.aoz.sourcePos="1041:0";
		this.vars.SETX=Math.floor(this.vars.OFFSETX/16);
		// SETY=OFFSETY/16
		this.aoz.sourcePos="1042:0";
		this.vars.SETY=Math.floor(this.vars.OFFSETY/16);
		// For Y=SIZEY-1 To 0 Step -1
		this.aoz.sourcePos="1043:0";
		this.vars.Y=Math.floor(this.vars.SIZEY-1);
		if(this.vars.Y<0)
			return{type:1,label:447};
	};
	this.blocks[442]=function()
	{
		// For X=0 To SIZEX-1
		this.aoz.sourcePos="1044:3";
		this.vars.X=0;
		if(this.vars.X>this.vars.SIZEX-1)
			return{type:1,label:446};
	};
	this.blocks[443]=function()
	{
		// If KANDY(X,Y,1)>-1
		this.aoz.sourcePos="1045:6";
		if(!(this.vars.KANDY_array.getValue([this.vars.X,this.vars.Y,1])>-1))
			return{type:1,label:445};
		// GX=X+SETX : GY=Y+SETY : GC=KANDY(X,Y,0) : GOFE=0 : Gosub PKANDY
		this.aoz.sourcePos="1047:9";
		this.vars.GX=Math.floor(this.vars.X+this.vars.SETX);
		this.aoz.sourcePos="1047:21";
		this.vars.GY=Math.floor(this.vars.Y+this.vars.SETY);
		this.aoz.sourcePos="1047:33";
		this.vars.GC=Math.floor(this.vars.KANDY_array.getValue([this.vars.X,this.vars.Y,0]));
		this.aoz.sourcePos="1047:51";
		this.vars.GOFE=0;
		this.aoz.sourcePos="1047:60";
		return{type:2,label:509,return:444};
	};
	this.blocks[444]=function()
	{
		// End If
		this.aoz.sourcePos="1048:6";
	};
	this.blocks[445]=function()
	{
		// Next X
		this.aoz.sourcePos="1050:3";
		this.vars.X+=1;
		if(this.vars.X<=this.vars.SIZEX-1)
			return{type:1,label:443}
	};
	this.blocks[446]=function()
	{
		// Next Y
		this.aoz.sourcePos="1051:0";
		this.vars.Y+=-1;
		if(this.vars.Y>=0)
			return{type:1,label:442}
	};
	this.blocks[447]=function()
	{
		// For T=0 To 5
		this.aoz.sourcePos="1053:0";
		this.vars.T=0;
		if(this.vars.T>5)
			return{type:1,label:449};
	};
	this.blocks[448]=function()
	{
		// Next T
		this.aoz.sourcePos="1055:0";
		this.vars.T+=1;
		if(this.vars.T<=5)
			return{type:1,label:448}
	};
	this.blocks[449]=function()
	{
		// Return
		this.aoz.sourcePos="1056:0";
		return{type:3};
	};
	this.blocks[450]=function()
	{
		// CREATEGRID:
		// BEF=0
		this.aoz.sourcePos="1059:0";
		this.vars.BEF=0;
		// ABOVE=0
		this.aoz.sourcePos="1060:0";
		this.vars.ABOVE=0;
		// For T=0 To 2
		this.aoz.sourcePos="1061:0";
		this.vars.T=0;
		if(this.vars.T>2)
			return{type:1,label:452};
	};
	this.blocks[451]=function()
	{
		// Next T
		this.aoz.sourcePos="1063:0";
		this.vars.T+=1;
		if(this.vars.T<=2)
			return{type:1,label:451}
	};
	this.blocks[452]=function()
	{
		// For Y=0 To SIZEY-1
		this.aoz.sourcePos="1064:0";
		this.vars.Y=0;
		if(this.vars.Y>this.vars.SIZEY-1)
			return{type:1,label:461};
	};
	this.blocks[453]=function()
	{
		// For X=0 To SIZEX-1
		this.aoz.sourcePos="1065:3";
		this.vars.X=0;
		if(this.vars.X>this.vars.SIZEX-1)
			return{type:1,label:460};
	};
	this.blocks[454]=function()
	{
		// If KANDY(X,Y,1)>-1
		this.aoz.sourcePos="1066:6";
		if(!(this.vars.KANDY_array.getValue([this.vars.X,this.vars.Y,1])>-1))
			return{type:1,label:458};
		// If Y>0 : ABOVE=KANDY(X,Y-1,0) : End If
		this.aoz.sourcePos="1067:9";
		if(!(this.vars.Y>0))
			return{type:1,label:455};
		this.aoz.sourcePos="1067:18";
		this.vars.ABOVE=Math.floor(this.vars.KANDY_array.getValue([this.vars.X,this.vars.Y-1,0]));
		this.aoz.sourcePos="1067:41";
	};
	this.blocks[455]=function()
	{
		// Repeat
		this.aoz.sourcePos="1068:9";
	};
	this.blocks[456]=function()
	{
		// NEW=Rnd(5)+1
		this.aoz.sourcePos="1069:12";
		this.vars.NEW=Math.floor(this.aoz.rnd(5)+1);
		// Until NEW<>BEF and NEW<>ABOVE
		this.aoz.sourcePos="1070:9";
		if(!(this.vars.NEW!=this.vars.BEF&&this.vars.NEW!=this.vars.ABOVE))
			return{type:1,label:456};
	};
	this.blocks[457]=function()
	{
		// KANDY(X,Y,0)=NEW
		this.aoz.sourcePos="1071:9";
		this.vars.KANDY_array.setValue([this.vars.X,this.vars.Y,0],Math.floor(this.vars.NEW));
		// ED(X,Y,0)=NEW
		this.aoz.sourcePos="1072:9";
		this.vars.ED_array.setValue([this.vars.X,this.vars.Y,0],Math.floor(this.vars.NEW));
		// BEF=KANDY(X,Y,0)
		this.aoz.sourcePos="1074:9";
		this.vars.BEF=Math.floor(this.vars.KANDY_array.getValue([this.vars.X,this.vars.Y,0]));
		// Else
		return{type:1,label:459};
	};
	this.blocks[458]=function()
	{
		// ED(X,Y,0)=0
		this.aoz.sourcePos="1077:9";
		this.vars.ED_array.setValue([this.vars.X,this.vars.Y,0],0);
		// KANDY(X,Y,0)=0
		this.aoz.sourcePos="1078:9";
		this.vars.KANDY_array.setValue([this.vars.X,this.vars.Y,0],0);
		// End If
		this.aoz.sourcePos="1079:6";
	};
	this.blocks[459]=function()
	{
		// Next X
		this.aoz.sourcePos="1080:3";
		this.vars.X+=1;
		if(this.vars.X<=this.vars.SIZEX-1)
			return{type:1,label:454}
	};
	this.blocks[460]=function()
	{
		// Next Y
		this.aoz.sourcePos="1081:0";
		this.vars.Y+=1;
		if(this.vars.Y<=this.vars.SIZEY-1)
			return{type:1,label:453}
	};
	this.blocks[461]=function()
	{
		// For T=0 To 5
		this.aoz.sourcePos="1082:0";
		this.vars.T=0;
		if(this.vars.T>5)
			return{type:1,label:463};
	};
	this.blocks[462]=function()
	{
		// Next T
		this.aoz.sourcePos="1084:0";
		this.vars.T+=1;
		if(this.vars.T<=5)
			return{type:1,label:462}
	};
	this.blocks[463]=function()
	{
		// Return
		this.aoz.sourcePos="1085:0";
		return{type:3};
	};
	this.blocks[464]=function()
	{
		// MAKERANDOMGRID:
		// For X=0 To((SIZEX-1)/2)
		this.aoz.sourcePos="1088:0";
		this.vars.X=0;
		if(this.vars.X>((this.vars.SIZEX-1)/2))
			return{type:1,label:468};
	};
	this.blocks[465]=function()
	{
		// For Y=0 To SIZEY-1
		this.aoz.sourcePos="1089:3";
		this.vars.Y=0;
		if(this.vars.Y>this.vars.SIZEY-1)
			return{type:1,label:467};
	};
	this.blocks[466]=function()
	{
		// ED(X,Y,0)=0
		this.aoz.sourcePos="1090:6";
		this.vars.ED_array.setValue([this.vars.X,this.vars.Y,0],0);
		// ED(X,Y,1)=Rnd(2)
		this.aoz.sourcePos="1091:6";
		this.vars.ED_array.setValue([this.vars.X,this.vars.Y,1],Math.floor(this.aoz.rnd(2)));
		// ED((SIZEX-1)-X,Y,0)=0
		this.aoz.sourcePos="1092:6";
		this.vars.ED_array.setValue([(this.vars.SIZEX-1)-this.vars.X,this.vars.Y,0],0);
		// ED((SIZEX-1)-X,Y,1)=ED(X,Y,1)
		this.aoz.sourcePos="1093:6";
		this.vars.ED_array.setValue([(this.vars.SIZEX-1)-this.vars.X,this.vars.Y,1],Math.floor(this.vars.ED_array.getValue([this.vars.X,this.vars.Y,1])));
		// Next Y
		this.aoz.sourcePos="1094:3";
		this.vars.Y+=1;
		if(this.vars.Y<=this.vars.SIZEY-1)
			return{type:1,label:466}
	};
	this.blocks[467]=function()
	{
		// Next X
		this.aoz.sourcePos="1095:0";
		this.vars.X+=1;
		if(this.vars.X<=((this.vars.SIZEX-1)/2))
			return{type:1,label:465}
	};
	this.blocks[468]=function()
	{
		// Gosub RELOAD
		this.aoz.sourcePos="1096:0";
		return{type:2,label:479,return:469};
	};
	this.blocks[469]=function()
	{
		// Return
		this.aoz.sourcePos="1097:0";
		return{type:3};
	};
	this.blocks[470]=function()
	{
		// _WASHLEVEL:
		// SETX=OFFSETX/16
		this.aoz.sourcePos="1101:0";
		this.vars.SETX=Math.floor(this.vars.OFFSETX/16);
		// SETY=OFFSETY/16
		this.aoz.sourcePos="1102:0";
		this.vars.SETY=Math.floor(this.vars.OFFSETY/16);
		// SX=SIZEX/2 : SY=SIZEY/2
		this.aoz.sourcePos="1104:0";
		this.vars.SX=Math.floor(this.vars.SIZEX/2);
		this.aoz.sourcePos="1104:13";
		this.vars.SY=Math.floor(this.vars.SIZEY/2);
		// B=0 : B2=9
		this.aoz.sourcePos="1105:0";
		this.vars.B=0;
		this.aoz.sourcePos="1105:6";
		this.vars.B2=9;
		// for T=SIZEX/2 to 0 step -1
		this.aoz.sourcePos="1107:0";
		this.vars.T=Math.floor(this.vars.SIZEX/2);
		if(this.vars.T<0)
			return{type:1,label:478};
	};
	this.blocks[471]=function()
	{
		// for X=0+T to SIZEX-1-T
		this.aoz.sourcePos="1108:3";
		this.vars.X=Math.floor(0+this.vars.T);
		if(this.vars.X>this.vars.SIZEX-1-this.vars.T)
			return{type:1,label:475};
	};
	this.blocks[472]=function()
	{
		// for Y=0 to SIZEY-1
		this.aoz.sourcePos="1109:6";
		this.vars.Y=0;
		if(this.vars.Y>this.vars.SIZEY-1)
			return{type:1,label:474};
	};
	this.blocks[473]=function()
	{
		// GX=X+SETX : GY=Y+SETY
		this.aoz.sourcePos="1110:12";
		this.vars.GX=Math.floor(this.vars.X+this.vars.SETX);
		this.aoz.sourcePos="1110:24";
		this.vars.GY=Math.floor(this.vars.Y+this.vars.SETY);
		// Screen Copy 0,B*16,B2*16,B*16+16,B2*16+16 To 1,GX*16,GY*16
		this.aoz.sourcePos="1111:12";
		this.aoz.getScreen(0).screenCopy(this.aoz.getScreen(1),undefined,{x:this.vars.B*16,y:this.vars.B2*16,width:(this.vars.B*16+16)-(this.vars.B*16),height:(this.vars.B2*16+16)-(this.vars.B2*16)},{x:this.vars.GX*16,y:this.vars.GY*16});
		// Next Y
		this.aoz.sourcePos="1112:6";
		this.vars.Y+=1;
		if(this.vars.Y<=this.vars.SIZEY-1)
			return{type:1,label:473}
	};
	this.blocks[474]=function()
	{
		// Next X
		this.aoz.sourcePos="1113:3";
		this.vars.X+=1;
		if(this.vars.X<=this.vars.SIZEX-1-this.vars.T)
			return{type:1,label:472}
	};
	this.blocks[475]=function()
	{
		// wait vbl
		this.aoz.sourcePos="1114:3";
		return{type:8,instruction:"waitVbl",args:[]};
	};
	this.blocks[476]=function()
	{
		// wait 5
		this.aoz.sourcePos="1115:3";
		return{type:8,instruction:"wait",args:[5]};
	};
	this.blocks[477]=function()
	{
		// next T
		this.aoz.sourcePos="1116:0";
		this.vars.T+=-1;
		if(this.vars.T>=0)
			return{type:1,label:471}
	};
	this.blocks[478]=function()
	{
		// Return
		this.aoz.sourcePos="1117:0";
		return{type:3};
	};
	this.blocks[479]=function()
	{
		// RELOAD:
		// For X=0 To SIZEX-1
		this.aoz.sourcePos="1120:0";
		this.vars.X=0;
		if(this.vars.X>this.vars.SIZEX-1)
			return{type:1,label:489};
	};
	this.blocks[480]=function()
	{
		// For Y=0 To SIZEY-1
		this.aoz.sourcePos="1121:3";
		this.vars.Y=0;
		if(this.vars.Y>this.vars.SIZEY-1)
			return{type:1,label:488};
	};
	this.blocks[481]=function()
	{
		// For T=0 To 3
		this.aoz.sourcePos="1122:6";
		this.vars.T=0;
		if(this.vars.T>3)
			return{type:1,label:487};
	};
	this.blocks[482]=function()
	{
		// If T>0
		this.aoz.sourcePos="1123:9";
		if(!(this.vars.T>0))
			return{type:1,label:483};
		// KANDY(X,Y,T)=ED(X,Y,T)
		this.aoz.sourcePos="1124:12";
		this.vars.KANDY_array.setValue([this.vars.X,this.vars.Y,this.vars.T],Math.floor(this.vars.ED_array.getValue([this.vars.X,this.vars.Y,this.vars.T])));
		// Else
		return{type:1,label:486};
	};
	this.blocks[483]=function()
	{
		// If ED(X,Y,1)>-1
		this.aoz.sourcePos="1126:12";
		if(!(this.vars.ED_array.getValue([this.vars.X,this.vars.Y,1])>-1))
			return{type:1,label:484};
		// KANDY(X,Y,T)=-1
		this.aoz.sourcePos="1127:15";
		this.vars.KANDY_array.setValue([this.vars.X,this.vars.Y,this.vars.T],-1);
		// Else
		return{type:1,label:485};
	};
	this.blocks[484]=function()
	{
		// KANDY(X,Y,T)=0
		this.aoz.sourcePos="1129:15";
		this.vars.KANDY_array.setValue([this.vars.X,this.vars.Y,this.vars.T],0);
		// End If
		this.aoz.sourcePos="1130:12";
	};
	this.blocks[485]=function()
	{
		// End If
		this.aoz.sourcePos="1131:9";
	};
	this.blocks[486]=function()
	{
		// Next T
		this.aoz.sourcePos="1132:6";
		this.vars.T+=1;
		if(this.vars.T<=3)
			return{type:1,label:482}
	};
	this.blocks[487]=function()
	{
		// Next Y
		this.aoz.sourcePos="1133:3";
		this.vars.Y+=1;
		if(this.vars.Y<=this.vars.SIZEY-1)
			return{type:1,label:481}
	};
	this.blocks[488]=function()
	{
		// Next X
		this.aoz.sourcePos="1134:0";
		this.vars.X+=1;
		if(this.vars.X<=this.vars.SIZEX-1)
			return{type:1,label:480}
	};
	this.blocks[489]=function()
	{
		// Return
		this.aoz.sourcePos="1136:0";
		return{type:3};
	};
	this.blocks[490]=function()
	{
		// _LOADLEVEL:
		// PRASK=1
		this.aoz.sourcePos="1139:0";
		this.vars.PRASK=1;
		// POANG=0
		this.aoz.sourcePos="1140:0";
		this.vars.POANG=0;
		// IF PRASK=1
		this.aoz.sourcePos="1142:0";
		if(!(this.vars.PRASK==1))
			return{type:1,label:501};
		// Open In 1,"levels/level"+Str$(LEVEL)+".lvl"
		this.aoz.sourcePos="1143:3";
		return{type:12,waitThis:this.aoz.thisFilesystem,callFunction:"openIn",waitFunction:"load_wait",args:[1,"levels/level"+this.aoz.str$(this.vars.LEVEL)+".lvl"]};
	};
	this.blocks[491]=function()
	{
		// For X=0 To SIZEX-1
		this.aoz.sourcePos="1144:3";
		this.vars.X=0;
		if(this.vars.X>this.vars.SIZEX-1)
			return{type:1,label:498};
	};
	this.blocks[492]=function()
	{
		// For Y=0 To SIZEY-1
		this.aoz.sourcePos="1145:6";
		this.vars.Y=0;
		if(this.vars.Y>this.vars.SIZEY-1)
			return{type:1,label:497};
	};
	this.blocks[493]=function()
	{
		// ED(X,Y,0)=0
		this.aoz.sourcePos="1146:9";
		this.vars.ED_array.setValue([this.vars.X,this.vars.Y,0],0);
		// Input #1,ED(X,Y,1)
		this.aoz.sourcePos="1147:9";
		this.aoz.filesystem.input(1,[{name:"ED_array",dimensions:[this.vars.X,this.vars.Y,1],type:0}],false);
	};
	this.blocks[494]=function()
	{
		// Input #1,ED(X,Y,2)
		this.aoz.sourcePos="1148:9";
		this.aoz.filesystem.input(1,[{name:"ED_array",dimensions:[this.vars.X,this.vars.Y,2],type:0}],false);
	};
	this.blocks[495]=function()
	{
		// Input #1,ED(X,Y,3)
		this.aoz.sourcePos="1149:9";
		this.aoz.filesystem.input(1,[{name:"ED_array",dimensions:[this.vars.X,this.vars.Y,3],type:0}],false);
	};
	this.blocks[496]=function()
	{
		// Next Y
		this.aoz.sourcePos="1150:6";
		this.vars.Y+=1;
		if(this.vars.Y<=this.vars.SIZEY-1)
			return{type:1,label:493}
	};
	this.blocks[497]=function()
	{
		// Next X
		this.aoz.sourcePos="1151:3";
		this.vars.X+=1;
		if(this.vars.X<=this.vars.SIZEX-1)
			return{type:1,label:492}
	};
	this.blocks[498]=function()
	{
		// Close 1
		this.aoz.sourcePos="1152:3";
		return{type:12,waitThis:this.aoz.thisFilesystem,callFunction:"close",waitFunction:"load_wait",args:[1]};
	};
	this.blocks[499]=function()
	{
		// Gosub RELOAD
		this.aoz.sourcePos="1153:3";
		return{type:2,label:479,return:500};
	};
	this.blocks[500]=function()
	{
		// Else
		return{type:1,label:507};
	};
	this.blocks[501]=function()
	{
		// For X=0 To SIZEX-1
		this.aoz.sourcePos="1155:3";
		this.vars.X=0;
		if(this.vars.X>this.vars.SIZEX-1)
			return{type:1,label:505};
	};
	this.blocks[502]=function()
	{
		// For Y=0 To SIZEY-1
		this.aoz.sourcePos="1156:6";
		this.vars.Y=0;
		if(this.vars.Y>this.vars.SIZEY-1)
			return{type:1,label:504};
	};
	this.blocks[503]=function()
	{
		// ED(X,Y,1)=0
		this.aoz.sourcePos="1157:9";
		this.vars.ED_array.setValue([this.vars.X,this.vars.Y,1],0);
		// ED(X,Y,2)=0
		this.aoz.sourcePos="1158:9";
		this.vars.ED_array.setValue([this.vars.X,this.vars.Y,2],0);
		// ED(X,Y,3)=0
		this.aoz.sourcePos="1159:9";
		this.vars.ED_array.setValue([this.vars.X,this.vars.Y,3],0);
		// Next Y
		this.aoz.sourcePos="1160:6";
		this.vars.Y+=1;
		if(this.vars.Y<=this.vars.SIZEY-1)
			return{type:1,label:503}
	};
	this.blocks[504]=function()
	{
		// Next X
		this.aoz.sourcePos="1161:3";
		this.vars.X+=1;
		if(this.vars.X<=this.vars.SIZEX-1)
			return{type:1,label:502}
	};
	this.blocks[505]=function()
	{
		// Gosub RELOAD
		this.aoz.sourcePos="1162:3";
		return{type:2,label:479,return:506};
	};
	this.blocks[506]=function()
	{
		// End If
		this.aoz.sourcePos="1163:0";
	};
	this.blocks[507]=function()
	{
		// Return
		this.aoz.sourcePos="1164:0";
		return{type:3};
	};
	this.blocks[508]=function()
	{
		// _SAVELEVEL:
		// Return
		this.aoz.sourcePos="1168:0";
		return{type:3};
	};
	this.blocks[509]=function()
	{
		// PKANDY:
		// B2=9 : SP=0 : B=0
		this.aoz.sourcePos="1175:0";
		this.vars.B2=9;
		this.aoz.sourcePos="1175:7";
		this.vars.SP=0;
		this.aoz.sourcePos="1175:14";
		this.vars.B=0;
		// If KANDY(X2,Y2,1)>0 : B=KANDY(X2,Y2,1) : End If
		this.aoz.sourcePos="1177:0";
		if(!(this.vars.KANDY_array.getValue([this.vars.X2,this.vars.Y2,1])>0))
			return{type:1,label:510};
		this.aoz.sourcePos="1177:22";
		this.vars.B=Math.floor(this.vars.KANDY_array.getValue([this.vars.X2,this.vars.Y2,1]));
		this.aoz.sourcePos="1177:41";
	};
	this.blocks[510]=function()
	{
		// If KANDY(X2,Y2,1)=-1 : B=4 : End If
		this.aoz.sourcePos="1178:0";
		if(!(this.vars.KANDY_array.getValue([this.vars.X2,this.vars.Y2,1])==-1))
			return{type:1,label:511};
		this.aoz.sourcePos="1178:23";
		this.vars.B=4;
		this.aoz.sourcePos="1178:29";
	};
	this.blocks[511]=function()
	{
		// If GC>0
		this.aoz.sourcePos="1179:0";
		if(!(this.vars.GC>0))
			return{type:1,label:520};
		// B2=9 : SP=0
		this.aoz.sourcePos="1180:3";
		this.vars.B2=9;
		this.aoz.sourcePos="1180:10";
		this.vars.SP=0;
		// If GC>10 and GC<20 : SP=1 : GC=GC-10 : End If
		this.aoz.sourcePos="1181:3";
		if(!(this.vars.GC>10&&this.vars.GC<20))
			return{type:1,label:512};
		this.aoz.sourcePos="1181:24";
		this.vars.SP=1;
		this.aoz.sourcePos="1181:31";
		this.vars.GC=Math.floor(this.vars.GC-10);
		this.aoz.sourcePos="1181:42";
	};
	this.blocks[512]=function()
	{
		// If GC>20 and GC<30 : SP=2 : GC=GC-20 : End If
		this.aoz.sourcePos="1182:3";
		if(!(this.vars.GC>20&&this.vars.GC<30))
			return{type:1,label:513};
		this.aoz.sourcePos="1182:24";
		this.vars.SP=2;
		this.aoz.sourcePos="1182:31";
		this.vars.GC=Math.floor(this.vars.GC-20);
		this.aoz.sourcePos="1182:42";
	};
	this.blocks[513]=function()
	{
		// If GC>30 and GC<40 : B=2 : GC=GC-30 : End If
		this.aoz.sourcePos="1183:3";
		if(!(this.vars.GC>30&&this.vars.GC<40))
			return{type:1,label:514};
		this.aoz.sourcePos="1183:24";
		this.vars.B=2;
		this.aoz.sourcePos="1183:30";
		this.vars.GC=Math.floor(this.vars.GC-30);
		this.aoz.sourcePos="1183:41";
	};
	this.blocks[514]=function()
	{
		// If GC>40 and GC<50 : B=3 : GC=GC-40 : End If
		this.aoz.sourcePos="1184:3";
		if(!(this.vars.GC>40&&this.vars.GC<50))
			return{type:1,label:515};
		this.aoz.sourcePos="1184:24";
		this.vars.B=3;
		this.aoz.sourcePos="1184:30";
		this.vars.GC=Math.floor(this.vars.GC-40);
		this.aoz.sourcePos="1184:41";
	};
	this.blocks[515]=function()
	{
		// GC=GC-1
		this.aoz.sourcePos="1186:3";
		this.vars.GC=Math.floor(this.vars.GC-1);
		// Screen Copy 0,B*16,B2*16,B*16+16,B2*16+16 To 1,GX*16,GY*16
		this.aoz.sourcePos="1188:3";
		this.aoz.getScreen(0).screenCopy(this.aoz.getScreen(1),undefined,{x:this.vars.B*16,y:this.vars.B2*16,width:(this.vars.B*16+16)-(this.vars.B*16),height:(this.vars.B2*16+16)-(this.vars.B2*16)},{x:this.vars.GX*16,y:this.vars.GY*16});
		// If EMODE$="testgame" or EMODE$="placegems"
		this.aoz.sourcePos="1190:3";
		if(!(this.vars.EMODE$=="testgame"||this.vars.EMODE$=="placegems"))
			return{type:1,label:517};
		// Javascript
		this.aoz.currentScreen.context.globalAlpha=0.5; 
		// End Javascript
		// Paste Bob GX*16+2,GY*16+2+GOFE,GC+7
		this.aoz.sourcePos="1192:6";
		this.aoz.currentScreen.pasteBob(this.vars.GC+7,this.vars.GX*16+2,this.vars.GY*16+2+this.vars.GOFE,undefined,undefined,undefined*this.aoz.degreeRadian,);
		// Javascript
		this.aoz.currentScreen.context.globalAlpha=1; 
		// End Javascript
		// If SP=0
		this.aoz.sourcePos="1197:6";
		if(!(this.vars.SP==0))
			return{type:1,label:516};
		// Paste Bob GX*16+1,GY*16+1+GOFE,GC+1
		this.aoz.sourcePos="1198:9";
		this.aoz.currentScreen.pasteBob(this.vars.GC+1,this.vars.GX*16+1,this.vars.GY*16+1+this.vars.GOFE,undefined,undefined,undefined*this.aoz.degreeRadian,);
		// End If
		this.aoz.sourcePos="1199:6";
	};
	this.blocks[516]=function()
	{
		// End If
		this.aoz.sourcePos="1201:3";
	};
	this.blocks[517]=function()
	{
		// If SP=1
		this.aoz.sourcePos="1202:3";
		if(!(this.vars.SP==1))
			return{type:1,label:518};
		// Paste Bob GX*16+1,GY*16+1+GOFE,GC+13
		this.aoz.sourcePos="1203:6";
		this.aoz.currentScreen.pasteBob(this.vars.GC+13,this.vars.GX*16+1,this.vars.GY*16+1+this.vars.GOFE,undefined,undefined,undefined*this.aoz.degreeRadian,);
		// End If
		this.aoz.sourcePos="1204:3";
	};
	this.blocks[518]=function()
	{
		// If SP=2
		this.aoz.sourcePos="1205:3";
		if(!(this.vars.SP==2))
			return{type:1,label:519};
		// Paste Bob GX*16+1,GY*16+1+GOFE,26
		this.aoz.sourcePos="1206:6";
		this.aoz.currentScreen.pasteBob(26,this.vars.GX*16+1,this.vars.GY*16+1+this.vars.GOFE,undefined,undefined,undefined*this.aoz.degreeRadian,);
		// End If
		this.aoz.sourcePos="1207:3";
	};
	this.blocks[519]=function()
	{
		// Else
		return{type:1,label:521};
	};
	this.blocks[520]=function()
	{
		// B2=9
		this.aoz.sourcePos="1210:3";
		this.vars.B2=9;
		// Screen Copy 0,B*16,B2*16,B*16+16,B2*16+16 To 1,GX*16,GY*16
		this.aoz.sourcePos="1211:3";
		this.aoz.getScreen(0).screenCopy(this.aoz.getScreen(1),undefined,{x:this.vars.B*16,y:this.vars.B2*16,width:(this.vars.B*16+16)-(this.vars.B*16),height:(this.vars.B2*16+16)-(this.vars.B2*16)},{x:this.vars.GX*16,y:this.vars.GY*16});
		// End If
		this.aoz.sourcePos="1212:0";
	};
	this.blocks[521]=function()
	{
		// Return
		this.aoz.sourcePos="1213:0";
		return{type:3};
		// End
		this.aoz.sourcePos="1217:0";
		return{type:0}
	};
	this.blocks[522]=function()
	{
		return {type:0};
	};

	// Labels...
	this.labels=
	{
		LP:
		{
			dataPosition:0,
			labelBlock:122
		},
		MAINMENU:
		{
			dataPosition:0,
			labelBlock:124
		},
		CHOOSEPLAYER:
		{
			dataPosition:0,
			labelBlock:125
		},
		RETRY2:
		{
			dataPosition:0,
			labelBlock:126
		},
		_SAVEPROGRESS:
		{
			dataPosition:0,
			labelBlock:143
		},
		_LOADPROGRESS:
		{
			dataPosition:0,
			labelBlock:144
		},
		_SAVEPLAYERS:
		{
			dataPosition:0,
			labelBlock:145
		},
		_LOADPLAYERS:
		{
			dataPosition:0,
			labelBlock:150
		},
		TESTMOVE:
		{
			dataPosition:0,
			labelBlock:157
		},
		DAN3:
		{
			dataPosition:0,
			labelBlock:196
		},
		NEWGRID:
		{
			dataPosition:0,
			labelBlock:207
		},
		ANMOVE:
		{
			dataPosition:0,
			labelBlock:221
		},
		BONUS1:
		{
			dataPosition:0,
			labelBlock:234
		},
		DELKANDY:
		{
			dataPosition:0,
			labelBlock:239
		},
		SGRID:
		{
			dataPosition:0,
			labelBlock:246
		},
		CANCELGRID:
		{
			dataPosition:0,
			labelBlock:253
		},
		MOVEKANDY:
		{
			dataPosition:0,
			labelBlock:260
		},
		URKA:
		{
			dataPosition:0,
			labelBlock:282
		},
		LP2:
		{
			dataPosition:0,
			labelBlock:286
		},
		_CHECKKANDY:
		{
			dataPosition:0,
			labelBlock:311
		},
		WEDONE:
		{
			dataPosition:0,
			labelBlock:392
		},
		CHECKREMOVE:
		{
			dataPosition:0,
			labelBlock:400
		},
		AGAIN:
		{
			dataPosition:0,
			labelBlock:401
		},
		CANWEMOVE:
		{
			dataPosition:0,
			labelBlock:414
		},
		GOTAMOVE:
		{
			dataPosition:0,
			labelBlock:415
		},
		RITAGRID:
		{
			dataPosition:0,
			labelBlock:421
		},
		FIRSTGRID:
		{
			dataPosition:0,
			labelBlock:430
		},
		CREATEGRID:
		{
			dataPosition:0,
			labelBlock:450
		},
		MAKERANDOMGRID:
		{
			dataPosition:0,
			labelBlock:464
		},
		_WASHLEVEL:
		{
			dataPosition:0,
			labelBlock:470
		},
		RELOAD:
		{
			dataPosition:0,
			labelBlock:479
		},
		_LOADLEVEL:
		{
			dataPosition:0,
			labelBlock:490
		},
		_SAVELEVEL:
		{
			dataPosition:0,
			labelBlock:508
		},
		PKANDY:
		{
			dataPosition:0,
			labelBlock:509
		}
	};
	this.aoz.run(this,0,null,this);
	this.aoz.v1_0_bobs=new v1_0_bobs(this.aoz,this);
	this.aoz.v1_0_filesystem=new v1_0_filesystem(this.aoz,this);
	this.aoz.v1_0_screens=new v1_0_screens(this.aoz,this);
	this.aoz.v1_0_textwindows=new v1_0_textwindows(this.aoz,this);
};
