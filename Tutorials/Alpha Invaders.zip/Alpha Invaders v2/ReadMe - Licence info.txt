Sound effects:

Sound effects obtained from https://www.zapsplat.com
Standard licence.  https://www.zapsplat.com/license-type/standard-license/
____________________________________________________________________

Explosion graphics:

This work is licensed under the Creative Commons Attribution 3.0 Unported License. To view a copy of this license, visit http://creativecommons.org/licenses/by/3.0/ or send a letter to Creative Commons, PO Box 1866, Mountain View, CA 94042, USA.

"Iron Plague" art by Daniel Cook (Lostgarden.com), licensed CC-BY 3.0 : https://opengameart.org/content/iron-plague-explode5bmp
____________________________________________________________________

Moon picture:
Taken from the NASA Flickr site.  Commercial use allowed.

https://creativecommons.org/licenses/by/4.0/
https://www.flickr.com/photos/132160802@N06/21406290833/in/photolist-yBAQtT-zp8TRe-v1Ng5P-URYtL4-bnoscL-oyfftP-NSoYiV-jR9gc-6RyQbL-LFi9EN-URYyux-5XXhG7-nNFGx8-HQtqAk-XiVtpd-PTXEXv-yVZGDi-8fwvFX-q175Qk-2hTPs4y-r4jAKU-7eSuom-9e9Rsh-pUK5k6-oXXczm-WCd84b-5zWAk5-uAtbRZ-2hbH91g-j1TJM-5XXP8E-5XXNSS-HvwtWv-5YCcST-9w1E85-7kSgPw-S4tZdo-d2Ydfs-2gFLK9k-5BvCDi-TZLKFT-qBbN6U-nr4KFS-4yQuQH-7ZYnft-bCac8G-BKZ79s-FK2weE-ECBG2n-646wTa

The image has been cropped from the original by Justin Cowart.  Apollo 16 - Science at Station 1
____________________________________________________________________

Space ship drawn by Paul Kitching the creator of this software.

