Firework Demo
Written By: Paul Kitching

I was listening to the fireworks outside as we left 2019 and moved into 2020 and thought it would be fun to simulate a firework display in AOZ, so here it is.  It's the first time I've ever tried to do particle effects, so there are certainly better and more clever ways to do it.
It has all the settings ready to go by accepting the default when running it, but you can change things if you want, though some combinations could probably cause a runtime error.  I may update this with sliders and buttons for the options at some point when AOZ has some missing features added in the future.  At the moment it's using 'input' without validation on acceptable values.

It wasn't planned very well, so in manual mode you have to do any ground fireworks first, then the air ones afterwards.  I was just adding things as I thought of them, and the manual mode was the last thing.  It also doesn't loop back to the title screen, which is bad.  Just press F5 to reload the page.

Sound effects obtained from https://www.zapsplat.com.  Used with permission.

Firework photos taken by Paul Kitching, the author of this demo.
